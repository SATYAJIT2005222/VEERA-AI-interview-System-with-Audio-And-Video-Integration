/* ======================================================
GLOBAL VARIABLES
====================================================== */

let recorder = null;

let audioChunks = [];

let stream = null;

let Vidstream = null;

let streamInterval = null;

let isRecording = false;

let isStoppingRecording = false;

/* ======================================================
AUDIO SILENCE DETECTION
====================================================== */

let audioContext = null;

let analyser = null;

let audioSource = null;

let dataArray = null;

let silenceAnimationFrame = null;

let silenceStartTime = null;

let speechDetected = false;

let recordingStartTime = 0;

/*
Candidate must remain silent for this amount of time
before recording automatically stops.
*/

const SILENCE_DURATION = 3500;

/*
Give the candidate some time to start speaking.


Silence detection will not automatically stop the
recording during this initial period.


*/

const INITIAL_GRACE_PERIOD = 1000;

/*
RMS threshold.


Lower value = more sensitive.

Typical values:

0.01 = very sensitive
0.015 = sensitive
0.02 = normal
0.03 = less sensitive

We start with 0.015.


*/

const SILENCE_THRESHOLD = 0.015;

/*
How frequently the audio analyser checks
microphone volume.
*/

const AUDIO_CHECK_INTERVAL = 100;

/* ======================================================
DOM ELEMENTS
====================================================== */

const StartBtn =
document.getElementById("Start");

const StopBtn =
document.getElementById("Stop");

const StopInt =
document.getElementById("StopInt");

const video =
document.getElementById("preview");

const startScreen =
document.getElementById("startScreen");

const startButton =
document.getElementById("startExperience");

const veeraIntro =
document.getElementById("veeraIntro");

const landingPage =
document.getElementById("landingPage");

const music =
document.getElementById("introMusic");

const resumeUpload =
document.getElementById("resumeUpload");

const uploadResumeBtn =
document.getElementById("uploadResumeBtn");

const uploadStatus =
document.getElementById("uploadStatus");

const generateReportBtn =
document.getElementById("generateReportBtn");

const reportModal =
document.getElementById("reportModal");

const closeReportBtn =
document.getElementById("closeReportBtn");

const downloadReportBtn =
document.getElementById("downloadReportBtn");

const reportBody =
document.getElementById("reportBody");

/* ======================================================
BACKEND
====================================================== */

const ROBOT_BACKEND =
"http://127.0.0.1:8000";

/* ======================================================
ROBOT STATE SYNCHRONIZATION
====================================================== */

async function setRobotState(state) {


try {

    const response =
        await fetch(
            `${ROBOT_BACKEND}/robot/test`,
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    state: state
                })
            }
        );


    if (!response.ok) {

        throw new Error(
            `Robot state request failed: ${response.status}`
        );

    }


    console.log(
        `[ROBOT SYNC] ${state}`
    );

}
catch (error) {

    console.error(
        `[ROBOT SYNC] Failed to set ${state}:`,
        error
    );

}


}

/* ======================================================
INITIAL PAGE STATE
====================================================== */

veeraIntro.style.display = "none";

landingPage.style.display = "none";

/* ======================================================
AUDIO RMS CALCULATION
====================================================== */

/*
This function calculates RMS volume from the
microphone waveform.


This is much more reliable for silence detection
than getByteFrequencyData().


*/

function calculateRMS() {


if (!analyser || !dataArray) {

    return 0;

}


analyser.getByteTimeDomainData(
    dataArray
);


let sumSquares = 0;


for (
    let i = 0;
    i < dataArray.length;
    i++
) {

    /*
        Convert 0-255 audio value to
        -1 to +1 range.
    */

    const normalized =
        (dataArray[i] - 128) / 128;


    sumSquares +=
        normalized * normalized;

}


const meanSquare =
    sumSquares / dataArray.length;


const rms =
    Math.sqrt(meanSquare);


return rms;


}

/* ======================================================
UPDATE RECORDING BUTTON
====================================================== */

function updateRecordingButton(text) {


if (!StartBtn) {
    return;
}

StartBtn.textContent = text;


}

/* ======================================================
SILENCE DETECTION
====================================================== */

function detectSilence() {


if (!isRecording) {

    return;

}


const now =
    performance.now();


/*
    Calculate how long the candidate has
    been recording.
*/

const recordingTime =
    now - recordingStartTime;


/*
    Calculate microphone RMS.
*/

const volume =
    calculateRMS();


console.log(
    `[AUDIO] RMS: ${volume.toFixed(4)}`
);


/* ==================================================
   INITIAL GRACE PERIOD
================================================== */

if (
    recordingTime <
    INITIAL_GRACE_PERIOD
) {

    silenceAnimationFrame =
        setTimeout(
            detectSilence,
            AUDIO_CHECK_INTERVAL
        );

    return;

}


/* ==================================================
   SPEECH DETECTION
================================================== */

if (
    volume >
    SILENCE_THRESHOLD
) {

    /*
        Candidate is speaking.

        Therefore we know that an actual answer
        has started.
    */

    speechDetected = true;

    silenceStartTime = null;


    updateRecordingButton(
        "🎙 Recording... Listening"
    );


    console.log(
        "[AUDIO] Speech detected"
    );

}


/* ==================================================
   SILENCE DETECTION
================================================== */

else {

    /*
        Do not stop until the candidate has
        actually spoken at least once.
    */

    if (!speechDetected) {

        updateRecordingButton(
            "🎙 Recording... Waiting for speech"
        );


        silenceAnimationFrame =
            setTimeout(
                detectSilence,
                AUDIO_CHECK_INTERVAL
            );

        return;

    }


    /*
        Candidate has previously spoken and
        is currently silent.
    */

    if (!silenceStartTime) {

        silenceStartTime =
            performance.now();


        console.log(
            "[AUDIO] Silence started"
        );

    }


    /*
        Calculate how long the candidate
        has been silent.
    */

    const silentDuration =
        performance.now() -
        silenceStartTime;


    const remaining =
        Math.max(
            0,
            SILENCE_DURATION -
            silentDuration
        );


    const remainingSeconds =
        Math.ceil(
            remaining / 1000
        );


    updateRecordingButton(
        `⏳ Silence detected... ${remainingSeconds}s`
    );


    console.log(
        `[AUDIO] Silence: ${(silentDuration / 1000).toFixed(1)}s`
    );


    /*
        Candidate has been silent for
        3.5 seconds.
    */

    if (
        silentDuration >=
        SILENCE_DURATION
    ) {

        console.log(
            "[AUDIO] 3.5 seconds of silence detected"
        );


        stopRecording();

        return;

    }

}


/*
    Continue monitoring.
*/

if (isRecording) {

    silenceAnimationFrame =
        setTimeout(
            detectSilence,
            AUDIO_CHECK_INTERVAL
        );

}


}

/* ======================================================
START AUDIO ANALYSIS
====================================================== */

async function setupAudioAnalysis(
microphoneStream
) {


try {

    /*
        Create AudioContext.
    */

    audioContext =
        new (
            window.AudioContext ||
            window.webkitAudioContext
        )();


    /*
        Some browsers create the AudioContext
        in suspended state.
    */

    if (
        audioContext.state ===
        "suspended"
    ) {

        await audioContext.resume();

    }


    /*
        Create microphone source.
    */

    audioSource =
        audioContext.createMediaStreamSource(
            microphoneStream
        );


    /*
        Create analyser.
    */

    analyser =
        audioContext.createAnalyser();


    /*
        Larger FFT size gives us a better
        waveform representation.
    */

    analyser.fftSize = 2048;


    /*
        Use smoothing so the RMS does not
        jump excessively.
    */

    analyser.smoothingTimeConstant = 0.15;


    /*
        Create waveform data array.
    */

    dataArray =
        new Uint8Array(
            analyser.fftSize
        );


    /*
        Connect microphone → analyser.
    */

    audioSource.connect(
        analyser
    );


    console.log(
        "[AUDIO] Audio analyser initialized"
    );

    console.log(
        `[AUDIO] Silence threshold: ${SILENCE_THRESHOLD}`
    );


}
catch (error) {

    console.error(
        "[AUDIO] Failed to initialize analyser:",
        error
    );

}


}

/* ======================================================
CLEAN UP AUDIO ANALYSIS
====================================================== */

async function cleanupAudioAnalysis() {


/*
    Stop silence monitoring.
*/

if (silenceAnimationFrame) {

    clearTimeout(
        silenceAnimationFrame
    );

    silenceAnimationFrame = null;

}


silenceStartTime = null;

speechDetected = false;


/*
    Disconnect analyser.
*/

if (audioSource) {

    try {

        audioSource.disconnect();

    }
    catch (error) {

        console.log(
            "Audio source already disconnected"
        );

    }

    audioSource = null;

}


/*
    Close AudioContext.
*/

if (audioContext) {

    try {

        await audioContext.close();

    }
    catch (error) {

        console.log(
            "AudioContext already closed"
        );

    }

    audioContext = null;

}


analyser = null;

dataArray = null;


}

/* ======================================================
STOP RECORDING
====================================================== */

async function stopRecording() {


/*
    Prevent multiple calls.

    Silence detection can sometimes trigger
    more than once.
*/

if (
    !isRecording ||
    isStoppingRecording
) {

    return;

}


isStoppingRecording = true;

isRecording = false;


console.log(
    "================================"
);

console.log(
    "STOP RECORDING"
);

console.log(
    "Candidate has finished answering."
);

console.log(
    "================================"
);


/*
    Stop silence detector.
*/

if (silenceAnimationFrame) {

    clearTimeout(
        silenceAnimationFrame
    );

    silenceAnimationFrame = null;

}


silenceStartTime = null;


/*
    Close audio analyser.
*/

await cleanupAudioAnalysis();


/*
    Robot is now thinking.

    This happens before backend processing.
*/

await setRobotState(
    "THINKING"
);


/*
    recorder.onstop is responsible for
    sending the completed audio.
*/

if (
    recorder &&
    recorder.state !== "inactive"
) {

    recorder.onstop =
        async () => {

            try {

                console.log(
                    "[RECORDER] Recording stopped"
                );


                /*
                    Create final audio blob.
                */

                const audioBlob =
                    new Blob(
                        audioChunks,
                        {
                            type:
                                recorder.mimeType ||
                                "audio/webm"
                        }
                    );


                console.log(
                    `[RECORDER] Audio size: ${audioBlob.size} bytes`
                );


                /*
                    Send audio to backend.
                */

                await sendToServer(
                    audioBlob
                );

            }
            catch (error) {

                console.error(
                    "[RECORDER] Error processing recording:",
                    error
                );


                await setRobotState(
                    "LISTENING"
                );

            }

        };


    /*
        Stop MediaRecorder.
    */

    recorder.stop();

}
else {

    console.warn(
        "[RECORDER] Recorder was already inactive"
    );


    await setRobotState(
        "LISTENING"
    );

}


/*
    Stop microphone tracks.
*/

if (stream) {

    stream
        .getTracks()
        .forEach(
            track => track.stop()
        );

    stream = null;

}


/*
    Stop camera frame sending.
*/

if (streamInterval) {

    clearInterval(
        streamInterval
    );

    streamInterval = null;

}


/*
    Re-enable Start Recording button.

    It will remain disabled until processing
    is finished? We enable it here so another
    answer can be started after AI finishes.
*/

StartBtn.disabled = false;

updateRecordingButton(
    "🎙 Start Recording"
);


/*
    Reset stopping flag.

    sendToServer() may still be running,
    but the recording itself has finished.
*/

isStoppingRecording = false;


}


/* ======================================================
STOP RECORDING FLOW (FOR MANUAL STOP)
====================================================== */

async function stopRecordingFlow() {

    /*
        Call the existing stopRecording function.
    */

    await stopRecording();

}

/* ======================================================
START EXPERIENCE
====================================================== */

startButton.addEventListener(
"click",
async () => {


    /*
        User interaction occurred.

        Browser now allows audio playback.
    */

    startButton.disabled = true;


    /*
        Start intro music.
    */

    music.volume = 0.35;


    try {

        await music.play();

    }
    catch (error) {

        console.log(
            "Audio playback error:",
            error
        );

    }


    /*
        Hide start screen.
    */

    startScreen.classList.add(
        "startScreenExit"
    );


    /*
        Show VEERA cinematic intro.
    */

    setTimeout(
        () => {

            startScreen.style.display =
                "none";


            veeraIntro.style.display =
                "block";


            veeraIntro.classList.add(
                "playIntro"
            );

        },
        800
    );


    /*
        Show landing page after intro.
    */

    setTimeout(
        () => {

            veeraIntro.classList.add(
                "introFinished"
            );


            landingPage.style.display =
                "flex";


            setTimeout(
                () => {

                    landingPage.classList.add(
                        "landingVisible"
                    );

                },
                50
            );

        },
        7200
    );

}


);

/* ======================================================
START INTERVIEW RESPONSE
====================================================== */

StartBtn.onclick =
async (event) => {


    event.preventDefault();


    /*
        Prevent duplicate recording.
    */

    if (isRecording) {

        console.log(
            "Already recording."
        );

        return;

    }


    /*
        Reset variables.
    */

    flag = 1;

    audioChunks = [];

    speechDetected = false;

    silenceStartTime = null;

    isStoppingRecording = false;


    /*
        Disable button.
    */

    StartBtn.disabled = true;

    updateRecordingButton(
        "🎙 Starting microphone..."
    );


    /* ==================================================
       START NEW INTERVIEW SESSION
    ================================================== */

    try {

        const response =
            await fetch(
                `${ROBOT_BACKEND}/start-interview`,
                {
                    method: "POST"
                }
            );


        if (!response.ok) {

            console.warn(
                "start-interview returned:",
                response.status
            );

        }
        else {

            console.log(
                "New interview session started"
            );

        }


        /*
            Robot waits for candidate.
        */

        await setRobotState(
            "LISTENING"
        );

    }
    catch (error) {

        console.error(
            "Failed to start interview session:",
            error
        );


        /*
            Still allow recording if robot
            endpoint fails.
        */

    }


    /* ==================================================
       START MICROPHONE
    ================================================== */

    try {

        stream =
            await navigator.mediaDevices.getUserMedia(
                {
                    audio: {
                        echoCancellation: true,
                        noiseSuppression: true,
                        autoGainControl: true
                    }
                }
            );

    }
    catch (error) {

        console.error(
            "Microphone permission/error:",
            error
        );


        StartBtn.disabled = false;

        updateRecordingButton(
            "🎙 Start Recording"
        );


        alert(
            "Unable to access microphone. Please check microphone permission."
        );


        return;

    }


    console.log(
        "Microphone access granted"
    );


    /* ==================================================
       MEDIA RECORDER
    ================================================== */

    let mimeType =
        "audio/webm;codecs=opus";


    /*
        Check whether browser supports
        the preferred format.
    */

    if (
        !MediaRecorder.isTypeSupported(
            mimeType
        )
    ) {

        mimeType =
            "audio/webm";

    }


    if (
        !MediaRecorder.isTypeSupported(
            mimeType
        )
    ) {

        mimeType = "";

    }


    try {

        if (mimeType) {

            recorder =
                new MediaRecorder(
                    stream,
                    {
                        mimeType:
                            mimeType
                    }
                );

        }
        else {

            recorder =
                new MediaRecorder(
                    stream
                );

        }

    }
    catch (error) {

        console.error(
            "MediaRecorder initialization failed:",
            error
        );


        stream
            .getTracks()
            .forEach(
                track => track.stop()
            );


        stream = null;

        StartBtn.disabled = false;

        updateRecordingButton(
            "🎙 Start Recording"
        );

        return;

    }


    /*
        Collect audio chunks.
    */

    recorder.ondataavailable =
        (event) => {

            if (
                event.data &&
                event.data.size > 0
            ) {

                audioChunks.push(
                    event.data
                );

            }

        };


    /*
        Handle recorder errors.
    */

    recorder.onerror =
        (event) => {

            console.error(
                "[RECORDER] Error:",
                event.error
            );

        };


    /*
        Start recording.
    */

    recorder.start(
        250
    );


    isRecording = true;

    recordingStartTime =
        performance.now();


    updateRecordingButton(
        "🎙 Recording... Waiting for speech"
    );


    console.log(
        "================================"
    );

    console.log(
        "RECORDING STARTED"
    );

    console.log(
        "Speak normally."
    );

    console.log(
        "After you stop speaking, wait 3.5 seconds."
    );

    console.log(
        "================================"
    );


    /* ==================================================
       SETUP SILENCE DETECTION
    ================================================== */

    await setupAudioAnalysis(
        stream
    );


    /*
        Start silence detector.
    */

    detectSilence();


    /* ==================================================
       START CAMERA
    ================================================== */

    try {

        Vidstream =
            await navigator.mediaDevices.getUserMedia(
                {
                    video: true
                }
            );


        video.srcObject =
            Vidstream;


        /*
            Wait until video metadata loads.
        */

        await new Promise(
            (resolve) => {

                if (
                    video.readyState >= 2
                ) {

                    resolve();

                }
                else {

                    video.onloadedmetadata =
                        () => {

                            resolve();

                        };

                }

            }
        );


        await video.play();


        console.log(
            "Camera started"
        );

    }
    catch (error) {

        console.error(
            "Camera error:",
            error
        );

    }


    /* ==================================================
       VIDEO FRAME PROCESSING
    ================================================== */

    if (
        video.videoWidth > 0 &&
        video.videoHeight > 0
    ) {

        const canvas =
            document.createElement(
                "canvas"
            );


        const ctx =
            canvas.getContext(
                "2d"
            );


        canvas.width =
            video.videoWidth;


        canvas.height =
            video.videoHeight;


        let sending = false;


        /*
            Send one frame every second.
        */

        streamInterval =
            setInterval(
                () => {

                    if (
                        !isRecording
                    ) {

                        return;

                    }


                    if (sending) {

                        return;

                    }


                    sending = true;


                    ctx.drawImage(
                        video,
                        0,
                        0,
                        canvas.width,
                        canvas.height
                    );


                    canvas.toBlob(
                        async (blob) => {

                            if (!blob) {

                                sending =
                                    false;

                                return;

                            }


                            const formData =
                                new FormData();


                            formData.append(
                                "file",
                                blob,
                                "frame.jpg"
                            );


                            try {

                                await fetch(
                                    `${ROBOT_BACKEND}/video-frame`,
                                    {
                                        method:
                                            "POST",

                                        body:
                                            formData
                                    }
                                );

                            }
                            catch (error) {

                                console.error(
                                    "Failed to send video frame:",
                                    error
                                );

                            }


                            sending =
                                false;

                        },
                        "image/jpeg",
                        0.8
                    );


                },
                1000
            );

    }

};


/* ======================================================
SEND AUDIO TO BACKEND
====================================================== */

async function sendToServer(
audioBlob
) {


try {

    console.log(
        "================================"
    );

    console.log(
        "Sending audio to server..."
    );

    console.log(
        `Audio size: ${audioBlob.size} bytes`
    );

    console.log(
        "================================"
    );


    /*
        Check whether audio is empty.
    */

    if (
        !audioBlob ||
        audioBlob.size === 0
    ) {

        throw new Error(
            "Audio recording is empty."
        );

    }


    const formData =
        new FormData();


    formData.append(
        "audio",
        audioBlob,
        "recording.webm"
    );


    /* ==================================================
       SEND TO /transcribe
    ================================================== */

    const response =
        await fetch(
            `${ROBOT_BACKEND}/transcribe`,
            {
                method: "POST",
                body: formData
            }
        );


    if (!response.ok) {

        throw new Error(
            `Server responded with status: ${response.status}`
        );

    }


    const data =
        await response.json();


    console.log(
        "Interview response:",
        data
    );


    /* ==================================================
       DISPLAY CANDIDATE ANSWER
    ================================================== */

    document.getElementById(
        "text"
    ).innerText =
        data.transcript ||
        "No transcript detected.";


    /* ==================================================
       DISPLAY AI RESPONSE
    ================================================== */

    document.getElementById(
        "Model"
    ).innerText =
        data.model ||
        "No AI response generated.";


    /* ==================================================
       AI SPEECH
    ================================================== */

    if (data.model) {

        /*
            Stop any previous browser speech.
        */

        window.speechSynthesis.cancel();


        const message =
            new SpeechSynthesisUtterance(
                data.model
            );


        /*
            Optional voice settings.
        */

        message.rate = 1.0;

        message.pitch = 1.0;

        message.volume = 1.0;


        /* ==================================================
           SPEECH START
        ================================================== */

        message.onstart =
            () => {

                console.log(
                    "[ROBOT SYNC] AI speaking"
                );


                setRobotState(
                    "SPEAKING"
                );

            };


        /* ==================================================
           SPEECH END
        ================================================== */

        message.onend =
            () => {

                console.log(
                    "[ROBOT SYNC] AI finished speaking"
                );


                setRobotState(
                    "LISTENING"
                );


                /*
                    Candidate can now answer
                    the next question.
                */

                StartBtn.disabled =
                    false;


                updateRecordingButton(
                    "🎙 Start Recording"
                );


                /*
                    Automatically start recording
                    for the next response.
                */

                setTimeout(() => {
                    if (!isRecording && !isStoppingRecording) {
                        console.log("Auto-starting recording for next response");
                        StartBtn.click();
                    }
                }, 500);

            };


        /* ==================================================
           SPEECH ERROR
        ================================================== */

        message.onerror =
            (error) => {

                console.error(
                    "Speech synthesis error:",
                    error
                );


                setRobotState(
                    "LISTENING"
                );


                StartBtn.disabled =
                    false;


                updateRecordingButton(
                    "🎙 Start Recording"
                );


                /*
                    Automatically start recording
                    for the next response.
                */

                setTimeout(() => {
                    if (!isRecording && !isStoppingRecording) {
                        console.log("Auto-starting recording for next response");
                        StartBtn.click();
                    }
                }, 500);

            };


        /*
            Robot enters speaking state.
        */

        await setRobotState(
            "SPEAKING"
        );


        /*
            Start browser speech.
        */

        window.speechSynthesis.speak(
            message
        );

    }
    else {

        /*
            No AI response.
        */

        await setRobotState(
            "LISTENING"
        );


        StartBtn.disabled =
            false;


        updateRecordingButton(
            "🎙 Start Recording"
        );


        /*
            Automatically start recording
            for the next response.
        */

        setTimeout(() => {
            if (!isRecording && !isStoppingRecording) {
                console.log("Auto-starting recording for next response");
                StartBtn.click();
            }
        }, 500);

    }


    console.log(
        "AI response completed"
    );

}
catch (error) {

    console.error(
        "Error sending audio:",
        error
    );


    document.getElementById(
        "Model"
    ).innerText =
        "Error processing response.";


    /*
        Never leave robot stuck
        in THINKING.
    */

    await setRobotState(
        "LISTENING"
    );


    StartBtn.disabled =
        false;


    updateRecordingButton(
        "🎙 Start Recording"
    );


    /*
        Automatically start recording
        for the next response.
    */

    setTimeout(() => {
        if (!isRecording && !isStoppingRecording) {
            console.log("Auto-starting recording for next response");
            StartBtn.click();
        }
    }, 500);

}


/* ======================================================
MANUAL STOP RECORDING
====================================================== */

StopBtn.onclick =
async (event) => {

    event.preventDefault();


    /*
        Only stop if currently recording.
    */

    if (!isRecording) {

        console.log(
            "Not currently recording."
        );

        return;

    }


    console.log(
        "Manual stop recording clicked"
    );


    /*
        Prevent auto-continue after manual stop.
        Set a flag that will persist until
        the next manual start.
    */

    isStoppingRecording = true;


    /*
        Trigger the existing stop recording
        logic.
    */

    await stopRecordingFlow();


    /*
        After manual stop, keep the flag set
        to prevent auto-continue on next AI response.
        The flag will be reset when user manually
        clicks Start again.
    */

};

/* ======================================================
RESUME UPLOAD
====================================================== */

uploadResumeBtn.onclick =
async (event) => {


    event.preventDefault();


    const file =
        resumeUpload.files[0];


    if (!file) {

        uploadStatus.textContent =
            "Please select a PDF file first.";

        uploadStatus.classList.add(
            "error"
        );

        return;

    }


    if (
        file.type !==
        "application/pdf"
    ) {

        uploadStatus.textContent =
            "Please upload a PDF file only.";

        uploadStatus.classList.add(
            "error"
        );

        return;

    }


    const formData =
        new FormData();


    formData.append(
        "resume",
        file
    );


    try {

        uploadStatus.textContent =
            "Uploading resume...";


        uploadStatus.classList.remove(
            "error",
            "success"
        );


        const response =
            await fetch(
                `${ROBOT_BACKEND}/upload-resume`,
                {
                    method: "POST",
                    body: formData
                }
            );


        if (!response.ok) {

            throw new Error(
                `Server responded with status: ${response.status}`
            );

        }


        const data =
            await response.json();


        uploadStatus.textContent =
            data.message ||
            "Resume uploaded successfully!";


        uploadStatus.classList.add(
            "success"
        );


        console.log(
            "Resume uploaded successfully:",
            data
        );

    }
    catch (error) {

        console.error(
            "Error uploading resume:",
            error
        );


        uploadStatus.textContent =
            "Failed to upload resume. Please try again.";


        uploadStatus.classList.add(
            "error"
        );

    }

};


/* ======================================================
STOP ENTIRE INTERVIEW
====================================================== */

StopInt.onclick =
async (event) => {


    event.preventDefault();


    console.log(
        "Stopping entire interview..."
    );


    /*
        Stop browser AI speech.
    */

    window.speechSynthesis.cancel();


    /*
        Stop current recording if active.
    */

    if (
        isRecording &&
        !isStoppingRecording
    ) {

        isRecording = false;

        isStoppingRecording = true;


        /*
            Stop silence detection.
        */

        if (
            silenceAnimationFrame
        ) {

            clearTimeout(
                silenceAnimationFrame
            );

            silenceAnimationFrame =
                null;

        }


        await cleanupAudioAnalysis();


        /*
            Stop recorder without sending
            the incomplete answer.
        */

        if (
            recorder &&
            recorder.state !==
                "inactive"
        ) {

            recorder.ondataavailable =
                null;

            recorder.onstop =
                null;

            recorder.stop();

        }


        /*
            Stop microphone.
        */

        if (stream) {

            stream
                .getTracks()
                .forEach(
                    track =>
                        track.stop()
                );

            stream = null;

        }


        isStoppingRecording =
            false;

    }


    /*
        Stop camera.
    */

    if (video) {

        video.pause();

        video.srcObject =
            null;

    }


    /*
        Stop camera tracks.
    */

    if (Vidstream) {

        Vidstream
            .getTracks()
            .forEach(
                track =>
                    track.stop()
            );

        Vidstream = null;

    }


    /*
        Stop sending frames.
    */

    if (streamInterval) {

        clearInterval(
            streamInterval
        );

        streamInterval = null;

    }


    /*
        Robot goodbye state.
    */

    await setRobotState(
        "GOODBYE"
    );


    /*
        Reset button.
    */

    StartBtn.disabled =
        false;


    updateRecordingButton(
        "🎙 Start Recording"
    );


    console.log(
        "Interview stopped"
    );

};


/* ======================================================
GENERATE REPORT
====================================================== */

generateReportBtn.onclick =
async (event) => {


    event.preventDefault();


    try {

        /*
            Show modal.
        */

        reportModal.classList.add(
            "active"
        );


        reportBody.innerHTML =
            `
            <div class="loading">
                Generating comprehensive interview report...
            </div>
            `;


        /*
            Request report.
        */

        const response =
            await fetch(
                `${ROBOT_BACKEND}/generate-report`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    }
                }
            );


        if (!response.ok) {

            throw new Error(
                `Server responded with status: ${response.status}`
            );

        }


        const data =
            await response.json();


        if (
            data.status ===
            "success"
        ) {

            reportBody.innerHTML =
                formatReport(
                    data.report
                );


            console.log(
                "Report generated successfully"
            );

        }
        else {

            reportBody.innerHTML =
                `
                <div class="error">
                    Error: ${data.message}
                </div>
                `;

        }

    }
    catch (error) {

        console.error(
            "Error generating report:",
            error
        );


        reportBody.innerHTML =
            `
            <div class="error">
                Failed to generate report:
                ${error.message}
            </div>
            `;

    }

};


/* ======================================================
CLOSE REPORT
====================================================== */

closeReportBtn.onclick =
() => {


    reportModal.classList.remove(
        "active"
    );

};


/* ======================================================
DOWNLOAD REPORT
====================================================== */

downloadReportBtn.onclick =
() => {


    const reportContent =
        reportBody.innerText;


    const blob =
        new Blob(
            [reportContent],
            {
                type:
                    "text/plain"
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const a =
        document.createElement(
            "a"
        );


    a.href = url;


    a.download =
        `interview_report_${new Date()
            .toISOString()
            .slice(0, 10)
        }.txt`;


    document.body.appendChild(
        a
    );


    a.click();


    document.body.removeChild(
        a
    );


    URL.revokeObjectURL(
        url
    );

};


/* ======================================================
FORMAT REPORT
====================================================== */

function formatReport(
reportText
) {


let html =
    reportText

        /*
            Headers
        */

        .replace(
            /^### (.*)$/gim,
            "<h3>$1</h3>"
        )

        .replace(
            /^## (.*)$/gim,
            "<h2>$1</h2>"
        )

        .replace(
            /^# (.*)$/gim,
            "<h1>$1</h1>"
        )


        /*
            Bold
        */

        .replace(
            /\*\*(.*?)\*\*/g,
            "<strong>$1</strong>"
        )


        /*
            Lists
        */

        .replace(
            /^- (.*)$/gim,
            "<li>$1</li>"
        )

        .replace(
            /^\d+\. (.*)$/gim,
            "<li>$1</li>"
        );


/*
    Convert table rows.
*/

html =
    html.replace(
        /^\|(.*)\|$/gim,
        function (match) {

            const cells =
                match
                    .split("|")
                    .filter(
                        cell =>
                            cell.trim()
                    );


            if (
                cells.some(
                    cell =>
                        cell
                            .trim()
                            .match(
                                /^-+$/
                            )
                )
            ) {

                return "";

            }


            return (
                "<tr>" +
                cells
                    .map(
                        cell =>
                            `<td>${cell.trim()}</td>`
                    )
                    .join("") +
                "</tr>"
            );

        }
    );


/*
    Line breaks.
*/

html =
    html.replace(
        /\n\n/g,
        "</p><p>"
    );


html =
    html.replace(
        /\n/g,
        "<br>"
    );


/*
    Wrap content.
*/

html =
    "<p>" +
    html +
    "</p>";


/*
    Clean list formatting.
*/

html =
    html.replace(
        /<li>/g,
        "</p><ul><li>"
    );


html =
    html.replace(
        /<\/li>/g,
        "</li></ul><p>"
    );


html =
    html.replace(
        /<p><\/p>/g,
        ""
    );


html =
    html.replace(
        /<p><ul>/g,
        "<ul>"
    );


html =
    html.replace(
        /<\/ul><\/p>/g,
        "</ul>"
    );


/*
    Clean table formatting.
*/

html =
    html.replace(
        /<tr>/g,
        "</p><table><tr>"
    );


html =
    html.replace(
        /<\/tr>/g,
        "</tr></table><p>"
    );


html =
    html.replace(
        /<p><table>/g,
        "<table>"
    );


html =
    html.replace(
        /<\/table><\/p>/g,
        "</table>"
    );


return html;


}}
