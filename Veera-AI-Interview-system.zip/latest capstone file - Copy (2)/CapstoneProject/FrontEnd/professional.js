/* ============================================================
   PROFESSIONAL AI INTERVIEWER SYSTEM
   Connected to FastAPI + Whisper + Gemini + MediaPipe
   ============================================================ */

// ============================================================
// CONFIGURATION
// ============================================================

const BACKEND_URL = "http://127.0.0.1:8000";

// ============================================================
// GLOBAL STATE
// ============================================================

let currentUser = null;
let interviewSession = null;

let isRecording = false;
let isStoppingRecording = false;
let interviewStopped = false;
let isEndingInterview = false;
let isProcessingResponse = false;

let recorder = null;
let audioChunks = [];
let stream = null;

let audioContext = null;
let analyser = null;
let dataArray = null;
let silenceTimer = null;

let Vidstream = null;
let streamInterval = null;

let sessionStartTime = null;
let sessionTimer = null;

let currentQuestion = 1;
let totalQuestions = 5;

let resumeUploaded = false;

// ============================================================
// SILENCE DETECTION
// ============================================================

const DEFAULT_SILENCE_THRESHOLD = 0.015;
const DEFAULT_SILENCE_DURATION = 3500;
const INITIAL_GRACE_PERIOD = 1000;

let speechDetected = false;
let silenceStartTime = null;
let recordingStartTime = 0;

// ============================================================
// DOM ELEMENTS
// ============================================================

// Screens
const loginScreen = document.getElementById("loginScreen");
const dashboardScreen = document.getElementById("dashboardScreen");
const interviewScreen = document.getElementById("interviewScreen");

// Login
const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const rememberMeCheckbox = document.getElementById("rememberMe");
const logoutBtn = document.getElementById("logoutBtn");

// Navigation
const navItems = document.querySelectorAll(".nav-item");
const contentSections = document.querySelectorAll(".content-section");

// Setup
const candidateNameInput = document.getElementById("candidateName");
const candidateEmailInput = document.getElementById("candidateEmail");
const candidatePhoneInput = document.getElementById("candidatePhone");

const companyNameInput = document.getElementById("companyName");
const positionInput = document.getElementById("position");
const experienceSelect = document.getElementById("experience");

const resumeUploadArea = document.getElementById("resumeUploadArea");
const resumeInput = document.getElementById("resumeInput");
const resumePreview = document.getElementById("resumePreview");
const resumeFileName = document.getElementById("resumeFileName");
const removeResumeBtn = document.getElementById("removeResume");

const startInterviewBtn = document.getElementById("startInterviewBtn");
const resetSetupBtn = document.getElementById("resetSetup");

// Interview
const backToDashboardBtn = document.getElementById("backToDashboard");
const endInterviewBtn = document.getElementById("endInterviewBtn");

const interviewTitle = document.getElementById("interviewTitle");
const interviewCompany = document.getElementById("interviewCompany");

const preview = document.getElementById("preview");
const recordingIndicator = document.getElementById("recordingIndicator");

const aiResponse = document.getElementById("aiResponse");
const candidateResponse = document.getElementById("candidateResponse");

const startRecordingBtn = document.getElementById("startRecordingBtn");
const stopRecordingBtn = document.getElementById("stopRecordingBtn");

const sessionDuration = document.getElementById("sessionDuration");
const sessionMode = document.getElementById("sessionMode");

const generateReportBtn = document.getElementById("generateReportBtn");

// Settings
const silenceThresholdInput =
    document.getElementById("silenceThreshold");

const silenceDurationInput =
    document.getElementById("silenceDuration");

const noiseCancellationCheckbox =
    document.getElementById("noiseCancellation");

const enableVideoCheckbox =
    document.getElementById("enableVideo");

const enableExpressionDetectionCheckbox =
    document.getElementById("enableExpressionDetection");

const difficultyLevelSelect =
    document.getElementById("difficultyLevel");

const questionCountInput =
    document.getElementById("questionCount");

// ============================================================
// UTILITY
// ============================================================

function showScreen(screenId) {
    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.remove("active");
    });

    const screen = document.getElementById(screenId);

    if (screen) {
        screen.classList.add("active");
    }
}

function getSelectedInterviewMode() {
    const selected = document.querySelector(
        'input[name="interviewMode"]:checked'
    );

    return selected ? selected.value : "audio";
}

function getSilenceDuration() {
    const value = parseFloat(silenceDurationInput?.value);

    if (isNaN(value)) {
        return DEFAULT_SILENCE_DURATION;
    }

    return value * 1000;
}

function getSilenceThreshold() {
    const value = parseInt(silenceThresholdInput?.value);

    if (isNaN(value)) {
        return DEFAULT_SILENCE_THRESHOLD;
    }

    /*
       Convert UI setting 1-10 into a practical microphone
       volume threshold.

       Lower setting = less sensitive.
       Higher setting = more sensitive.
    */

    return 0.005 + (value * 0.003);
}

// ============================================================
// LOGIN
// ============================================================

if (loginForm) {

    loginForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        const email = emailInput.value.trim();
        const password = passwordInput.value;

        if (!email || !password) {
            alert("Please enter your email and password.");
            return;
        }

        // Email validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }

        // Password validation (minimum 6 characters)
        if (password.length < 6) {
            alert("Password must be at least 6 characters long.");
            return;
        }

        try {
            // Call backend login endpoint
            const response = await fetch(
                `${BACKEND_URL}/login`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                }
            );

            const data = await response.json();

            if (!response.ok || data.status === "error") {
                alert(data.message || "Login failed. Please check your credentials.");
                return;
            }

            // Login successful
            currentUser = data.user;

            if (rememberMeCheckbox.checked) {
                localStorage.setItem(
                    "user",
                    JSON.stringify(currentUser)
                );
            }

            updateUserProfile();

            showScreen("dashboardScreen");

        } catch (error) {
            console.error("[LOGIN] Error:", error);
            alert("Login failed. Please check if the backend is running.");
        }
    });
}

// ============================================================
// USER PROFILE
// ============================================================

function updateUserProfile() {

    const userAvatar =
        document.querySelector(".user-avatar");

    const userName =
        document.querySelector(".user-name");

    const userEmail =
        document.querySelector(".user-email");

    if (!currentUser) return;

    if (userAvatar) {
        userAvatar.textContent = currentUser.initials;
    }

    if (userName) {
        userName.textContent = currentUser.name;
    }

    if (userEmail) {
        userEmail.textContent = currentUser.email;
    }
}

function checkLoggedInUser() {

    const savedUser = localStorage.getItem("user");

    if (!savedUser) {
        showScreen("loginScreen");
        return;
    }

    try {

        currentUser = JSON.parse(savedUser);

        updateUserProfile();

        showScreen("dashboardScreen");

    } catch (error) {

        console.error("Invalid saved user:", error);

        localStorage.removeItem("user");

        showScreen("loginScreen");
    }
}

if (logoutBtn) {

    logoutBtn.addEventListener("click", function () {

        endInterview(false);

        currentUser = null;

        localStorage.removeItem("user");

        showScreen("loginScreen");
    });
}

// ============================================================
// NAVIGATION
// ============================================================

navItems.forEach(item => {

    item.addEventListener("click", function () {

        const targetScreen =
            item.dataset.screen;

        navItems.forEach(nav => {
            nav.classList.remove("active");
        });

        item.classList.add("active");

        contentSections.forEach(section => {
            section.classList.remove("active");
        });

        const target =
            document.getElementById(targetScreen);

        if (target) {
            target.classList.add("active");
        }

        // Load interview history when history section is opened
        if (targetScreen === "history") {
            loadInterviewHistory();
        }
    });
});

// ============================================================
// LOAD INTERVIEW HISTORY
// ============================================================

async function loadInterviewHistory() {
    const historyList = document.getElementById("historyList");

    if (!historyList) {
        return;
    }

    try {
        const response = await fetch(`${BACKEND_URL}/interview-history`);

        if (!response.ok) {
            throw new Error(`Failed to fetch history: ${response.status}`);
        }

        const data = await response.json();

        if (data.status === "success" && data.history && data.history.length > 0) {
            renderInterviewHistory(data.history);
        } else {
            historyList.innerHTML = `
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" width="48" height="48">
                        <path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                    </svg>
                    <p>No interview history yet.</p>
                    <p>Complete an interview to see it here.</p>
                </div>
            `;
        }

    } catch (error) {
        console.error("[HISTORY] Error:", error);
        historyList.innerHTML = `
            <div class="error-state">
                <p>Failed to load interview history.</p>
                <p>Please check if the backend is running.</p>
            </div>
        `;
    }
}

function renderInterviewHistory(history) {
    const historyList = document.getElementById("historyList");

    if (!historyList) {
        return;
    }

    let html = "";

    // Sort by most recent first
    const sortedHistory = [...history].reverse();

    sortedHistory.forEach(interview => {
        const statusClass = interview.status === "completed" ? "completed" : "in-progress";
        const statusText = interview.status === "completed" ? "Completed" : "In Progress";
        const score = interview.score ? `Score: ${interview.score}%` : "Not rated";
        const completedDate = interview.completed_at || interview.start_time;
        const formattedDate = new Date(completedDate).toLocaleDateString("en-US", {
            year: "numeric",
            month: "short",
            day: "numeric"
        });

        html += `
            <div class="history-item">
                <div class="history-icon">
                    <svg viewBox="0 0 24 24" width="24" height="24">
                        <path fill="currentColor" d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                    </svg>
                </div>
                <div class="history-details">
                    <h4>${interview.position} - ${interview.company_name}</h4>
                    <p>${statusText} on ${formattedDate}</p>
                    <div class="history-tags">
                        <span class="tag">${interview.mode.charAt(0).toUpperCase() + interview.mode.slice(1)}</span>
                        <span class="tag ${statusClass}">${statusText}</span>
                        ${interview.status === "completed" ? `<span class="tag score">${score}</span>` : ""}
                    </div>
                </div>
                ${interview.status === "completed" ? `
                    <button class="btn btn-outline" onclick="window.downloadReport('${interview.session_id}')">
                        View Report
                    </button>
                ` : `
                    <button class="btn btn-outline" disabled>
                        In Progress
                    </button>
                `}
            </div>
        `;
    });

    historyList.innerHTML = html;
}

// Make downloadReport globally accessible
window.downloadReport = async function(sessionId) {
    try {
        const response = await fetch(`${BACKEND_URL}/download-report`);
        if (response.ok) {
            const blob = await response.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `interview_report_${sessionId}.pdf`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        } else {
            alert("Report not available for this session.");
        }
    } catch (error) {
        console.error("[DOWNLOAD] Error:", error);
        alert("Failed to download report.");
    }
};

// ============================================================
// RESUME UPLOAD
// ============================================================

if (resumeUploadArea && resumeInput) {

    resumeUploadArea.addEventListener("click", function () {
        resumeInput.click();
    });

    resumeInput.addEventListener("change", function (event) {

        const file = event.target.files[0];

        if (file) {
            handleResumeFile(file);
        }
    });

    resumeUploadArea.addEventListener("dragover", function (event) {

        event.preventDefault();

        resumeUploadArea.style.borderColor =
            "var(--primary)";
    });

    resumeUploadArea.addEventListener("dragleave", function (event) {

        event.preventDefault();

        resumeUploadArea.style.borderColor =
            "var(--border)";
    });

    resumeUploadArea.addEventListener("drop", function (event) {

        event.preventDefault();

        resumeUploadArea.style.borderColor =
            "var(--border)";

        const file = event.dataTransfer.files[0];

        if (file && file.type === "application/pdf") {

            try {
                resumeInput.files =
                    event.dataTransfer.files;
            } catch (error) {
                console.warn(
                    "Could not assign dropped file:",
                    error
                );
            }

            handleResumeFile(file);

        } else {

            alert("Please upload a PDF resume.");
        }
    });
}

function handleResumeFile(file) {

    if (file.type !== "application/pdf") {

        alert("Only PDF resumes are supported.");

        return;
    }

    resumeFileName.textContent = file.name;

    resumeUploadArea.classList.add("hidden");

    resumePreview.classList.remove("hidden");

    resumeUploaded = false;
}

if (removeResumeBtn) {

    removeResumeBtn.addEventListener("click", function (event) {

        event.stopPropagation();

        resumeInput.value = "";

        resumeUploadArea.classList.remove("hidden");

        resumePreview.classList.add("hidden");

        resumeUploaded = false;
    });
}

// ============================================================
// RESET INTERVIEW SETUP
// ============================================================

if (resetSetupBtn) {

    resetSetupBtn.addEventListener("click", function () {

        candidateNameInput.value = "";
        candidateEmailInput.value = "";
        candidatePhoneInput.value = "";

        companyNameInput.value = "";
        positionInput.value = "";

        experienceSelect.value = "";

        resumeInput.value = "";

        resumeUploadArea.classList.remove("hidden");

        resumePreview.classList.add("hidden");

        resumeUploaded = false;

        const audioMode =
            document.querySelector(
                'input[name="interviewMode"][value="audio"]'
            );

        if (audioMode) {
            audioMode.checked = true;
        }
    });
}

// ============================================================
// START INTERVIEW
// ============================================================

if (startInterviewBtn) {

    startInterviewBtn.addEventListener("click", async function () {

        console.log("[UI] Start Interview clicked.");

        const candidateName =
            candidateNameInput.value.trim();

        const candidateEmail =
            candidateEmailInput.value.trim();

        const candidatePhone =
            candidatePhoneInput.value.trim();

        const companyName =
            companyNameInput.value.trim();

        const position =
            positionInput.value.trim();

        const experience =
            experienceSelect.value;

        // Validate candidate name
        if (!candidateName) {
            alert("Please enter your full name.");
            candidateNameInput.focus();
            return;
        }

        if (candidateName.length < 2) {
            alert("Name must be at least 2 characters long.");
            candidateNameInput.focus();
            return;
        }

        // Validate candidate email
        if (!candidateEmail) {
            alert("Please enter your email address.");
            candidateEmailInput.focus();
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(candidateEmail)) {
            alert("Please enter a valid email address.");
            candidateEmailInput.focus();
            return;
        }

        // Validate phone (optional but if provided, validate format)
        if (candidatePhone) {
            const phoneRegex = /^[\d\s\-\+\(\)]+$/;
            if (!phoneRegex.test(candidatePhone)) {
                alert("Please enter a valid phone number.");
                candidatePhoneInput.focus();
                return;
            }
        }

        // Validate company name
        if (!companyName) {
            alert("Please enter a company name.");
            companyNameInput.focus();
            return;
        }

        if (companyName.length < 2) {
            alert("Company name must be at least 2 characters long.");
            companyNameInput.focus();
            return;
        }

        // Validate position
        if (!position) {
            alert("Please enter the position you are applying for.");
            positionInput.focus();
            return;
        }

        if (position.length < 2) {
            alert("Position must be at least 2 characters long.");
            positionInput.focus();
            return;
        }

        // Validate experience level
        if (!experience) {
            alert("Please select your experience level.");
            experienceSelect.focus();
            return;
        }

        const interviewMode =
            getSelectedInterviewMode();

        totalQuestions =
            parseInt(questionCountInput?.value) || 5;

        /*
           Reset interview control flags.
        */

        interviewStopped = false;
        isEndingInterview = false;
        isProcessingResponse = false;
        isStoppingRecording = false;

        currentQuestion = 1;

        interviewSession = {

            candidateName: candidateName,

            candidateEmail: candidateEmail,

            candidatePhone: candidatePhone,

            companyName: companyName,

            position: position,

            experience: experience,

            mode: interviewMode,

            difficulty:
                difficultyLevelSelect?.value || "medium",

            questionCount:
                totalQuestions,

            startTime:
                new Date().toISOString()
        };

        /*
           Update interview screen.
        */

        interviewTitle.textContent =
            `${position} Interview`;

        interviewCompany.textContent =
            companyName;

        sessionMode.textContent =
            interviewMode.charAt(0).toUpperCase() +
            interviewMode.slice(1);

        updateInterviewProgress();

        aiResponse.innerHTML =
            "<p>Preparing your interview...</p>";

        candidateResponse.innerHTML =
            "<p>Your response will appear here...</p>";

        /*
           Disable button while initializing.
        */

        startInterviewBtn.disabled = true;

        try {

            /*
               1. Upload resume
            */

            if (resumeInput.files.length > 0) {

                const uploaded =
                    await uploadResume(
                        resumeInput.files[0]
                    );

                if (!uploaded) {

                    alert(
                        "Resume upload failed. Please check the backend."
                    );

                    return;
                }
            }

            /*
               2. Create backend interview session
            */

            const sessionStarted =
                await startInterviewSession();

            if (!sessionStarted) {

                alert(
                    "Could not start the interview session. Make sure the FastAPI backend is running."
                );

                return;
            }

            /*
               3. Show interview screen
            */

            showScreen("interviewScreen");

            /*
               4. Start timer
            */

            startSessionTimer();

            /*
               5. Start camera
            */

            if (enableVideoCheckbox.checked) {
                await startCamera();
            }


            /*
            6. Robot greets the candidate.
            */

            await setRobotState("GREETING");

            if (interviewStopped || isEndingInterview) {
                return;
            }

            /*
            7. Prepare the initial interviewer message.
            */

            const welcomeMessage =
                `Hello ${interviewSession.candidateName}. ` +
                `Welcome to your ${position} interview for ${companyName}. ` +
                `Please introduce yourself and tell me about your background.`;

            aiResponse.innerHTML =
                `<p>${escapeHtml(welcomeMessage)}</p>`;

            /*
            8. Robot speaks the welcome message.
            */

            await setRobotState("SPEAKING");

            await speakAIResponse(welcomeMessage);

            /*
            9. Start listening only after the welcome speech finishes.
            */

            if (!interviewStopped && !isEndingInterview) {

                await setRobotState("LISTENING");

                setTimeout(() => {

                    if (
                        !interviewStopped &&
                        !isEndingInterview &&
                        !isRecording &&
                        !isProcessingResponse
                    ) {
                        startRecording();
                    }

                }, 700);
            }


        } catch (error) {

            console.error(
                "[UI] Start interview error:",
                error
            );

            alert(
                "Unable to start interview. Check the browser console and FastAPI backend."
            );

        } finally {

            startInterviewBtn.disabled = false;
        }
    });
}

// ============================================================
// UPLOAD RESUME
// ============================================================

async function uploadResume(file) {

    const formData = new FormData();

    formData.append("file", file);

    try {

        const response =
            await fetch(
                `${BACKEND_URL}/upload-resume`,
                {
                    method: "POST",
                    body: formData
                }
            );

        if (!response.ok) {

            console.error(
                "Resume upload failed:",
                response.status
            );

            return false;
        }

        console.log(
            "[UI] Resume uploaded successfully."
        );

        resumeUploaded = true;

        return true;

    } catch (error) {

        console.error(
            "[UI] Resume upload error:",
            error
        );

        return false;
    }
}

// ============================================================
// START BACKEND INTERVIEW SESSION
// ============================================================

async function startInterviewSession() {

    try {

        const response =
            await fetch(
                `${BACKEND_URL}/start-interview`,
                {
                    method: "POST",
                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({
                        companyName:
                            interviewSession.companyName,

                        position:
                            interviewSession.position,

                        experience:
                            interviewSession.experience,

                        mode:
                            interviewSession.mode,

                        difficulty:
                            interviewSession.difficulty,

                        questionCount:
                            interviewSession.questionCount,

                        startTime:
                            interviewSession.startTime
                    })
                }
            );

        if (!response.ok) {

            console.error(
                "[UI] /start-interview failed:",
                response.status
            );

            return false;
        }

        const data =
            await response.json();

        console.log(
            "[UI] Backend interview session started:",
            data
        );

        return true;

    } catch (error) {

        console.error(
            "[UI] Could not connect to backend:",
            error
        );

        return false;
    }
}

// ============================================================
// CAMERA
// ============================================================

async function startCamera() {

    try {

        Vidstream =
            await navigator.mediaDevices.getUserMedia({
                video: true
            });

        preview.srcObject =
            Vidstream;

        await preview.play();

        /*
           Wait until dimensions are available.
        */

        if (
            preview.videoWidth === 0 ||
            preview.videoHeight === 0
        ) {

            await new Promise(resolve => {

                preview.onloadedmetadata =
                    resolve;

            });
        }

        if (
            enableExpressionDetectionCheckbox.checked
        ) {
            startVideoFrameSending();
        }

    } catch (error) {

        console.error(
            "[UI] Camera error:",
            error
        );

        alert(
            "Camera could not be accessed. You can continue without camera analysis."
        );
    }
}

// ============================================================
// VIDEO FRAME SENDING
// ============================================================

function startVideoFrameSending() {

    if (streamInterval) {
        clearInterval(streamInterval);
    }

    const canvas =
        document.createElement("canvas");

    const ctx =
        canvas.getContext("2d");

    let sending = false;

    streamInterval =
        setInterval(() => {

            if (
                sending ||
                !Vidstream ||
                preview.videoWidth === 0
            ) {
                return;
            }

            sending = true;

            canvas.width =
                preview.videoWidth;

            canvas.height =
                preview.videoHeight;

            ctx.drawImage(
                preview,
                0,
                0,
                canvas.width,
                canvas.height
            );

            canvas.toBlob(
                async function (blob) {

                    if (!blob) {

                        sending = false;

                        return;
                    }

                    const formData =
                        new FormData();

                    formData.append(
                        "file",
                        blob,
                        "frame.jpg"
                    );

                    try {

                        await fetch(
                            `${BACKEND_URL}/video-frame`,
                            {
                                method: "POST",
                                body: formData
                            }
                        );

                    } catch (error) {

                        console.error(
                            "[UI] Failed to send video frame:",
                            error
                        );
                    }

                    sending = false;

                },
                "image/jpeg",
                0.7
            );

        }, 1000);
}

// ============================================================
// SESSION TIMER
// ============================================================

function startSessionTimer() {

    if (sessionTimer) {
        clearInterval(sessionTimer);
    }

    sessionStartTime =
        Date.now();

    sessionTimer =
        setInterval(() => {

            if (!sessionStartTime) {
                return;
            }

            const elapsed =
                Date.now() -
                sessionStartTime;

            const hours =
                Math.floor(
                    elapsed / 3600000
                );

            const minutes =
                Math.floor(
                    (elapsed % 3600000) /
                    60000
                );

            const seconds =
                Math.floor(
                    (elapsed % 60000) /
                    1000
                );

            sessionDuration.textContent =
                `${String(hours).padStart(2, "0")}:` +
                `${String(minutes).padStart(2, "0")}:` +
                `${String(seconds).padStart(2, "0")}`;

        }, 1000);
}

// ============================================================
// PROGRESS
// ============================================================

function updateInterviewProgress() {

    const progressFill =
        document.querySelector(".progress-fill");

    const progressText =
        document.querySelector(
            ".sidebar-section p"
        );

    if (!progressFill) {
        return;
    }

    const percentage =
        Math.min(
            100,
            (currentQuestion /
                totalQuestions) *
                100
        );

    progressFill.style.width =
        `${percentage}%`;

    if (progressText) {

        progressText.textContent =
            `Question ${Math.min(
                currentQuestion,
                totalQuestions
            )} of ${totalQuestions}`;
    }
}

// ============================================================
// RECORDING
// ============================================================

if (startRecordingBtn) {

    startRecordingBtn.addEventListener(
        "click",
        function () {
            startRecording();
        }
    );
}

async function startRecording() {

    if (isRecording) {
        return;
    }

    if (interviewStopped || isEndingInterview) {
        console.log(
            "[UI] Recording blocked because interview has ended."
        );

        return;
    }

    if (isProcessingResponse) {

        console.log(
            "[UI] Waiting for previous response."
        );

        return;
    }

    try {

        console.log(
            "[UI] Starting microphone..."
        );

        stream =
            await navigator.mediaDevices.getUserMedia({

                audio: {

                    echoCancellation:
                        noiseCancellationCheckbox.checked,

                    noiseSuppression:
                        noiseCancellationCheckbox.checked,

                    autoGainControl:
                        true
                }
            });

        recorder =
            new MediaRecorder(
                stream,
                {
                    mimeType: "audio/webm"
                }
            );

        audioChunks = [];

        recorder.ondataavailable =
            function (event) {

                if (event.data.size > 0) {
                    audioChunks.push(event.data);
                }
            };

        recorder.onerror =
            function (event) {

                console.error(
                    "[UI] MediaRecorder error:",
                    event
                );
            };

        recorder.onstop =
            async function () {

                const audioBlob =
                    new Blob(
                        audioChunks,
                        {
                            type: "audio/webm"
                        }
                    );

                /*
                   Release microphone before processing.
                */

                if (stream) {

                    stream
                        .getTracks()
                        .forEach(track =>
                            track.stop()
                        );

                    stream = null;
                }

                await sendAudioToServer(
                    audioBlob
                );
            };

        recorder.start();

        isRecording = true;
        isStoppingRecording = false;

        recordingStartTime =
            Date.now();

        speechDetected = false;
        silenceStartTime = null;

        
        startRecordingBtn.disabled = true;
        stopRecordingBtn.disabled = true;

        recordingIndicator.classList.remove("hidden");

        // Confirm the listening state before allowing Stop Recording.
        await setRobotState("LISTENING");

        if (isRecording && !interviewStopped && !isEndingInterview) {
            stopRecordingBtn.disabled = false;
            setupSilenceDetection();
        }


        console.log(
            "[UI] Recording started."
        );

    } catch (error) {

        console.error(
            "[UI] Microphone error:",
            error
        );

        alert(
            "Unable to access microphone. Please check microphone permissions."
        );
    }
}

// ============================================================
// STOP RECORDING BUTTON
// ============================================================



if (stopRecordingBtn) {
    stopRecordingBtn.addEventListener(
        "click",
        async function () {

            if (!isRecording || isStoppingRecording) {
                return;
            }

            // Prevent repeated clicks.
            isStoppingRecording = true;

            // Request THINKING immediately.
            // Do not wait for the backend response.
            void setRobotState("THINKING");

            // Stop recording and continue normal processing.
            // Do NOT set isRecording = false here:
            // stopRecording() needs its current value.
            await stopRecording();
        }
    );
}



// ============================================================
// STOP RECORDING
// ============================================================

async function stopRecording() {

    if (!isRecording) {
        return;
    }

    console.log(
        "[UI] Stopping recording..."
    );

    isRecording = false;

    if (silenceTimer) {

        clearTimeout(
            silenceTimer
        );

        silenceTimer = null;
    }

    if (audioContext) {

        try {
            await audioContext.close();
        } catch (error) {
            console.warn(
                "AudioContext close error:",
                error
            );
        }

        audioContext = null;
    }

    if (
        recorder &&
        recorder.state !== "inactive"
    ) {

        recorder.stop();
    }

    startRecordingBtn.disabled = true;
    stopRecordingBtn.disabled = true;

    recordingIndicator.classList.add(
        "hidden"
    );

    console.log(
        "[UI] Recording stopped."
    );
}

// ============================================================
// SILENCE DETECTION
// ============================================================

function setupSilenceDetection() {

    if (!stream) {
        return;
    }

    try {

        audioContext =
            new (
                window.AudioContext ||
                window.webkitAudioContext
            )();

        const source =
            audioContext.createMediaStreamSource(
                stream
            );

        analyser =
            audioContext.createAnalyser();

        analyser.fftSize = 256;

        source.connect(analyser);

        dataArray =
            new Uint8Array(
                analyser.frequencyBinCount
            );

        detectSilence();

    } catch (error) {

        console.error(
            "[UI] Silence detection error:",
            error
        );
    }
}

function detectSilence() {

    if (!isRecording) {
        return;
    }

    if (!analyser) {
        return;
    }

    analyser.getByteFrequencyData(
        dataArray
    );

    let sum = 0;

    for (
        let i = 0;
        i < dataArray.length;
        i++
    ) {

        sum +=
            dataArray[i] *
            dataArray[i];
    }

    const rms =
        Math.sqrt(
            sum / dataArray.length
        );

    const normalizedVolume =
        rms / 255;

    const elapsed =
        Date.now() -
        recordingStartTime;

    const threshold =
        getSilenceThreshold();

    if (
        normalizedVolume <
        threshold
    ) {

        if (
            speechDetected ||
            elapsed >
            INITIAL_GRACE_PERIOD
        ) {

            if (!silenceStartTime) {

                silenceStartTime =
                    Date.now();

            } else if (
                Date.now() -
                silenceStartTime >=
                getSilenceDuration()
            ) {

                console.log(
                    "[UI] Silence detected."
                );

                /*
                   Automatic stop.
                */

                isStoppingRecording = false;

                stopRecording();

                return;
            }
        }

    } else {

        speechDetected = true;

        silenceStartTime = null;
    }

    requestAnimationFrame(
        detectSilence
    );
}

// ============================================================
// SEND AUDIO TO FASTAPI
// ============================================================

async function sendAudioToServer(
    audioBlob
) {

    if (
        !audioBlob ||
        audioBlob.size === 0
    ) {

        console.warn(
            "[UI] Empty audio blob."
        );

        startRecordingBtn.disabled = false;

        if (
            !interviewStopped &&
            !isEndingInterview
        ) {
            setTimeout(
                () => startRecording(),
                500
            );
        }

        return;
    }

    isProcessingResponse = true;

    await setRobotState("THINKING");

    candidateResponse.innerHTML =
        "<p>Processing your response...</p>";

    aiResponse.innerHTML =
        "<p>AI is thinking...</p>";

    try {

        const formData =
            new FormData();

        formData.append(
            "audio",
            audioBlob,
            "recording.webm"
        );

        console.log(
            "[UI] Sending audio to /transcribe..."
        );

        const response =
            await fetch(
                `${BACKEND_URL}/transcribe`,
                {
                    method: "POST",
                    body: formData
                }
            );

        if (!response.ok) {

            throw new Error(
                `Transcription request failed: ${response.status}`
            );
        }

        const data =
            await response.json();

        console.log(
            "[UI] Transcription response:",
            data
        );

        /*
           Candidate response.
        */

        const transcript =
            data.transcript || "";

        candidateResponse.innerHTML =
            `<p>${escapeHtml(
                transcript ||
                "No speech detected."
            )}</p>`;

        /*
           AI response.
        */

        const modelResponse =
            data.model || "";

        if (!modelResponse) {

            aiResponse.innerHTML =
                "<p>The interviewer did not return a response.</p>";

        } else {

            aiResponse.innerHTML =
                `<p>${escapeHtml(
                    modelResponse
                )}</p>`;
        }

        /*
           Move to next question.
        */

        currentQuestion++;

        updateInterviewProgress();

        /*
           Speak AI response.

           IMPORTANT:
           We wait until SpeechSynthesis finishes
           BEFORE starting microphone recording.
        */

        if (
            modelResponse &&
            !interviewStopped &&
            !isEndingInterview
        ) {

            await setRobotState(
                "SPEAKING"
            );

            await speakAIResponse(
                modelResponse
            );
        }

        /*
           Start next candidate recording.
        */

        if (
            !interviewStopped &&
            !isEndingInterview &&
            currentQuestion <= totalQuestions
        ) {

            await setRobotState(
                "LISTENING"
            );

            await new Promise(
                resolve =>
                    setTimeout(
                        resolve,
                        700
                    )
            );

            if (
                !interviewStopped &&
                !isEndingInterview &&
                !isRecording
            ) {

                startRecording();
            }

        } else if (
            currentQuestion > totalQuestions
        ) {

            await setRobotState(
                "GOODBYE"
            );

            aiResponse.innerHTML +=
                "<p><strong>Interview completed.</strong></p>";
        }

    } catch (error) {

        console.error(
            "[UI] Error processing audio:",
            error
        );

        aiResponse.innerHTML =
            "<p>Error processing the interview response. Please check the backend.</p>";

        /*
           Do NOT automatically restart if an
           actual backend error occurred.
        */

    } finally {

        isProcessingResponse = false;

        startRecordingBtn.disabled =
            interviewStopped ||
            isEndingInterview;
    }
}

// ============================================================
// AI SPEECH
// ============================================================

function speakAIResponse(text) {

    return new Promise(resolve => {

        if (
            !text ||
            !("speechSynthesis" in window)
        ) {

            resolve();

            return;
        }

        /*
           Stop any previous browser speech.
        */

        window.speechSynthesis.cancel();

        const message =
            new SpeechSynthesisUtterance(
                text
            );

        message.rate = 1.0;
        message.pitch = 1.0;
        message.volume = 1.0;

        message.onstart =
            function () {

                console.log(
                    "[TTS] AI speech started."
                );
            };

        message.onend =
            function () {

                console.log(
                    "[TTS] AI speech finished."
                );

                resolve();
            };

        message.onerror =
            function (event) {

                console.error(
                    "[TTS] Speech error:",
                    event
                );

                resolve();
            };

        window.speechSynthesis.speak(
            message
        );
    });
}

// ============================================================
// ROBOT STATE
// ============================================================

async function setRobotState(state) {

    try {

        await fetch(
            `${BACKEND_URL}/robot/state`,
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify({
                    state: state
                })
            }
        );

    } catch (error) {

        /*
           Robot failure should NOT break
           the interview.
        */

        console.warn(
            "[ROBOT] State update failed:",
            state,
            error
        );
    }
}

// ============================================================
// END INTERVIEW
// ============================================================

if (backToDashboardBtn) {

    backToDashboardBtn.addEventListener(
        "click",
        function () {

            if (
                confirm(
                    "Are you sure you want to exit the interview? Your progress will be lost."
                )
            ) {

                endInterview(true);
            }
        }
    );
}

if (endInterviewBtn) {

    endInterviewBtn.addEventListener(
        "click",
        function () {

            if (
                confirm(
                    "Are you sure you want to end the interview?"
                )
            ) {

                endInterview(true);
            }
        }
    );
}

function endInterview(
    returnToDashboard = true
) {

    console.log(
        "[UI] Ending interview..."
    );

    /*
       VERY IMPORTANT:
       Set this FIRST so asynchronous
       callbacks cannot restart recording.
    */

    interviewStopped = true;

    isEndingInterview = true;

    isProcessingResponse = false;

    /*
       Stop browser speech.
    */

    if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
    }

    /*
       Stop microphone.
    */

    if (isRecording) {

        isStoppingRecording = true;

        stopRecording();
    }

    /*
       Stop camera.
    */

    if (Vidstream) {

        Vidstream
            .getTracks()
            .forEach(track =>
                track.stop()
            );

        Vidstream = null;
    }

    if (preview) {
        preview.srcObject = null;
    }

    /*
       Stop video frame sending.
    */

    if (streamInterval) {

        clearInterval(
            streamInterval
        );

        streamInterval = null;
    }

    /*
       Stop session timer.
    */

    if (sessionTimer) {

        clearInterval(
            sessionTimer
        );

        sessionTimer = null;
    }

    sessionStartTime = null;

    /*
       Tell robot.
    */

    setRobotState("GOODBYE");

    /*
       Reset controls.
    */

    startRecordingBtn.disabled = false;
    stopRecordingBtn.disabled = true;

    recordingIndicator.classList.add(
        "hidden"
    );

    /*
       Clear interview object.
    */

    interviewSession = null;

    if (returnToDashboard) {

        showScreen(
            "dashboardScreen"
        );
    }
}

// ============================================================
// GENERATE REPORT
// ============================================================

if (generateReportBtn) {

    generateReportBtn.addEventListener(
        "click",
        async function () {

            try {

                generateReportBtn.disabled =
                    true;

                generateReportBtn.textContent =
                    "Generating...";

                const response =
                    await fetch(
                        `${BACKEND_URL}/generate-report`,
                        {
                            method: "POST",
                            headers: {
                                "Content-Type":
                                    "application/json"
                            }
                        }
                    );

                if (!response.ok) {

                    throw new Error(
                        `Report generation failed: ${response.status}`
                    );
                }

                const data =
                    await response.json();

                console.log(
                    "[REPORT]",
                    data
                );

                // Check if PDF report URL is available
                if (data.pdf_report_url) {
                    // Download the PDF report
                    const pdfResponse = await fetch(`${BACKEND_URL}${data.pdf_report_url}`);
                    if (pdfResponse.ok) {
                        const blob = await pdfResponse.blob();
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = `interview_report_${new Date().toISOString().slice(0, 10)}.pdf`;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);

                        alert("Report generated and downloaded successfully!");
                    } else {
                        alert("Report generated but download failed. Please try again.");
                    }
                } else {
                    alert("Report generated successfully!");
                }

            } catch (error) {

                console.error(
                    "[REPORT] Error:",
                    error
                );

                alert(
                    "Error generating report. Please check the backend."
                );

            } finally {

                generateReportBtn.disabled =
                    false;

                generateReportBtn.innerHTML =
                    `
                    <svg viewBox="0 0 24 24" width="20" height="20">
                        <path fill="currentColor"
                        d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                    </svg>
                    Generate Report
                    `;
            }
        }
    );
}

// ============================================================
// SETTINGS
// ============================================================

if (silenceThresholdInput) {

    silenceThresholdInput.addEventListener(
        "input",
        function (event) {

            const value =
                parseInt(
                    event.target.value
                );

            const labels = [
                "Very Low",
                "Low",
                "Medium",
                "High",
                "Very High"
            ];

            /*
               Map 1-10 to five labels.
            */

            const index =
                Math.min(
                    4,
                    Math.floor(
                        (value - 1) / 2
                    )
                );

            const label =
                event.target.nextElementSibling;

            if (label) {

                label.textContent =
                    labels[index];
            }
        }
    );
}

// ============================================================
// HELPER: ESCAPE HTML
// ============================================================

function escapeHtml(value) {

    const div =
        document.createElement("div");

    div.textContent =
        value ?? "";

    return div.innerHTML;
}

// ============================================================
// INITIALIZATION
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        console.log(
            "========================================"
        );

        console.log(
            "InterviewAI Pro Frontend Loaded"
        );

        console.log(
            "Backend:",
            BACKEND_URL
        );

        console.log(
            "========================================"
        );

        checkLoggedInUser();

        // Load interview history if history section is initially active
        const historySection = document.getElementById("history");
        if (historySection && historySection.classList.contains("active")) {
            loadInterviewHistory();
        }

        if (stopRecordingBtn) {
            stopRecordingBtn.disabled = true;
        }

        if (generateReportBtn) {
            console.log(
                "[UI] Report button initialized."
            );
        }

        // Initialize report button in Reports section
        const reportsGenerateBtn =
            document.querySelector(
                '#reports .report-card:first-child .btn-primary'
            );

        if (reportsGenerateBtn) {
            reportsGenerateBtn.addEventListener(
                "click",
                async function () {

                    try {

                        reportsGenerateBtn.disabled =
                            true;

                        reportsGenerateBtn.textContent =
                            "Generating...";

                        const response =
                            await fetch(
                                `${BACKEND_URL}/generate-report`,
                                {
                                    method: "POST",
                                    headers: {
                                        "Content-Type":
                                            "application/json"
                                    }
                                }
                            );

                        if (!response.ok) {

                            throw new Error(
                                `Report generation failed: ${response.status}`
                            );
                        }

                        const data =
                            await response.json();

                        console.log(
                            "[REPORT]",
                            data
                        );

                        // Check if PDF report URL is available
                        if (data.pdf_report_url) {
                            // Download the PDF report
                            const pdfResponse = await fetch(`${BACKEND_URL}${data.pdf_report_url}`);
                            if (pdfResponse.ok) {
                                const blob = await pdfResponse.blob();
                                const url = URL.createObjectURL(blob);
                                const a = document.createElement("a");
                                a.href = url;
                                a.download = `interview_report_${new Date().toISOString().slice(0, 10)}.pdf`;
                                document.body.appendChild(a);
                                a.click();
                                document.body.removeChild(a);
                                URL.revokeObjectURL(url);

                                alert("Report generated and downloaded successfully!");
                            } else {
                                alert("Report generated but download failed. Please try again.");
                            }
                        } else {
                            alert("Report generated successfully!");
                        }

                    } catch (error) {

                        console.error(
                            "[REPORT] Error:",
                            error
                        );

                        alert(
                            "Error generating report. Please check the backend."
                        );

                    } finally {

                        reportsGenerateBtn.disabled =
                            false;

                        reportsGenerateBtn.innerHTML =
                            `
                            <svg viewBox="0 0 24 24" width="20" height="20">
                                <path fill="currentColor"
                                d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                            </svg>
                            Generate Report
                            `;
                    }
                }
            );
        }
    }
);