# Robot Face Display

This display shows the robot's facial expression in real-time based on the current robot state from the backend.

## 📱 HOW TO USE

### Option 1: Same Computer (Local)

1. **Start the Python backend:**
   ```bash
   cd BackEnd
   python FinalBackend.py
   ```

2. **Open the display in your browser:**
   - Navigate to: `FrontEnd/robot-face/display.html`
   - Open it in your browser (double-click or drag to browser)
   - Or use: `file:///C:/Users/Sumedh/OneDrive/Desktop/CapstoneProject/FrontEnd/robot-face/display.html`

### Option 2: Different Device (Phone/Tablet on Same Network)

1. **Find your computer's IP address:**
   - Windows: Open Command Prompt and run `ipconfig`
   - Look for "IPv4 Address" (e.g., 192.168.1.100)

2. **Update the BACKEND_URL in display.html:**
   - Open `display.html` in a text editor
   - Find line ~52: `const BACKEND_URL = 'http://127.0.0.1:8000';`
   - Change to: `const BACKEND_URL = 'http://192.168.1.100:8000';` (use your actual IP)

3. **Serve the display.html file:**
   You need to serve the HTML file so your phone can access it. Options:

   **Option A: Use Python Simple HTTP Server**
   ```bash
   cd FrontEnd/robot-face
   python -m http.server 8080
   ```

   **Option B: Use VS Code Live Server**
   - Right-click on `display.html`
   - Select "Open with Live Server"
   - Note the port (usually 5500 or 5501)

4. **Access from your phone:**
   - Ensure phone is on the same WiFi network
   - Open browser on phone
   - Go to: `http://192.168.1.100:8080/display.html` (adjust IP and port)

## 🎨 ROBOT STATES

The display automatically updates based on the robot's current state:

| State | Description | Visual |
|-------|-------------|--------|
| IDLE | Robot waiting, subtle movement | Eyes normal, slight idle animation |
| LISTENING | Robot listening to candidate | Eyes attentive, listening expression |
| THINKING | Robot processing answer | Eyes thoughtful, processing animation |
| SPEAKING | Robot speaking response | Mouth movement, conversational expression |
| GREETING | Robot welcoming candidate | Welcoming facial expression |
| GOODBYE | Robot saying farewell | Farewell facial expression |

## 📊 STATUS BAR

The top of the display shows:
- **Connection status:** Green = connected, Red = disconnected, Yellow = connecting
- **Current state:** Shows the robot's current state
- **Connection status:** Shows if backend is connected

## ⚙️ CONFIGURATION

### Change Polling Frequency

By default, the display polls the backend every 200ms (5 times per second). To change this:

1. Open `display.html`
2. Find line ~55: `const POLL_INTERVAL = 200;`
3. Change to desired value in milliseconds:
   - 100 = 10 times per second (smoother, more CPU)
   - 500 = 2 times per second (less smooth, less CPU)
   - 1000 = 1 time per second (minimal CPU)

### Change Backend URL

If your backend is on a different computer or port:

1. Open `display.html`
2. Find line ~52: `const BACKEND_URL = 'http://127.0.0.1:8000';`
3. Change to your backend URL

## 🔧 TROUBLESHOOTING

### Display shows "Disconnected"

1. **Check backend is running:**
   - Verify Python backend is running
   - Check it's on port 8000

2. **Check network connection:**
   - If using different device, ensure same WiFi network
   - Verify IP address is correct
   - Check firewall settings

3. **Check CORS:**
   - The backend should allow all origins (already configured)
   - If you modified CORS, ensure it allows your device

### Display not updating

1. **Check browser console:**
   - Press F12 to open developer tools
   - Check Console tab for errors
   - Check Network tab for failed requests

2. **Verify endpoint:**
   - Test endpoint directly: `http://127.0.0.1:8000/robot-state`
   - Should return JSON with current state

3. **Check polling:**
   - Open Network tab in browser dev tools
   - Look for requests to `/robot-state`
   - Verify they're succeeding

### Face animations not working

1. **Check CSS file:**
   - Ensure `style.css` is in the same directory
   - Verify CSS classes are defined

2. **Check browser compatibility:**
   - Use modern browser (Chrome, Firefox, Safari, Edge)
   - Update browser if needed

## 📱 MOBILE OPTIMIZATION

The display is optimized for mobile:
- Full-screen display
- Large robot face
- Minimal UI
- Touch-friendly

### Full-Screen on Mobile

To make it truly full-screen:
- **iOS:** Add to Home Screen, then open from home screen
- **Android:** Use "Add to Home Screen" option in browser menu

## 🎯 INTEGRATION WITH INTERVIEW

The display automatically syncs with the interview flow:

1. **Interview starts:** Robot shows GREETING
2. **AI asks question:** Robot shows SPEAKING
3. **Candidate answers:** Robot shows LISTENING
4. **AI processes:** Robot shows THINKING
5. **AI responds:** Robot shows SPEAKING
6. **Interview ends:** Robot shows GOODBYE
7. **Waiting:** Robot shows IDLE

## 📝 FILES

- `display.html` - Main display file (auto-updating)
- `index.html` - Manual control version (for testing)
- `script.js` - JavaScript for manual control
- `style.css` - CSS animations and styling

## 🚀 USAGE EXAMPLE

**For a real interview setup:**

1. Computer 1: Running Python backend + interview frontend
2. Computer 2 (or tablet): Showing robot-face display
3. Physical robot: With servo motor

This creates a complete multi-modal AI interviewer:
- **Physical movement:** Servo head movements
- **Visual expression:** Robot face on screen
- **Voice interaction:** TTS and speech recognition

## 🔒 SECURITY NOTES

- The backend currently allows all origins (`allow_origins=["*"]`)
- For production, restrict to specific origins
- Use HTTPS if deploying over internet
- Consider authentication for robot-face endpoint
