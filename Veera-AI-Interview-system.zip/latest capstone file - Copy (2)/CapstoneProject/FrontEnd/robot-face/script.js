const robotFace = document.getElementById("robot-face");

if (!robotFace) {
    console.error("ERROR: #robot-face was not found in index.html");
}

function setRobotState(state) {

    console.log("Robot State:", state);

    if (!robotFace) {
        console.error("Cannot change robot state because #robot-face does not exist.");
        return;
    }

    state = state.toUpperCase();

    robotFace.classList.remove(
        "idle",
        "listening",
        "thinking",
        "speaking",
        "greeting",
        "goodbye"
    );

    switch (state) {

        case "IDLE":
            robotFace.classList.add("idle");
            break;

        case "LISTENING":
            robotFace.classList.add("listening");
            break;

        case "THINKING":
            robotFace.classList.add("thinking");
            break;

        case "SPEAKING":
            robotFace.classList.add("speaking");
            break;

        case "GREETING":
            robotFace.classList.add("greeting");
            break;

        case "GOODBYE":
            robotFace.classList.add("goodbye");
            break;

        default:
            console.warn("Unknown robot state:", state);
            robotFace.classList.add("idle");
    }
}

setRobotState("IDLE");