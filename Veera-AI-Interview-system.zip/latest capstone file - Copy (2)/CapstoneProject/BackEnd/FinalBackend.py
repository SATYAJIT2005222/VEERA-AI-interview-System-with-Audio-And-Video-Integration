# ============================================================
# FINAL BACKEND - VOICE BASED AI INTERVIEWER
# ============================================================

from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

from contextlib import asynccontextmanager

import pdfplumber
import os
import asyncio
import uuid
import json
import time
import hashlib
import threading

import cv2
import numpy as np
import mediapipe as mp

from google.adk.agents import LlmAgent
from google.adk.models.google_llm import Gemini
from google.adk.sessions import InMemorySessionService
from google.adk.runners import Runner
from google.genai import types

from mediapipe.tasks import python
from mediapipe.tasks.python import vision

from interview_event_detector1 import analyze_expressions
from interview_report_generator import generate_interview_report

import whisper
import requests  # For WiFi communication with ESP32

# Optional legacy serial mode (used only when USE_WIFI=false).
try:
    import serial
except ImportError:
    serial = None

import pyttsx3


GOOGLE_API_KEY = "AQ.Ab8RN6KsFdoZj_CiRKExRyTTFkNkyTCmjbpMifG_1gq2rPmGRw"
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# ============================================================
# CONFIGURATION
# ============================================================

# ESP32 Serial Configuration (Legacy - for serial communication)
ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
ESP32_BAUD = 115200

# ESP32 WiFi Configuration (New - for wireless communication)
ESP32_IP = os.getenv("ESP32_IP", "10.61.133.200")  # ESP32's IP address
ESP32_PORT_HTTP = 80  # HTTP server port on ESP32
USE_WIFI = os.getenv("USE_WIFI", "true").lower() == "true"  # Set to "true" to use WiFi

APP_NAME = "InterviewApp"
USER_ID = "demo_candidate"

CURRENT_SESSION_ID = None

# Prevent two /transcribe requests from being processed together.
transcribe_lock = asyncio.Lock()

# Duplicate request protection.
LAST_AUDIO_HASH = None
LAST_MODEL_RESPONSE = None

# ============================================================
# FILE PATHS
# ============================================================

# Keep every backend-generated file in the existing Outsiders data folder.
# This preserves the location used by the earlier backend version.
BASE_DIR = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders"
os.makedirs(BASE_DIR, exist_ok=True)

RESUME_PATH = os.path.join(BASE_DIR, "uploaded_resume.pdf")
AUDIO_PATH = os.path.join(BASE_DIR, "recording.webm")
CONVERSATION_PATH = os.path.join(BASE_DIR, "conversation.json")
EXPRESSIONS_PATH = os.path.join(BASE_DIR, "expressions.log")
EVENTS_PATH = os.path.join(BASE_DIR, "events.json")
COMPRESSED_EVENTS_PATH = os.path.join(BASE_DIR, "compressed_events.json")

# Video telemetry and generated report artifacts.
MODEL_PATH = os.path.join(BASE_DIR, "face_landmarker.task")
INTERVIEW_LOG_PATH = os.path.join(BASE_DIR, "interview_log.json")
REPORT_PDF_PATH = os.path.join(BASE_DIR, "comprehensive_interview_report.pdf")

# The detector is created lazily so a missing model file does not prevent
# the API and robot endpoints from starting. Video processing initializes it
# when the first frame arrives.
face_landmarker = None
face_landmarker_lock = threading.Lock()
telemetry_lock = threading.Lock()
VIDEO_TIMELINE = []
INTERVIEW_STARTED_AT = None
BLINK_COUNT = 0
BLINK_STATE = False


# ============================================================
# VIDEO TELEMETRY HELPERS (MediaPipe Tasks Face Landmarker)
# ============================================================

# Landmark indices from the supplied reference implementation.
LIP_TOP, LIP_BOTTOM = 13, 14
LIP_LEFT, LIP_RIGHT = 61, 291
LEFT_IRIS = [468, 469, 470, 471]
LEFT_EYE_INNER, LEFT_EYE_OUTER = 133, 33
L_EYE_TOP, L_EYE_BOTTOM = 159, 145
R_EYE_TOP, R_EYE_BOTTOM = 386, 374
L_EYE_LEFT, L_EYE_RIGHT = 33, 133
R_EYE_LEFT, R_EYE_RIGHT = 362, 263


def _get_face_landmarker():
    """Create and cache the MediaPipe detector when the model is available."""
    global face_landmarker
    with face_landmarker_lock:
        if face_landmarker is not None:
            return face_landmarker
        if not os.path.isfile(MODEL_PATH):
            raise FileNotFoundError(
                f"MediaPipe model not found: {MODEL_PATH}. "
                "Place face_landmarker.task beside the backend data files."
            )
        base_options = python.BaseOptions(model_asset_path=MODEL_PATH)
        options = vision.FaceLandmarkerOptions(
            base_options=base_options,
            output_face_blendshapes=True,
            output_facial_transformation_matrixes=False,
            num_faces=1
        )
        face_landmarker = vision.FaceLandmarker.create_from_options(options)
        print(f"[VIDEO] MediaPipe FaceLandmarker loaded: {MODEL_PATH}")
        return face_landmarker


def _point_distance(p1, p2):
    return float(np.linalg.norm(np.asarray(p1, dtype=np.float32) - np.asarray(p2, dtype=np.float32)))


def _calculate_ear(coords, eye_top, eye_bottom, eye_left, eye_right):
    vertical = _point_distance(coords[eye_top], coords[eye_bottom])
    horizontal = _point_distance(coords[eye_left], coords[eye_right])
    return vertical / (horizontal + 1e-6)


def _write_json_atomic(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    temp_path = path + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(temp_path, path)


def _process_interview_frame(frame):
    """Analyze one decoded BGR frame and append reference-style telemetry."""
    global BLINK_COUNT, BLINK_STATE
    detector = _get_face_landmarker()
    height, width = frame.shape[:2]
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
    result = detector.detect(mp_image)
    now = time.time()

    with telemetry_lock:
        started_at = INTERVIEW_STARTED_AT if INTERVIEW_STARTED_AT is not None else now
        timestamp = round(max(0.0, now - started_at), 2)
        record = {
            "timestamp_seconds": timestamp,
            "face_detected": False,
            "gaze": "No Face Detected",
            "speech": "Silent",
            "expression": "Neutral",
            "left_ear": None,
            "right_ear": None,
            "gaze_ratio": None,
            "current_blink_total": BLINK_COUNT
        }

        if result.face_landmarks:
            landmarks = result.face_landmarks[0]
            coords = [(int(lm.x * width), int(lm.y * height)) for lm in landmarks]
            record["face_detected"] = True

            # Speaking: lip opening relative to mouth width, as in the reference.
            if len(coords) > max(LIP_TOP, LIP_BOTTOM, LIP_LEFT, LIP_RIGHT):
                lip_dist = _point_distance(coords[LIP_TOP], coords[LIP_BOTTOM])
                lip_width = _point_distance(coords[LIP_LEFT], coords[LIP_RIGHT])
                if lip_dist / (lip_width + 1e-6) > 0.15:
                    record["speech"] = "Speaking"

            # Gaze estimate based on the left iris relative to the inner eye corner.
            if len(coords) > max(LEFT_IRIS + [LEFT_EYE_INNER, LEFT_EYE_OUTER]):
                iris_center = np.mean([coords[i] for i in LEFT_IRIS], axis=0)
                eye_width = _point_distance(coords[LEFT_EYE_INNER], coords[LEFT_EYE_OUTER])
                gaze_dist = _point_distance(coords[LEFT_EYE_INNER], iris_center)
                gaze_ratio = gaze_dist / (eye_width + 1e-6)
                record["gaze_ratio"] = round(float(gaze_ratio), 4)
                record["gaze"] = "Eye-Contact" if 0.38 <= gaze_ratio <= 0.62 else "Looked Away"

            # Blink counting via average eye aspect ratio (EAR).
            required_eye_indices = max(L_EYE_TOP, L_EYE_BOTTOM, R_EYE_TOP, R_EYE_BOTTOM,
                                       L_EYE_LEFT, L_EYE_RIGHT, R_EYE_LEFT, R_EYE_RIGHT)
            if len(coords) > required_eye_indices:
                left_ear = _calculate_ear(coords, L_EYE_TOP, L_EYE_BOTTOM, L_EYE_LEFT, L_EYE_RIGHT)
                right_ear = _calculate_ear(coords, R_EYE_TOP, R_EYE_BOTTOM, R_EYE_LEFT, R_EYE_RIGHT)
                avg_ear = (left_ear + right_ear) / 2.0
                record["left_ear"] = round(left_ear, 4)
                record["right_ear"] = round(right_ear, 4)
                if avg_ear < 0.20:
                    if not BLINK_STATE:
                        BLINK_STATE = True
                elif BLINK_STATE:
                    BLINK_COUNT += 1
                    BLINK_STATE = False

            # Interview expression priority matrix from the supplied reference.
            if result.face_blendshapes:
                scores = {b.category_name: float(b.score) for b in result.face_blendshapes[0]}
                if scores.get("jawOpen", 0) > 0.35:
                    expression = "Surprised"
                elif scores.get("mouthSmileLeft", 0) > 0.40 or scores.get("mouthSmileRight", 0) > 0.40:
                    expression = "Smiling / Confident"
                elif scores.get("browDownLeft", 0) > 0.40 or scores.get("browDownRight", 0) > 0.40:
                    expression = "Frowning / Deep Focus"
                elif scores.get("browOuterUpLeft", 0) > 0.35 or scores.get("mouthStretchLeft", 0) > 0.35:
                    expression = "Anxious / Stressed"
                elif scores.get("mouthFrownLeft", 0) > 0.30 or scores.get("eyeLookInLeft", 0) > 0.40:
                    expression = "Pensive / Evaluating"
                else:
                    expression = "Neutral"
                record["blendshape_scores"] = scores
                record["expression"] = expression

        record["current_blink_total"] = BLINK_COUNT
        VIDEO_TIMELINE.append(record)
        # Persist after every received frame so partial telemetry survives errors.
        _write_json_atomic(INTERVIEW_LOG_PATH, VIDEO_TIMELINE)
        # Keep the established event file available for existing project tooling.
        _write_json_atomic(EVENTS_PATH, VIDEO_TIMELINE)
        return record


def _summarize_video_telemetry():
    with telemetry_lock:
        logs = list(VIDEO_TIMELINE)
        blink_count = BLINK_COUNT
    if not logs:
        return {
            "available": False,
            "message": "No video frames were recorded during this interview.",
            "frames_received": 0,
            "face_detection_coverage_percent": 0.0,
            "eye_contact_percent": None,
            "looked_away_percent": None,
            "speaking_frame_percent": None,
            "blink_count": blink_count,
            "blinks_per_minute": None,
            "expression_percentages": {},
            "timeline": []
        }

    total = len(logs)
    face_logs = [x for x in logs if x.get("face_detected")]
    observed = len(face_logs)
    duration = max(float(logs[-1].get("timestamp_seconds", 0)), 0.0)
    if INTERVIEW_STARTED_AT is not None:
        duration = max(duration, time.time() - INTERVIEW_STARTED_AT)
    gaze_valid = [x for x in face_logs if x.get("gaze") in ("Eye-Contact", "Looked Away")]
    speaking = sum(1 for x in face_logs if x.get("speech") == "Speaking")
    expression_names = ["Neutral", "Surprised", "Smiling / Confident", "Frowning / Deep Focus",
                        "Anxious / Stressed", "Pensive / Evaluating"]
    expression_pct = {}
    for name in expression_names:
        expression_pct[name] = round(100 * sum(1 for x in face_logs if x.get("expression") == name) / observed, 1) if observed else 0.0
    eye_contact_pct = round(100 * sum(1 for x in gaze_valid if x.get("gaze") == "Eye-Contact") / len(gaze_valid), 1) if gaze_valid else None
    looked_away_pct = round(100 * sum(1 for x in gaze_valid if x.get("gaze") == "Looked Away") / len(gaze_valid), 1) if gaze_valid else None
    return {
        "available": True,
        "frames_received": total,
        "face_detected_frames": observed,
        "face_detection_coverage_percent": round(100 * observed / total, 1),
        "session_duration_seconds": round(duration, 2),
        "eye_contact_percent": eye_contact_pct,
        "looked_away_percent": looked_away_pct,
        "speaking_frame_percent": round(100 * speaking / observed, 1) if observed else None,
        "blink_count": blink_count,
        "blinks_per_minute": round(blink_count / (duration / 60), 1) if duration > 0 else None,
        "expression_percentages": expression_pct,
        "timeline": logs
    }


def _behavioral_recommendations(analytics):
    if not analytics.get("available"):
        return ["Video-based observations were unavailable; use the interview conversation and answers for evaluation."]
    recs = []
    gaze = analytics.get("eye_contact_percent")
    if gaze is not None and gaze < 50:
        recs.append("Camera engagement: consider positioning the camera near the screen and practising looking toward it while explaining answers.")
    elif gaze is not None and gaze >= 70:
        recs.append("Camera engagement: eye-contact estimates were consistently within the configured on-screen gaze range.")
    coverage = analytics.get("face_detection_coverage_percent", 0)
    if coverage < 60:
        recs.append("Video quality: face detection coverage was limited. Improve lighting, camera framing, and keep the face unobstructed before drawing conclusions.")
    expr = analytics.get("expression_percentages", {})
    if expr.get("Smiling / Confident", 0) >= 8:
        recs.append("Expression: smiling-related blendshape signals were observed; use these only as a descriptive observation, not proof of confidence.")
    if expr.get("Frowning / Deep Focus", 0) >= 20:
        recs.append("Expression: brow-lowering signals appeared frequently and may coincide with concentration; they cannot establish a candidate's mental state.")
    if not recs:
        recs.append("Continue practising clear, structured answers and review the recorded observations alongside the actual interview responses.")
    return recs


def _generate_comprehensive_pdf(ai_report, analytics, conversation, session_id):
    """Build a detailed PDF combining interview content and video telemetry."""
    from xml.sax.saxutils import escape
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

    os.makedirs(BASE_DIR, exist_ok=True)
    doc = SimpleDocTemplate(REPORT_PDF_PATH, pagesize=letter, rightMargin=0.62*inch,
                            leftMargin=0.62*inch, topMargin=0.62*inch, bottomMargin=0.62*inch,
                            title="Comprehensive AI Interview Report", author="Capstone Interview Analytics")
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="ReportTitleCustom", parent=styles["Title"], fontSize=20, leading=25,
                              textColor=colors.HexColor("#1A365D"), spaceAfter=8))
    styles.add(ParagraphStyle(name="SectionCustom", parent=styles["Heading2"], fontSize=12, leading=16,
                              textColor=colors.HexColor("#2B6CB0"), spaceBefore=12, spaceAfter=6))
    styles.add(ParagraphStyle(name="SmallBodyCustom", parent=styles["BodyText"], fontSize=8.5, leading=12, spaceAfter=5))
    styles.add(ParagraphStyle(name="QuestionCustom", parent=styles["BodyText"], fontSize=9, leading=13, spaceAfter=7))
    story = [Paragraph("Comprehensive AI Interview Report", styles["ReportTitleCustom"]),
             Paragraph(f"<b>Session ID:</b> {escape(str(session_id))}<br/><b>Generated:</b> {time.strftime('%Y-%m-%d %H:%M:%S')}", styles["Normal"]),
             Spacer(1, 10)]

    story.append(Paragraph("1. Executive Summary and AI Assessment", styles["SectionCustom"]))

    # Render the AI assessment as readable headings, bullets and key/value rows
    # instead of printing raw JSON into the PDF.
    def append_readable_value(label, value, depth=0):
        safe_label = escape(str(label).replace("_", " ").strip().title())
        if isinstance(value, dict):
            if not value:
                story.append(Paragraph(f"<b>{safe_label}:</b> Not provided", styles["SmallBodyCustom"]))
                return
            if depth <= 1:
                story.append(Paragraph(safe_label, styles["SectionCustom"]))
            for child_key, child_value in value.items():
                append_readable_value(child_key, child_value, depth + 1)
        elif isinstance(value, (list, tuple)):
            if not value:
                story.append(Paragraph(f"<b>{safe_label}:</b> None provided", styles["SmallBodyCustom"]))
                return
            story.append(Paragraph(f"<b>{safe_label}</b>", styles["SmallBodyCustom"]))
            for child in value:
                if isinstance(child, (dict, list, tuple)):
                    append_readable_value("Details", child, depth + 1)
                else:
                    story.append(Paragraph("• " + escape(str(child)), styles["SmallBodyCustom"]))
        else:
            text_value = str(value if value is not None else "Not provided")
            # Convert newlines to readable paragraphs while escaping report text.
            paragraphs = [part.strip() for part in text_value.splitlines() if part.strip()]
            if not paragraphs:
                paragraphs = ["Not provided"]
            story.append(Paragraph(f"<b>{safe_label}:</b> " + "<br/>".join(escape(part) for part in paragraphs), styles["SmallBodyCustom"]))

    if isinstance(ai_report, dict):
        if not ai_report:
            story.append(Paragraph("No AI-generated assessment was returned.", styles["SmallBodyCustom"]))
        else:
            for assessment_key, assessment_value in ai_report.items():
                append_readable_value(assessment_key, assessment_value)
    elif isinstance(ai_report, list):
        append_readable_value("Assessment Details", ai_report)
    else:
        assessment_text = str(ai_report or "No AI-generated assessment was returned.")
        story.append(Paragraph(escape(assessment_text).replace("\n", "<br/>"), styles["SmallBodyCustom"]))

    story.append(Paragraph("2. Interview Conversation", styles["SectionCustom"]))
    if conversation:
        for idx, item in enumerate(conversation, 1):
            role = str(item.get("role", "message")).capitalize()
            message = escape(str(item.get("text", ""))).replace("\n", "<br/>")
            story.append(Paragraph(f"<b>{idx}. {escape(role)}:</b> {message}", styles["QuestionCustom"]))
    else:
        story.append(Paragraph("No saved conversation transcript was found.", styles["SmallBodyCustom"]))

    story.append(Paragraph("3. Video Telemetry Summary", styles["SectionCustom"]))
    if analytics.get("available"):
        metrics = [
            ["Metric", "Observed result"],
            ["Frames received", str(analytics.get("frames_received", 0))],
            ["Face-detection coverage", f"{analytics.get('face_detection_coverage_percent', 0):.1f}%"],
            ["Estimated eye-contact frames", "N/A" if analytics.get("eye_contact_percent") is None else f"{analytics['eye_contact_percent']:.1f}% of valid gaze frames"],
            ["Looked-away frames", "N/A" if analytics.get("looked_away_percent") is None else f"{analytics['looked_away_percent']:.1f}% of valid gaze frames"],
            ["Speaking mouth-shape frames", "N/A" if analytics.get("speaking_frame_percent") is None else f"{analytics['speaking_frame_percent']:.1f}% of face-detected frames"],
            ["Registered blinks", str(analytics.get("blink_count", 0))],
            ["Estimated blinks/minute", "N/A" if analytics.get("blinks_per_minute") is None else str(analytics["blinks_per_minute"])],
            ["Observed duration", f"{analytics.get('session_duration_seconds', 0):.1f} seconds"]
        ]
        table = Table(metrics, colWidths=[2.15*inch, 4.3*inch], repeatRows=1)
        table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
                                   ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#1A365D")),
                                   ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E0")),
                                   ("VALIGN", (0,0), (-1,-1), "TOP"),
                                   ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6),
                                   ("TOPPADDING", (0,0), (-1,-1), 5), ("BOTTOMPADDING", (0,0), (-1,-1), 5)]))
        story.append(table)
        story.append(Spacer(1, 8))
        story.append(Paragraph("Expression distribution (percentage of face-detected frames):", styles["SmallBodyCustom"]))
        exp_rows = [["Expression label", "Share"]] + [[str(k), f"{v:.1f}%"] for k, v in analytics.get("expression_percentages", {}).items()]
        exp_table = Table(exp_rows, colWidths=[4.5*inch, 1.95*inch], repeatRows=1)
        exp_table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
                                       ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E0")),
                                       ("VALIGN", (0,0), (-1,-1), "TOP"), ("LEFTPADDING", (0,0), (-1,-1), 6),
                                       ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4)]))
        story.append(exp_table)
    else:
        story.append(Paragraph(escape(analytics.get("message", "No video telemetry available.")), styles["SmallBodyCustom"]))

    story.append(Paragraph("4. Development Recommendations", styles["SectionCustom"]))
    for rec in _behavioral_recommendations(analytics):
        story.append(Paragraph("• " + escape(rec), styles["SmallBodyCustom"]))

    story.append(Paragraph("5. Sampled Video Timeline", styles["SectionCustom"]))
    timeline = analytics.get("timeline", [])
    if timeline:
        timeline_rows = [["Time (s)", "Face", "Gaze", "Mouth", "Expression", "Blinks"]]
        for item in timeline:
            timeline_rows.append([
                str(item.get("timestamp_seconds", "")),
                "Yes" if item.get("face_detected") else "No",
                str(item.get("gaze", "")),
                str(item.get("speech", "")),
                str(item.get("expression", "")),
                str(item.get("current_blink_total", 0))
            ])
        timeline_table = Table(timeline_rows, colWidths=[0.55*inch, 0.45*inch, 1.05*inch, 0.55*inch, 2.55*inch, 0.55*inch], repeatRows=1)
        timeline_table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
                                            ("GRID", (0,0), (-1,-1), 0.3, colors.HexColor("#CBD5E0")),
                                            ("FONTSIZE", (0,0), (-1,-1), 6.5),
                                            ("VALIGN", (0,0), (-1,-1), "TOP"),
                                            ("LEFTPADDING", (0,0), (-1,-1), 3),
                                            ("RIGHTPADDING", (0,0), (-1,-1), 3),
                                            ("TOPPADDING", (0,0), (-1,-1), 3),
                                            ("BOTTOMPADDING", (0,0), (-1,-1), 3)]))
        story.append(timeline_table)
    else:
        story.append(Paragraph("No sampled video timeline was recorded.", styles["SmallBodyCustom"]))

    story.append(Paragraph("6. Methodology and Limitations", styles["SectionCustom"]))
    limitation = ("Video metrics are estimates from sampled webcam frames and configured MediaPipe landmark/blendshape thresholds. "
                  "Because frame sampling may be sparse, blink counts can be undercounted. Mouth opening is only a visual proxy and "
                  "does not verify that the candidate's voice is audible. Gaze and facial expressions do not reliably reveal honesty, "
                  "confidence, stress, personality, or cognitive ability; they must not be used as standalone hiring criteria. "
                  "Interpret these observations alongside the actual answers, role requirements, and interviewer judgement.")
    story.append(Paragraph(escape(limitation), styles["SmallBodyCustom"]))
    doc.build(story)
    return REPORT_PDF_PATH


# ============================================================
# ROBOT STATES
# ============================================================

class RobotState:

    IDLE = "IDLE"
    LISTENING = "LISTENING"
    THINKING = "THINKING"
    SPEAKING = "SPEAKING"
    GREETING = "GREETING"
    ATTENTION = "ATTENTION"
    GOODBYE = "GOODBYE"


# ============================================================
# ROBOT HEAD CONTROLLER
# ============================================================

class RobotHeadController:

    def __init__(self):

        self.serial_conn = None
        self.connected = False

        self.current_state = RobotState.IDLE

        self.animation_thread = None
        self.animation_running = False

        self.lock = threading.Lock()

        self.engine = None

        # Servo configuration

        # Servo configuration
        self.MIN_ANGLE = 40
        self.MAX_ANGLE = 140
        self.CENTER_ANGLE = 90

        # Smooth physical movement
        self.STEP_DELAY = 0.02

        # Animation control
        self.animation_thread = None
        self.animation_running = False
        self.animation_id = 0

        self.lock = threading.Lock()

        # WiFi/HTTP configuration
        self.use_wifi = USE_WIFI
        self.esp32_url = f"http://{ESP32_IP}:{ESP32_PORT_HTTP}"


    # --------------------------------------------------------
    # CONNECT ESP32
    # --------------------------------------------------------

    def connect(self):

        if self.use_wifi:
            self.connect_wifi()
        else:
            self.connect_serial()

    def connect_serial(self):

        if serial is None:
            print("[ROBOT] Serial mode requires pyserial. Install with: python -m pip install pyserial")
            self.connected = False
            return

        try:

            print(f"[ROBOT] Connecting to ESP32 via Serial on {ESP32_PORT}...")

            self.serial_conn = serial.Serial(
                ESP32_PORT,
                ESP32_BAUD,
                timeout=1
            )

            time.sleep(2)

            self.connected = True

            print("[ROBOT] ESP32 connected successfully via Serial.")

            self.send_angle(self.CENTER_ANGLE)

        except Exception as e:

            print(f"[ROBOT] ESP32 Serial connection failed: {e}")

            self.connected = False
            self.serial_conn = None

    def connect_wifi(self):

        try:

            print(f"[ROBOT] Connecting to ESP32 via WiFi at {self.esp32_url}...")

            # Test connection by sending a status request
            response = requests.get(
                f"{self.esp32_url}/status",
                timeout=5
            )

            if response.status_code == 200:
                self.connected = True
                print("[ROBOT] ESP32 connected successfully via WiFi.")
                print(f"[ROBOT] ESP32 Status: {response.json()}")
                self.send_angle(self.CENTER_ANGLE)
            else:
                print(f"[ROBOT] ESP32 WiFi connection failed: HTTP {response.status_code}")
                self.connected = False

        except Exception as e:

            print(f"[ROBOT] ESP32 WiFi connection failed: {e}")
            self.connected = False

    # --------------------------------------------------------
    # DISCONNECT
    # --------------------------------------------------------

    def disconnect(self):

        self.stop_animation()

        try:

            if self.use_wifi:
                self.send_command("STOP")
            elif self.serial_conn and self.serial_conn.is_open:
                self.send_command("STOP")
                self.serial_conn.close()

        except Exception as e:

            print(f"[ROBOT] Disconnect error: {e}")

        self.connected = False

        print("[ROBOT] ESP32 disconnected.")

    # --------------------------------------------------------
    # SEND COMMAND
    # --------------------------------------------------------

    def send_command(self, command):

        if not self.connected:
            return

        try:

            if self.use_wifi:
                self.send_command_wifi(command)
            else:
                self.send_command_serial(command)

        except Exception as e:

            print(f"[ROBOT] Command send error: {e}")

    def send_command_serial(self, command):

        try:

            with self.lock:

                self.serial_conn.write(
                    (command + "\n").encode()
                )

                self.serial_conn.flush()

        except Exception as e:

            print(f"[ROBOT] Serial write error: {e}")

    def send_command_wifi(self, command):

        try:

            with self.lock:

                response = requests.post(
                    f"{self.esp32_url}/command",
                    data=command,
                    timeout=5
                )

                if response.status_code == 200:
                    print(f"[ROBOT] WiFi command sent: {command}")
                else:
                    print(f"[ROBOT] WiFi command failed: HTTP {response.status_code}")

        except Exception as e:

            print(f"[ROBOT] WiFi write error: {e}")

    # # --------------------------------------------------------
    # # SEND SERVO ANGLE
    # # --------------------------------------------------------

    # def send_angle(self, angle):

    #     angle = max(
    #         self.MIN_ANGLE,
    #         min(self.MAX_ANGLE, int(angle))
    #     )

    #     self.send_command(f"ANGLE:{angle}")


        # --------------------------------------------------------
    # SEND SERVO ANGLE (HEAD)
    # --------------------------------------------------------

    def send_angle(self, angle):

        angle = max(
            self.MIN_ANGLE,
            min(self.MAX_ANGLE, int(angle))
        )

        self.send_command(f"ANGLE:{angle}")

    # --------------------------------------------------------
    # SEND HAND ANGLES (NEW HELPER)
    # --------------------------------------------------------

    def send_hand_angles(self, left, right):
        """
        Sends independent, clamped target angles to the hand servos.
        Because the ESP32 internally maps the right hand using (180 - angle),
        sending identical angles from the backend results in physically 
        coordinated, mirrored gestures.
        """
        left_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(left)))
        right_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(right)))
        
        self.send_command(f"LEFT:{left_clamped}")
        self.send_command(f"RIGHT:{right_clamped}")

    # --------------------------------------------------------
    # STOP SERVO
    # --------------------------------------------------------

    def stop_servo(self):

        self.send_command("STOP")

    # --------------------------------------------------------
    # ANIMATION
    # --------------------------------------------------------

    def start_animation(self, state):
        self.stop_animation()

        self.animation_running = True
        generation = self.animation_id

        self.animation_thread = threading.Thread(
            target=self.animation_loop,
            args=(state, generation),
            daemon=True
        )
        self.animation_thread.start()

    def stop_animation(self):
        self.animation_running = False

        # Invalidate every older animation thread.
        self.animation_id += 1

        old_thread = self.animation_thread

        if (
            old_thread
            and old_thread.is_alive()
            and old_thread != threading.current_thread()
        ):
            old_thread.join(timeout=0.7)

        self.animation_thread = None

    # --------------------------------------------------------
    # ANIMATION LOOP (UPDATED TO INTEGRATE HAND GESTURES)
    # --------------------------------------------------------

    def animation_loop(self, state, generation):
        """
        State-driven robot head and hand animation.
        Coordinated, non-blocking physical gestures.
        """

        def active():
            return (
                self.animation_running
                and generation == self.animation_id
            )

        def move(head_ang, left_ang=90, right_ang=90, pause=0.0):
            if not active():
                return False

            # Dispatch head and hand instructions safely across Wi-Fi
            self.send_angle(head_ang)
            self.send_hand_angles(left_ang, right_ang)

            if pause > 0:
                deadline = time.monotonic() + pause
                while active() and time.monotonic() < deadline:
                    time.sleep(0.05)

            return active()

        try:
            # ------------------------------------------
            # IDLE / LISTENING / THINKING: Rest positions
            # ------------------------------------------
            if state == RobotState.IDLE:
                move(90, 90, 90)
                return

            elif state == RobotState.LISTENING:
                # Attentive head tilt, hands relaxed at base rest (90)
                if not move(76, 90, 90, 0.8):
                    return
                while active():
                    time.sleep(0.05)

            elif state == RobotState.THINKING:
                # Look aside, keep hands resting to express analytical calm
                if not move(108, 90, 90, 1.4):
                    return
                while active():
                    if not move(102, 90, 90, 1.8): break
                    if not move(110, 90, 90, 1.2): break
                    if not move(90, 90, 90, 2.5): break

            # ------------------------------------------
            # SPEAKING: Dynamic conversational expressions
            # ------------------------------------------
            elif state == RobotState.SPEAKING:
                if not move(90, 90, 90):
                    return

                while active():
                    # Subtle mirrored conversational expansion (opening up)
                    if not move(98, 75, 75, 0.45): break
                    if not move(90, 90, 90, 1.0): break
                    # Alternating asymmetrical emphasis shifts
                    if not move(82, 105, 80, 0.45): break
                    if not move(90, 90, 90, 1.5): break

            # ------------------------------------------
            # GREETING: Welcome presentation gesture
            # ------------------------------------------
            elif state == RobotState.GREETING:
                # Graceful sweep opening both hands outward together
                if not move(72, 60, 60, 0.45): return
                if not move(108, 60, 60, 0.55): return
                # Gradually return to center balance positions
                if not move(78, 80, 80, 0.45): return
                move(90, 90, 90, 0.8)

            # ------------------------------------------
            # ATTENTION: Orient towards user
            # ------------------------------------------
            elif state == RobotState.ATTENTION:
                if not move(110, 90, 90, 0.8): return
                if not move(90, 90, 90, 1.0): return

                while active():
                    if not move(96, 90, 90, 0.8): break
                    if not move(90, 90, 90, 2.5): break

            # ------------------------------------------
            # GOODBYE: Closing polite gesture
            # ------------------------------------------
            elif state == RobotState.GOODBYE:
                # Brief parting hand gesture, then drop smoothly down to rest
                if not move(72, 70, 70, 0.45): return
                if not move(108, 70, 70, 0.55): return
                if not move(72, 90, 90, 0.45): return
                move(90, 90, 90, 1.0)

        except Exception as e:
            print(f"[ROBOT] Animation error: {e}")

    # --------------------------------------------------------
    # SET ROBOT STATE
    # --------------------------------------------------------

    def set_state(self, new_state):

        thread_alive = (
            self.animation_thread is not None
            and self.animation_thread.is_alive()
        )

        if new_state == self.current_state and thread_alive:
            return

        print(
            f"[ROBOT] STATE: "
            f"{self.current_state} -> {new_state}"
        )

        self.current_state = new_state
        self.start_animation(new_state)

    # --------------------------------------------------------
    # PYTTSX3 SPEAK
    # --------------------------------------------------------

    def speak(self, text):

        """
        Optional backend TTS.

        CURRENT PROJECT FLOW:
        Browser SpeechSynthesis handles the actual voice.

        Therefore this function is NOT called by the ADK
        callback.
        """

        if not text:
            return

        if self.engine is None:

            try:

                self.engine = pyttsx3.init()

            except Exception as e:

                print(
                    f"[ROBOT] pyttsx3 initialization failed: {e}"
                )

                return

        self.set_state(RobotState.SPEAKING)

        try:

            self.engine.say(text)
            self.engine.runAndWait()

        except Exception as e:

            print(f"[ROBOT] TTS error: {e}")

        finally:

            self.set_state(RobotState.LISTENING)


# ============================================================
# CREATE ROBOT
# ============================================================

robot = RobotHeadController()


# ============================================================
# RESUME TEXT EXTRACTION
# ============================================================

def getText() -> str:

    resume_path = RESUME_PATH

    if not os.path.exists(resume_path):

        print(
            f"[RESUME] Uploaded resume not found: "
            f"{resume_path}"
        )

        resume_path = "sample_resume.pdf"

    if not os.path.exists(resume_path):

        print("[RESUME] No resume PDF found.")

        return ""

    text = ""

    try:

        with pdfplumber.open(resume_path) as pdf:

            for page in pdf.pages:

                page_text = page.extract_text()

                if page_text:

                    text += page_text + "\n"

        print(
            f"[RESUME] Extracted "
            f"{len(text)} characters."
        )

        return text

    except Exception as e:

        print(
            f"[RESUME] Error extracting resume: {e}"
        )

        return ""


# ============================================================
# ADK CALLBACK
# ============================================================

def Speak(callback_context):

    """
    ADK callback.

    IMPORTANT:
    The browser is responsible for actual voice output.

    Therefore this callback DOES NOT call pyttsx3.
    """

    print(
        "[AGENT] Speak callback triggered - "
        "browser will handle TTS"
    )

    return None


# ============================================================
# GEMINI CONFIGURATION
# ============================================================

retry_config = types.HttpRetryOptions(

    attempts=5,

    exp_base=7,

    initial_delay=1,

    http_status_codes=[
        429,
        500,
        503,
        504
    ]
)


# ============================================================
# CAMERA AGENT
# ============================================================

CameraAgent = LlmAgent(
    name="CamAgent"
)


# ============================================================
# INTERVIEW AGENT
# ============================================================

interviewAgent = LlmAgent(

    name="InterviewAgent",

    model=Gemini(
        model="gemini-3.5-flash-lite",
        retry_options=retry_config
    ),

    description=(
        "You are an AI professional interviewer "
        "who interviews candidates based on their resumes."
    ),

    instruction="""

You are a professional interviewer conducting a
technical recruitment interview.

IMPORTANT RULES:

1. Use the getText() tool to extract the candidate's
   resume text.

2. Study the candidate's resume carefully.

3. Ask ONLY ONE question at a time.

4. After asking a question, WAIT for the candidate's
   answer before asking the next question.

5. Ask at least 2 questions about the candidate
   personally, such as:
   - Introduction
   - Background
   - Career goals
   - Interests

6. Ask at least 4 technical questions based specifically
   on the skills, technologies and projects present in
   the candidate's resume.

7. Do NOT invent technologies or projects that are not
   present in the resume.

8. Questions should progressively evaluate:
   - Understanding
   - Practical knowledge
   - Problem solving
   - Technical depth

9. Keep each interviewer response concise and natural
   because it will be converted into speech.

10. Do not ask multiple questions in one response.

11. Do not repeat a question that has already been asked.

12. Maintain awareness of the previous conversation.

13. After all required questions have been completed,
    provide an overall summary of the candidate's
    performance.

14. The final summary should include:
    - Strengths
    - Technical knowledge
    - Communication
    - Problem solving
    - Areas for improvement
    - Overall assessment

15. Always use the candidate's resume information when
    discussing their background, skills and projects.

16. Never generate a second answer to the same candidate
    response.

""",

    after_agent_callback=Speak,

    tools=[getText]
)


# ============================================================
# ADK SESSION SERVICE
# ============================================================

session_service = InMemorySessionService()


# ============================================================
# RUNNER
# ============================================================

runner = Runner(

    agent=interviewAgent,

    app_name=APP_NAME,

    session_service=session_service
)


# ============================================================
# RUN ADK SESSION
# ============================================================

async def run_session(
    runner: Runner,
    query: str,
    session_id: str
):

    print()
    print("=" * 60)
    print("[ADK] NEW MODEL REQUEST")
    print(f"[ADK] Session ID : {session_id}")
    print(f"[ADK] User       : {USER_ID}")
    print(f"[ADK] Query      : {query}")
    print("=" * 60)

    if not query or not query.strip():

        print(
            "[ADK] Empty user query. "
            "Skipping model request."
        )

        return None

    query_content = types.Content(

        role="user",

        parts=[
            types.Part(
                text=query.strip()
            )
        ]

    )

    model_text = None

    try:

        async for event in runner.run_async(

            user_id=USER_ID,

            session_id=session_id,

            new_message=query_content

        ):

            # Only use the final response.

            if not event.is_final_response():
                continue

            if not event.content:
                continue

            if not event.content.parts:
                continue

            for part in event.content.parts:

                if (
                    hasattr(part, "text")
                    and part.text
                    and part.text.strip()
                ):

                    model_text = part.text.strip()

                    print()
                    print("[ADK] FINAL MODEL RESPONSE:")
                    print(model_text)
                    print()

                    break

            if model_text:
                break

    except Exception as e:

        print(
            f"[ADK] Model execution error: {e}"
        )

        raise

    if not model_text:

        print(
            "[ADK] WARNING: "
            "No final model response received."
        )

    return model_text


# ============================================================
# SAVE CONVERSATION
# ============================================================

def save_conversation(session):

    conversation_data = []

    try:

        if not session:
            return conversation_data

        for event in session.events:

            if not event.content:
                continue

            role = event.content.role

            if role not in ["user", "model"]:
                continue

            if not event.content.parts:
                continue

            for part in event.content.parts:

                if (
                    hasattr(part, "text")
                    and part.text
                    and part.text.strip()
                ):

                    conversation_data.append({

                        "role": role,

                        "text": part.text.strip()

                    })

        os.makedirs(
            os.path.dirname(CONVERSATION_PATH),
            exist_ok=True
        )

        with open(
            CONVERSATION_PATH,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                conversation_data,
                f,
                indent=4,
                ensure_ascii=False
            )

        print(
            f"[CONVERSATION] Saved "
            f"{len(conversation_data)} messages."
        )

    except Exception as e:

        print(
            f"[CONVERSATION] Save error: {e}"
        )

    return conversation_data


# ============================================================
# FASTAPI LIFESPAN
# ============================================================

@asynccontextmanager
async def lifespan(app: FastAPI):

    print()
    print("=" * 60)
    print("VOICE BASED AI INTERVIEWER BACKEND")
    print("=" * 60)

    robot.connect()

    if robot.connected:

        robot.current_state = RobotState.IDLE

        robot.start_animation(
            RobotState.IDLE
        )

    yield

    print(
        "[SERVER] Shutting down..."
    )

    robot.disconnect()


# ============================================================
# FASTAPI APP
# ============================================================

app = FastAPI(
    lifespan=lifespan
)


# ============================================================
# CORS
# ============================================================

app.add_middleware(

    CORSMiddleware,

    allow_origins=["*"],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"]

)


# ============================================================
# LOGIN AUTHENTICATION
# ============================================================

# Hardcoded valid credentials (in production, use a database)
VALID_CREDENTIALS = {
    "admin@interviewai.com": "admin123",
    "candidate@interviewai.com": "candidate123",
    "recruiter@interviewai.com": "recruiter123"
}

# Store interview sessions
INTERVIEW_HISTORY = []

@app.post("/login")
async def login(credentials: dict):
    """
    Authenticate user credentials.
    """
    try:
        email = credentials.get("email", "").strip().lower()
        password = credentials.get("password", "")

        if not email or not password:
            return {
                "status": "error",
                "message": "Email and password are required."
            }

        # Check if credentials match
        if email in VALID_CREDENTIALS and VALID_CREDENTIALS[email] == password:
            return {
                "status": "success",
                "message": "Login successful",
                "user": {
                    "email": email,
                    "name": email.split("@")[0],
                    "initials": email[:2].upper()
                }
            }
        else:
            return {
                "status": "error",
                "message": "Invalid email or password"
            }

    except Exception as e:
        print(f"[LOGIN] Error: {e}")
        return {
            "status": "error",
            "message": "Authentication failed"
        }


# ============================================================
# INTERVIEW HISTORY
# ============================================================

@app.get("/interview-history")
async def get_interview_history():
    """
    Get all completed interview sessions.
    """
    try:
        return {
            "status": "success",
            "history": INTERVIEW_HISTORY
        }
    except Exception as e:
        print(f"[HISTORY] Error: {e}")
        return {
            "status": "error",
            "message": "Failed to fetch interview history"
        }


# ============================================================
# UPLOAD RESUME
# ============================================================

@app.post("/upload-resume")
async def upload_resume(
    file: UploadFile = File(...)
):

    try:

        os.makedirs(
            BASE_DIR,
            exist_ok=True
        )

        data = await file.read()

        with open(
            RESUME_PATH,
            "wb"
        ) as f:

            f.write(data)

        print(
            f"[RESUME] Uploaded: "
            f"{len(data)} bytes"
        )

        return {

            "status": "success",

            "message": "Resume uploaded successfully."

        }

    except Exception as e:

        print(
            f"[RESUME] Upload error: {e}"
        )

        return {

            "status": "error",

            "message": str(e)

        }


# ============================================================
# START NEW INTERVIEW
# ============================================================

@app.post("/start-interview")
async def start_interview(interview_data: dict = None):

    global CURRENT_SESSION_ID
    global LAST_AUDIO_HASH
    global LAST_MODEL_RESPONSE
    global INTERVIEW_HISTORY

    try:

        # ----------------------------------------------------
        # CREATE UNIQUE SESSION
        # ----------------------------------------------------

        CURRENT_SESSION_ID = (
            f"interview_{uuid.uuid4().hex}"
        )

        print()
        print("=" * 60)
        print("[INTERVIEW] NEW INTERVIEW STARTED")
        print(
            f"[INTERVIEW] Session: "
            f"{CURRENT_SESSION_ID}"
        )
        print("=" * 60)

        # ----------------------------------------------------
        # STORE INTERVIEW SESSION DATA
        # ----------------------------------------------------

        if interview_data:
            interview_session = {
                "session_id": CURRENT_SESSION_ID,
                "company_name": interview_data.get("companyName", "Unknown"),
                "position": interview_data.get("position", "Unknown"),
                "experience": interview_data.get("experience", "Not specified"),
                "mode": interview_data.get("mode", "audio"),
                "difficulty": interview_data.get("difficulty", "medium"),
                "question_count": interview_data.get("questionCount", 5),
                "start_time": interview_data.get("startTime", time.strftime("%Y-%m-%d %H:%M:%S")),
                "status": "in_progress",
                "score": None
            }
            INTERVIEW_HISTORY.append(interview_session)
            print(f"[HISTORY] Interview session stored: {interview_session['company_name']} - {interview_session['position']}")

        # ----------------------------------------------------
        # RESET DUPLICATE PROTECTION
        # ----------------------------------------------------

        LAST_AUDIO_HASH = None
        LAST_MODEL_RESPONSE = None

        # Reset video telemetry for this interview only.
        global VIDEO_TIMELINE, INTERVIEW_STARTED_AT, BLINK_COUNT, BLINK_STATE
        with telemetry_lock:
            VIDEO_TIMELINE = []
            INTERVIEW_STARTED_AT = time.time()
            BLINK_COUNT = 0
            BLINK_STATE = False
        os.makedirs(BASE_DIR, exist_ok=True)
        _write_json_atomic(INTERVIEW_LOG_PATH, [])

        # ----------------------------------------------------
        # CREATE ADK SESSION
        # ----------------------------------------------------

        await session_service.create_session(

            app_name=APP_NAME,

            user_id=USER_ID,

            session_id=CURRENT_SESSION_ID

        )

        # ----------------------------------------------------
        # CLEAR OLD INTERVIEW DATA
        # ----------------------------------------------------

        os.makedirs(
            BASE_DIR,
            exist_ok=True
        )

        with open(
            CONVERSATION_PATH,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                [],
                f
            )

        with open(
            EXPRESSIONS_PATH,
            "w",
            encoding="utf-8"
        ) as f:

            f.truncate(0)

        with open(
            EVENTS_PATH,
            "w",
            encoding="utf-8"
        ) as f:

            f.truncate(0)

        if os.path.exists(
            COMPRESSED_EVENTS_PATH
        ):

            with open(
                COMPRESSED_EVENTS_PATH,
                "w",
                encoding="utf-8"
            ) as f:

                json.dump(
                    [],
                    f
                )

        # ----------------------------------------------------
        # ROBOT GREETING
        # ----------------------------------------------------
        # Frontend face sequence: GREETING -> SPEAKING while browser
        # TTS speaks -> LISTENING after the greeting finishes.
        robot.set_state(RobotState.GREETING)

        return {

            "status": "success",

            "message":
                "New interview session started.",

            "session_id":
                CURRENT_SESSION_ID

        }

    except Exception as e:

        print(
            f"[INTERVIEW] Start error: {e}"
        )

        return {

            "status": "error",

            "message": str(e)

        }


# ============================================================
# TRANSCRIBE + AI RESPONSE
# ============================================================

@app.post("/transcribe")
async def transcribe(
    audio: UploadFile = File(...)
):

    global LAST_AUDIO_HASH
    global LAST_MODEL_RESPONSE
    global CURRENT_SESSION_ID

    # ========================================================
    # IMPORTANT:
    # Only one transcription request can run at a time.
    # ========================================================

    async with transcribe_lock:

        request_id = uuid.uuid4().hex[:8]

        print()
        print("=" * 70)
        print(
            f"[TRANSCRIBE] NEW REQUEST "
            f"ID={request_id}"
        )
        print("=" * 70)

        try:

            # ------------------------------------------------
            # CHECK SESSION
            # ------------------------------------------------

            if not CURRENT_SESSION_ID:

                print(
                    "[TRANSCRIBE] ERROR: "
                    "No active interview session."
                )

                return {

                    "transcript": "",

                    "model":
                        "Please start a new interview first."

                }

            # Keep this request tied to its original session if a new
            # interview is started while audio/model processing is active.
            session_id = CURRENT_SESSION_ID

            # ------------------------------------------------
            # ROBOT THINKING
            # ------------------------------------------------

            robot.set_state(
                RobotState.THINKING
            )

            # ------------------------------------------------
            # READ AUDIO
            # ------------------------------------------------

            audio_data = await audio.read()

            if not audio_data:

                print(
                    "[TRANSCRIBE] Empty audio."
                )

                robot.set_state(
                    RobotState.LISTENING
                )

                return {

                    "transcript": "",

                    "model":
                        "I could not hear your answer. "
                        "Please try again."

                }

            print(
                f"[TRANSCRIBE] Audio size: "
                f"{len(audio_data)} bytes"
            )

            # ------------------------------------------------
            # CREATE AUDIO HASH
            # ------------------------------------------------

            audio_hash = hashlib.sha256(
                audio_data
            ).hexdigest()

            print(
                f"[TRANSCRIBE] Audio hash: "
                f"{audio_hash[:16]}..."
            )

            # ------------------------------------------------
            # DUPLICATE AUDIO CHECK
            # ------------------------------------------------

            if (
                LAST_AUDIO_HASH is not None
                and audio_hash == LAST_AUDIO_HASH
            ):

                print()
                print(
                    "[TRANSCRIBE] DUPLICATE AUDIO "
                    "DETECTED."
                )

                print(
                    "[TRANSCRIBE] "
                    "Gemini will NOT be called again."
                )

                robot.set_state(
                    RobotState.SPEAKING
                )

                return {

                    "transcript":
                        "(duplicate request)",

                    "model":
                        LAST_MODEL_RESPONSE
                        or
                        "Please continue."

                }

            # ------------------------------------------------
            # SAVE AUDIO
            # ------------------------------------------------

            os.makedirs(
                BASE_DIR,
                exist_ok=True
            )

            with open(
                AUDIO_PATH,
                "wb"
            ) as f:

                f.write(audio_data)

            print(
                f"[TRANSCRIBE] Saved audio: "
                f"{AUDIO_PATH}"
            )

            # ------------------------------------------------
            # LOAD WHISPER
            # ------------------------------------------------

            print(
                "[WHISPER] Loading model..."
            )

            model = whisper.load_model(
                "base"
            )

            print(
                "[WHISPER] Model loaded."
            )

            # ------------------------------------------------
            # TRANSCRIBE
            # ------------------------------------------------

            print(
                "[WHISPER] Transcribing..."
            )

            result = model.transcribe(
                AUDIO_PATH
            )

            text = (
                result
                .get("text", "")
                .strip()
            )

            print()
            print(
                "[WHISPER] TRANSCRIPT:"
            )
            print(text)
            print()

            # ------------------------------------------------
            # EMPTY TRANSCRIPT
            # ------------------------------------------------

            if not text:

                print(
                    "[WHISPER] Empty transcript."
                )

                robot.set_state(
                    RobotState.LISTENING
                )

                return {

                    "transcript": "",

                    "model":
                        "I could not understand your "
                        "answer. Please try again."

                }

            # ------------------------------------------------
            # VERIFY SESSION
            # ------------------------------------------------

            print(
                "[ADK] Using session:",
                session_id
            )

            # ------------------------------------------------
            # SEND TO GEMINI
            # ------------------------------------------------

            model_response = await run_session(

                runner,

                text,

                session_id

            )

            # ------------------------------------------------
            # HANDLE EMPTY MODEL RESPONSE
            # ------------------------------------------------

            if not model_response:

                print(
                    "[ADK] No model response."
                )

                model_response = (
                    "Thank you for your answer. "
                    "Let's continue."
                )

            # ------------------------------------------------
            # SAVE LAST MODEL RESPONSE
            # ------------------------------------------------

            LAST_MODEL_RESPONSE = model_response

            # Store duplicate protection only after a successful model
            # response; failed model calls can then be retried.
            LAST_AUDIO_HASH = audio_hash

            # ------------------------------------------------
            # READ SESSION ONLY FOR LOGGING
            #
            # IMPORTANT:
            # This does NOT call Gemini again.
            # ------------------------------------------------

            session = await session_service.get_session(

                app_name=APP_NAME,

                user_id=USER_ID,

                session_id=session_id

            )

            # ------------------------------------------------
            # SAVE CONVERSATION
            # ------------------------------------------------

            save_conversation(
                session
            )

            # ------------------------------------------------
            # ROBOT SPEAKING
            # ------------------------------------------------

            robot.set_state(
                RobotState.SPEAKING
            )

            print()
            print("=" * 70)
            print(
                f"[TRANSCRIBE] REQUEST "
                f"{request_id} COMPLETE"
            )
            print(
                "[TRANSCRIBE] Candidate:",
                text
            )
            print(
                "[TRANSCRIBE] AI:",
                model_response
            )
            print("=" * 70)
            print()

            # ------------------------------------------------
            # RETURN TO FRONTEND
            # ------------------------------------------------

            return {

                "transcript": text,

                "model": model_response

            }

        except Exception as e:

            print()
            print(
                "[TRANSCRIBE] ERROR:",
                str(e)
            )

            import traceback

            traceback.print_exc()

            robot.set_state(
                RobotState.LISTENING
            )

            return {

                "transcript": "",

                "model":
                    "Sorry, I encountered an error. "
                    "Please try again."

            }


# ============================================================
# GENERATE FINAL REPORT
# ============================================================

@app.post("/generate-report")
async def generate_report():
    global CURRENT_SESSION_ID
    global INTERVIEW_HISTORY

    print("\n" + "=" * 60)
    print("[REPORT] GENERATING COMPREHENSIVE INTERVIEW REPORT")
    print("=" * 60)

    try:
        if not CURRENT_SESSION_ID:
            return {"status": "error", "message": "No active interview session."}

        session = await session_service.get_session(
            app_name=APP_NAME, user_id=USER_ID, session_id=CURRENT_SESSION_ID
        )
        if not session:
            return {"status": "error", "message": "Interview session not found."}

        # Preserve the existing AI interview assessment, then combine it with
        # the complete saved conversation and the newly processed telemetry.
        ai_report = generate_interview_report(
            session_service=session_service,
            app_name=APP_NAME,
            user_id=USER_ID,
            session_id=CURRENT_SESSION_ID,
            llm_agent=interviewAgent
        )

        analytics = _summarize_video_telemetry()
        try:
            with open(CONVERSATION_PATH, "r", encoding="utf-8") as f:
                conversation = json.load(f)
            if not isinstance(conversation, list):
                conversation = []
        except (OSError, json.JSONDecodeError):
            conversation = []

        report_pdf = _generate_comprehensive_pdf(
            ai_report=ai_report,
            analytics=analytics,
            conversation=conversation,
            session_id=CURRENT_SESSION_ID
        )

        report_data = {
            "session_id": CURRENT_SESSION_ID,
            "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ai_assessment": ai_report,
            "conversation": conversation,
            "video_analytics": {k: v for k, v in analytics.items() if k != "timeline"},
            "behavioral_recommendations": _behavioral_recommendations(analytics),
            "pdf_report_url": "/download-report"
        }
        _write_json_atomic(os.path.join(BASE_DIR, "comprehensive_interview_report.json"), report_data)

        print(f"[REPORT] Comprehensive PDF created: {report_pdf}")
        robot.set_state(RobotState.GOODBYE)

        # Update interview history with completion status and score
        for interview in INTERVIEW_HISTORY:
            if interview["session_id"] == CURRENT_SESSION_ID:
                interview["status"] = "completed"
                interview["completed_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
                # Extract score from video analytics if available
                if analytics.get("eye_contact_percent"):
                    interview["score"] = int(analytics["eye_contact_percent"])
                else:
                    interview["score"] = 85  # Default score
                break

        return {
            "status": "success",
            # Keep the existing `report` field for frontend compatibility.
            "report": ai_report,
            "comprehensive_report": report_data,
            "video_analytics": report_data["video_analytics"],
            "pdf_report_url": "/download-report",
            "session_id": CURRENT_SESSION_ID
        }

    except Exception as e:
        print("[REPORT] Error:", str(e))
        import traceback
        traceback.print_exc()
        return {"status": "error", "message": str(e)}


@app.post("/convert-json-report")
async def convert_json_report():
    """Create a readable PDF from the existing comprehensive JSON, without rerunning the interview."""
    json_path = os.path.join(BASE_DIR, "comprehensive_interview_report.json")
    if not os.path.isfile(json_path):
        return {"status": "error", "message": f"Report JSON was not found: {json_path}"}

    try:
        with open(json_path, "r", encoding="utf-8") as f:
            report_data = json.load(f)
        if not isinstance(report_data, dict):
            return {"status": "error", "message": "The comprehensive report JSON must contain an object."}

        analytics = report_data.get("video_analytics", {})
        if not isinstance(analytics, dict):
            analytics = {}

        # The compact JSON intentionally omits the full timeline. Restore it from
        # the separate frame log when that file is available.
        try:
            with open(INTERVIEW_LOG_PATH, "r", encoding="utf-8") as f:
                timeline_data = json.load(f)
            if isinstance(timeline_data, list):
                analytics["timeline"] = timeline_data
            elif isinstance(timeline_data, dict):
                analytics["timeline"] = timeline_data.get("timeline", [])
        except (OSError, json.JSONDecodeError):
            analytics["timeline"] = []

        # Recreate expression distribution if the stored JSON lacks it.
        analytics.setdefault("expression_percentages", {})
        ai_report = report_data.get("ai_assessment", {})
        conversation = report_data.get("conversation", [])
        if not isinstance(conversation, list):
            conversation = []

        _generate_comprehensive_pdf(
            ai_report=ai_report,
            analytics=analytics,
            conversation=conversation,
            session_id=report_data.get("session_id", "Unknown")
        )
        return {
            "status": "success",
            "message": "A readable PDF report was generated from the existing JSON.",
            "pdf_report_url": "/download-report",
            "pdf_path": REPORT_PDF_PATH
        }
    except Exception as e:
        print("[REPORT] JSON-to-PDF conversion error:", str(e))
        import traceback
        traceback.print_exc()
        return {"status": "error", "message": str(e)}


@app.get("/download-report")
async def download_report():
    if not os.path.isfile(REPORT_PDF_PATH):
        return {"status": "error", "message": "Report PDF has not been generated yet."}
    return FileResponse(
        REPORT_PDF_PATH,
        media_type="application/pdf",
        filename="comprehensive_interview_report.pdf"
    )


# ============================================================
# ROBOT STATE API
# ============================================================

@app.get("/robot-state")
async def robot_state():

    return {

        "state":
            robot.current_state,

        "connected":
            robot.connected

    }


# ============================================================
# SET ROBOT STATE
# ============================================================

@app.post("/robot/state")
async def set_robot_state(data: dict):

    state = data.get("state")

    valid_states = {

        RobotState.IDLE,

        RobotState.LISTENING,

        RobotState.THINKING,

        RobotState.SPEAKING,

        RobotState.GREETING,

        RobotState.ATTENTION,

        RobotState.GOODBYE

    }

    if state not in valid_states:

        return {

            "status": "error",

            "message":
                f"Invalid robot state: {state}"

        }

    robot.set_state(state)

    return {

        "status": "success" if robot.connected else "warning",

        "state": robot.current_state,

        "connected": robot.connected,

        "message": (
            "State updated."
            if robot.connected
            else "Backend state updated, but ESP32 is not connected."
        )

    }


# ============================================================
# TEST ROBOT
# ============================================================

@app.get("/robot/test")
async def robot_test():

    robot.set_state(
        RobotState.GREETING
    )

    return {

        "status": "success",

        "message":
            "Robot test animation started."

    }


# ============================================================
# MANUAL SERVO ANGLE
# ============================================================

@app.post("/robot/angle")
async def robot_angle(data: dict):

    try:

        angle = int(
            data.get(
                "angle",
                robot.CENTER_ANGLE
            )
        )

        accepted_angle = max(robot.MIN_ANGLE, min(robot.MAX_ANGLE, angle))
        robot.send_angle(accepted_angle)

        return {

            "status": "success" if robot.connected else "warning",

            "angle": accepted_angle,

            "connected": robot.connected,

            "message": (
                "Angle command sent."
                if robot.connected
                else "Angle was validated, but ESP32 is not connected."
            )

        }

    except Exception as e:

        return {

            "status": "error",

            "message": str(e)

        }


# ============================================================
# STOP ROBOT
# ============================================================

@app.post("/robot/stop")
async def robot_stop():

    robot.stop_animation()
    robot.stop_servo()

    # Report IDLE after stopping. set_state() can restart IDLE later
    # because it checks whether an animation thread is actually alive.
    robot.current_state = RobotState.IDLE

    return {

        "status": "success",

        "message":
            "Robot stopped."

    }


# ============================================================
# VIDEO FRAME
# ============================================================

@app.post("/video-frame")
async def video_frame(file: UploadFile = File(...)):
    global INTERVIEW_STARTED_AT
    try:
        data = await file.read()
        if not data:
            return {"status": "error", "message": "Empty video frame."}

        np_arr = np.frombuffer(data, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if frame is None:
            return {"status": "error", "message": "Could not decode image."}

        if INTERVIEW_STARTED_AT is None:
            # Allow testing the endpoint directly, while the normal app path
            # resets the clock in /start-interview.
            with telemetry_lock:
                if INTERVIEW_STARTED_AT is None:
                    INTERVIEW_STARTED_AT = time.time()

        record = _process_interview_frame(frame)
        return {
            "status": "success",
            "face_detected": record["face_detected"],
            "gaze": record["gaze"],
            "speech": record["speech"],
            "expression": record["expression"],
            "blink_count": record["current_blink_total"],
            "timestamp_seconds": record["timestamp_seconds"]
        }
    except Exception as e:
        print("[VIDEO] Frame processing error:", e)
        return {"status": "error", "message": str(e)}


# ============================================================
# ROOT
# ============================================================

@app.get("/")
async def root():

    return {

        "status": "online",

        "application":
            "Voice Based AI Interviewer",

        "session":
            CURRENT_SESSION_ID,

        "robot_state":
            robot.current_state,

        "robot_connected":
            robot.connected

    }


# ============================================================
# RUN:
#
# uvicorn FinalBackend:app --reload
#
# ============================================================

















# # ============================================================
# # FINAL BACKEND - VOICE BASED AI INTERVIEWER
# # ============================================================

# from fastapi import FastAPI, UploadFile, File
# from fastapi.responses import FileResponse, StreamingResponse
# from fastapi.middleware.cors import CORSMiddleware

# from contextlib import asynccontextmanager

# import pdfplumber
# import os
# import asyncio
# import uuid
# import json
# import time
# import hashlib
# import threading

# import cv2
# import numpy as np
# import mediapipe as mp

# from google.adk.agents import LlmAgent
# from google.adk.models.google_llm import Gemini
# from google.adk.sessions import InMemorySessionService
# from google.adk.runners import Runner
# from google.genai import types

# from mediapipe.tasks import python
# from mediapipe.tasks.python import vision

# from interview_event_detector1 import analyze_expressions
# from interview_report_generator import generate_interview_report

# import whisper
# import requests  # For WiFi communication with ESP32

# import pyttsx3


# GOOGLE_API_KEY = "AQ.Ab8RN6KsFdoZj_CiRKExRyTTFkNkyTCmjbpMifG_1gq2rPmGRw"
# os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# # ============================================================
# # CONFIGURATION
# # ============================================================

# # ESP32 Serial Configuration (Legacy - for serial communication)
# ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
# ESP32_BAUD = 115200

# # ESP32 WiFi Configuration (New - for wireless communication)
# ESP32_IP = os.getenv("ESP32_IP", "192.168.1.100")  # ESP32's IP address
# ESP32_PORT_HTTP = 80  # HTTP server port on ESP32
# USE_WIFI = os.getenv("USE_WIFI", "true").lower() == "true"  # Set to "true" to use WiFi

# APP_NAME = "InterviewApp"
# USER_ID = "demo_candidate"

# CURRENT_SESSION_ID = None

# # Prevent two /transcribe requests from being processed together.
# transcribe_lock = asyncio.Lock()

# # Duplicate request protection.
# LAST_AUDIO_HASH = None
# LAST_MODEL_RESPONSE = None

# # ============================================================
# # FILE PATHS
# # ============================================================

# BASE_DIR = os.getenv("INTERVIEW_DATA_DIR", os.path.dirname(os.path.abspath(__file__)))

# RESUME_PATH = os.path.join(BASE_DIR, "uploaded_resume.pdf")
# AUDIO_PATH = os.path.join(BASE_DIR, "recording.webm")
# CONVERSATION_PATH = os.path.join(BASE_DIR, "conversation.json")
# EXPRESSIONS_PATH = os.path.join(BASE_DIR, "expressions.log")
# EVENTS_PATH = os.path.join(BASE_DIR, "events.json")
# COMPRESSED_EVENTS_PATH = os.path.join(BASE_DIR, "compressed_events.json")


# # ============================================================
# # ROBOT STATES
# # ============================================================

# class RobotState:

#     IDLE = "IDLE"
#     LISTENING = "LISTENING"
#     THINKING = "THINKING"
#     SPEAKING = "SPEAKING"
#     GREETING = "GREETING"
#     ATTENTION = "ATTENTION"
#     GOODBYE = "GOODBYE"


# # ============================================================
# # ROBOT HEAD CONTROLLER
# # ============================================================

# class RobotHeadController:

#     def __init__(self):

#         self.serial_conn = None
#         self.connected = False

#         self.current_state = RobotState.IDLE

#         self.animation_thread = None
#         self.animation_running = False

#         self.lock = threading.Lock()

#         self.engine = None

#         # Servo configuration

#         # Servo configuration
#         self.MIN_ANGLE = 40
#         self.MAX_ANGLE = 140
#         self.CENTER_ANGLE = 90

#         # Smooth physical movement
#         self.STEP_DELAY = 0.02

#         # Animation control
#         self.animation_thread = None
#         self.animation_running = False
#         self.animation_id = 0

#         self.lock = threading.Lock()

#         # WiFi/HTTP configuration
#         self.use_wifi = USE_WIFI
#         self.esp32_url = f"http://{ESP32_IP}:{ESP32_PORT_HTTP}"


#     # --------------------------------------------------------
#     # CONNECT ESP32
#     # --------------------------------------------------------

#     def connect(self):

#         if self.use_wifi:
#             self.connect_wifi()
#         else:
#             self.connect_serial()

#     def connect_serial(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via Serial on {ESP32_PORT}...")

#             self.serial_conn = serial.Serial(
#                 ESP32_PORT,
#                 ESP32_BAUD,
#                 timeout=1
#             )

#             time.sleep(2)

#             self.connected = True

#             print("[ROBOT] ESP32 connected successfully via Serial.")

#             self.send_angle(self.CENTER_ANGLE)

#         except Exception as e:

#             print(f"[ROBOT] ESP32 Serial connection failed: {e}")

#             self.connected = False
#             self.serial_conn = None

#     def connect_wifi(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via WiFi at {self.esp32_url}...")

#             # Test connection by sending a status request
#             response = requests.get(
#                 f"{self.esp32_url}/status",
#                 timeout=5
#             )

#             if response.status_code == 200:
#                 self.connected = True
#                 print("[ROBOT] ESP32 connected successfully via WiFi.")
#                 print(f"[ROBOT] ESP32 Status: {response.json()}")
#                 self.send_angle(self.CENTER_ANGLE)
#             else:
#                 print(f"[ROBOT] ESP32 WiFi connection failed: HTTP {response.status_code}")
#                 self.connected = False

#         except Exception as e:

#             print(f"[ROBOT] ESP32 WiFi connection failed: {e}")
#             self.connected = False

#     # --------------------------------------------------------
#     # DISCONNECT
#     # --------------------------------------------------------

#     def disconnect(self):

#         self.stop_animation()

#         try:

#             if self.use_wifi:
#                 self.send_command("STOP")
#             elif self.serial_conn and self.serial_conn.is_open:
#                 self.send_command("STOP")
#                 self.serial_conn.close()

#         except Exception as e:

#             print(f"[ROBOT] Disconnect error: {e}")

#         self.connected = False

#         print("[ROBOT] ESP32 disconnected.")

#     # --------------------------------------------------------
#     # SEND COMMAND
#     # --------------------------------------------------------

#     def send_command(self, command):

#         if not self.connected:
#             return

#         try:

#             if self.use_wifi:
#                 self.send_command_wifi(command)
#             else:
#                 self.send_command_serial(command)

#         except Exception as e:

#             print(f"[ROBOT] Command send error: {e}")

#     def send_command_serial(self, command):

#         try:

#             with self.lock:

#                 self.serial_conn.write(
#                     (command + "\n").encode()
#                 )

#                 self.serial_conn.flush()

#         except Exception as e:

#             print(f"[ROBOT] Serial write error: {e}")

#     def send_command_wifi(self, command):

#         try:

#             with self.lock:

#                 response = requests.post(
#                     f"{self.esp32_url}/command",
#                     data=command,
#                     timeout=5
#                 )

#                 if response.status_code == 200:
#                     print(f"[ROBOT] WiFi command sent: {command}")
#                 else:
#                     print(f"[ROBOT] WiFi command failed: HTTP {response.status_code}")

#         except Exception as e:

#             print(f"[ROBOT] WiFi write error: {e}")

#     # --------------------------------------------------------
#     # SEND SERVO ANGLE
#     # --------------------------------------------------------

#     def send_angle(self, angle):

#         angle = max(
#             self.MIN_ANGLE,
#             min(self.MAX_ANGLE, int(angle))
#         )

#         self.send_command(f"ANGLE:{angle}")

#     # --------------------------------------------------------
#     # STOP SERVO
#     # --------------------------------------------------------

#     def stop_servo(self):

#         self.send_command("STOP")

#     # --------------------------------------------------------
#     # ANIMATION
#     # --------------------------------------------------------

    
#     def start_animation(self, state):
#         self.stop_animation()

#         self.animation_running = True
#         generation = self.animation_id

#         self.animation_thread = threading.Thread(
#             target=self.animation_loop,
#             args=(state, generation),
#             daemon=True
#         )
#         self.animation_thread.start()

#     def stop_animation(self):
#         self.animation_running = False

#         # Invalidate every older animation thread.
#         self.animation_id += 1

#         old_thread = self.animation_thread

#         if (
#             old_thread
#             and old_thread.is_alive()
#             and old_thread != threading.current_thread()
#         ):
#             old_thread.join(timeout=0.7)

#         self.animation_thread = None


#     # --------------------------------------------------------
#     # ANIMATION LOOP
#     # --------------------------------------------------------

    
#     def animation_loop(self, state, generation):
#         """
#         State-driven robot head animation.

#         The backend owns the animation.
#         ESP32 receives ANGLE commands only.
#         """

#         def active():
#             return (
#                 self.animation_running
#                 and generation == self.animation_id
#             )

#         def move(angle, pause=0.0):
#             if not active():
#                 return False

#             self.send_angle(angle)

#             if pause > 0:
#                 deadline = time.monotonic() + pause

#                 while active() and time.monotonic() < deadline:
#                     time.sleep(0.05)

#             return active()

#         try:
#             # ------------------------------------------
#             # IDLE: calm, centered, occasional movement
#             # ------------------------------------------
#             if state == RobotState.IDLE:
#                 move(90)
#                 # Do not continuously move while idle.
#                 return

#             # ------------------------------------------
#             # LISTENING: attentive, deliberate head tilt
#             # ------------------------------------------
            
#             elif state == RobotState.LISTENING:
#                 # Tilt once and hold the listening pose.
#                 if not move(76, 0.8):
#                     return

#                 # Stay tilted until another state is requested.
#                 while active():
#                     time.sleep(0.05)


#             # ------------------------------------------
#             # THINKING: look aside, pause, return
#             # ------------------------------------------
#             elif state == RobotState.THINKING:
#                 if not move(108, 1.4):
#                     return

#                 while active():
#                     if not move(102, 1.8):
#                         break
#                     if not move(110, 1.2):
#                         break
#                     if not move(90, 2.5):
#                         break

#             # ------------------------------------------
#             # SPEAKING: restrained conversational gestures
#             # ------------------------------------------
#             elif state == RobotState.SPEAKING:
#                 if not move(90):
#                     return

#                 while active():
#                     if not move(98, 0.45):
#                         break
#                     if not move(90, 1.0):
#                         break
#                     if not move(82, 0.45):
#                         break
#                     if not move(90, 1.5):
#                         break

#             # ------------------------------------------
#             # GREETING: one clear welcoming gesture
#             # ------------------------------------------
#             elif state == RobotState.GREETING:
#                 if not move(72, 0.45):
#                     return
#                 if not move(108, 0.55):
#                     return
#                 if not move(78, 0.45):
#                     return
#                 move(90, 0.8)

#             # ------------------------------------------
#             # ATTENTION: turn toward the candidate
#             # ------------------------------------------
#             elif state == RobotState.ATTENTION:
#                 if not move(110, 0.8):
#                     return
#                 if not move(90, 1.0):
#                     return

#                 while active():
#                     if not move(96, 0.8):
#                         break
#                     if not move(90, 2.5):
#                         break

#             # ------------------------------------------
#             # GOODBYE: deliberate farewell movement
#             # ------------------------------------------
#             elif state == RobotState.GOODBYE:
#                 if not move(72, 0.45):
#                     return
#                 if not move(108, 0.55):
#                     return
#                 if not move(72, 0.45):
#                     return
#                 move(90, 1.0)

#         except Exception as e:
#             print(f"[ROBOT] Animation error: {e}")

#     # --------------------------------------------------------
#     # SET ROBOT STATE
#     # --------------------------------------------------------

#     def set_state(self, new_state):

#         if new_state == self.current_state:
#             return

#         print(
#             f"[ROBOT] STATE: "
#             f"{self.current_state} -> {new_state}"
#         )

#         self.current_state = new_state

#         self.start_animation(new_state)

#     # --------------------------------------------------------
#     # PYTTSX3 SPEAK
#     # --------------------------------------------------------

#     def speak(self, text):

#         """
#         Optional backend TTS.

#         CURRENT PROJECT FLOW:
#         Browser SpeechSynthesis handles the actual voice.

#         Therefore this function is NOT called by the ADK
#         callback.
#         """

#         if not text:
#             return

#         if self.engine is None:

#             try:

#                 self.engine = pyttsx3.init()

#             except Exception as e:

#                 print(
#                     f"[ROBOT] pyttsx3 initialization failed: {e}"
#                 )

#                 return

#         self.set_state(RobotState.SPEAKING)

#         try:

#             self.engine.say(text)
#             self.engine.runAndWait()

#         except Exception as e:

#             print(f"[ROBOT] TTS error: {e}")

#         finally:

#             self.set_state(RobotState.LISTENING)


# # ============================================================
# # CREATE ROBOT
# # ============================================================

# robot = RobotHeadController()


# # ============================================================
# # RESUME TEXT EXTRACTION
# # ============================================================

# def getText() -> str:

#     resume_path = RESUME_PATH

#     if not os.path.exists(resume_path):

#         print(
#             f"[RESUME] Uploaded resume not found: "
#             f"{resume_path}"
#         )

#         resume_path = "sample_resume.pdf"

#     if not os.path.exists(resume_path):

#         print("[RESUME] No resume PDF found.")

#         return ""

#     text = ""

#     try:

#         with pdfplumber.open(resume_path) as pdf:

#             for page in pdf.pages:

#                 page_text = page.extract_text()

#                 if page_text:

#                     text += page_text + "\n"

#         print(
#             f"[RESUME] Extracted "
#             f"{len(text)} characters."
#         )

#         return text

#     except Exception as e:

#         print(
#             f"[RESUME] Error extracting resume: {e}"
#         )

#         return ""


# # ============================================================
# # ADK CALLBACK
# # ============================================================

# def Speak(callback_context):

#     """
#     ADK callback.

#     IMPORTANT:
#     The browser is responsible for actual voice output.

#     Therefore this callback DOES NOT call pyttsx3.
#     """

#     print(
#         "[AGENT] Speak callback triggered - "
#         "browser will handle TTS"
#     )

#     return None


# # ============================================================
# # GEMINI CONFIGURATION
# # ============================================================

# retry_config = types.HttpRetryOptions(

#     attempts=5,

#     exp_base=7,

#     initial_delay=1,

#     http_status_codes=[
#         429,
#         500,
#         503,
#         504
#     ]
# )


# # ============================================================
# # CAMERA AGENT
# # ============================================================

# CameraAgent = LlmAgent(
#     name="CamAgent"
# )


# # ============================================================
# # INTERVIEW AGENT
# # ============================================================

# interviewAgent = LlmAgent(

#     name="InterviewAgent",

#     model=Gemini(
#         model="gemini-3.5-flash-lite",
#         retry_options=retry_config
#     ),

#     description=(
#         "You are an AI professional interviewer "
#         "who interviews candidates based on their resumes."
#     ),

#     instruction="""

# You are a professional interviewer conducting a
# technical recruitment interview.

# IMPORTANT RULES:

# 1. Use the getText() tool to extract the candidate's
#    resume text.

# 2. Study the candidate's resume carefully.

# 3. Ask ONLY ONE question at a time.

# 4. After asking a question, WAIT for the candidate's
#    answer before asking the next question.

# 5. Ask at least 2 questions about the candidate
#    personally, such as:
#    - Introduction
#    - Background
#    - Career goals
#    - Interests

# 6. Ask at least 4 technical questions based specifically
#    on the skills, technologies and projects present in
#    the candidate's resume.

# 7. Do NOT invent technologies or projects that are not
#    present in the resume.

# 8. Questions should progressively evaluate:
#    - Understanding
#    - Practical knowledge
#    - Problem solving
#    - Technical depth

# 9. Keep each interviewer response concise and natural
#    because it will be converted into speech.

# 10. Do not ask multiple questions in one response.

# 11. Do not repeat a question that has already been asked.

# 12. Maintain awareness of the previous conversation.

# 13. After all required questions have been completed,
#     provide an overall summary of the candidate's
#     performance.

# 14. The final summary should include:
#     - Strengths
#     - Technical knowledge
#     - Communication
#     - Problem solving
#     - Areas for improvement
#     - Overall assessment

# 15. Always use the candidate's resume information when
#     discussing their background, skills and projects.

# 16. Never generate a second answer to the same candidate
#     response.

# """,

#     after_agent_callback=Speak,

#     tools=[getText]
# )


# # ============================================================
# # ADK SESSION SERVICE
# # ============================================================

# session_service = InMemorySessionService()


# # ============================================================
# # RUNNER
# # ============================================================

# runner = Runner(

#     agent=interviewAgent,

#     app_name=APP_NAME,

#     session_service=session_service
# )


# # ============================================================
# # RUN ADK SESSION
# # ============================================================

# async def run_session(
#     runner: Runner,
#     query: str,
#     session_id: str
# ):

#     print()
#     print("=" * 60)
#     print("[ADK] NEW MODEL REQUEST")
#     print(f"[ADK] Session ID : {session_id}")
#     print(f"[ADK] User       : {USER_ID}")
#     print(f"[ADK] Query      : {query}")
#     print("=" * 60)

#     if not query or not query.strip():

#         print(
#             "[ADK] Empty user query. "
#             "Skipping model request."
#         )

#         return None

#     query_content = types.Content(

#         role="user",

#         parts=[
#             types.Part(
#                 text=query.strip()
#             )
#         ]

#     )

#     model_text = None

#     try:

#         async for event in runner.run_async(

#             user_id=USER_ID,

#             session_id=session_id,

#             new_message=query_content

#         ):

#             # Only use the final response.

#             if not event.is_final_response():
#                 continue

#             if not event.content:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     model_text = part.text.strip()

#                     print()
#                     print("[ADK] FINAL MODEL RESPONSE:")
#                     print(model_text)
#                     print()

#                     break

#             if model_text:
#                 break

#     except Exception as e:

#         print(
#             f"[ADK] Model execution error: {e}"
#         )

#         raise

#     if not model_text:

#         print(
#             "[ADK] WARNING: "
#             "No final model response received."
#         )

#     return model_text


# # ============================================================
# # SAVE CONVERSATION
# # ============================================================

# def save_conversation(session):

#     conversation_data = []

#     try:

#         if not session:
#             return conversation_data

#         for event in session.events:

#             if not event.content:
#                 continue

#             role = event.content.role

#             if role not in ["user", "model"]:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     conversation_data.append({

#                         "role": role,

#                         "text": part.text.strip()

#                     })

#         os.makedirs(
#             os.path.dirname(CONVERSATION_PATH),
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 conversation_data,
#                 f,
#                 indent=4,
#                 ensure_ascii=False
#             )

#         print(
#             f"[CONVERSATION] Saved "
#             f"{len(conversation_data)} messages."
#         )

#     except Exception as e:

#         print(
#             f"[CONVERSATION] Save error: {e}"
#         )

#     return conversation_data


# # ============================================================
# # FASTAPI LIFESPAN
# # ============================================================

# @asynccontextmanager
# async def lifespan(app: FastAPI):

#     print()
#     print("=" * 60)
#     print("VOICE BASED AI INTERVIEWER BACKEND")
#     print("=" * 60)

#     robot.connect()

#     if robot.connected:

#         robot.current_state = RobotState.IDLE

#         robot.start_animation(
#             RobotState.IDLE
#         )

#     yield

#     print(
#         "[SERVER] Shutting down..."
#     )

#     robot.disconnect()


# # ============================================================
# # FASTAPI APP
# # ============================================================

# app = FastAPI(
#     lifespan=lifespan
# )


# # ============================================================
# # CORS
# # ============================================================

# app.add_middleware(

#     CORSMiddleware,

#     allow_origins=["*"],

#     allow_credentials=True,

#     allow_methods=["*"],

#     allow_headers=["*"]

# )


# # ============================================================
# # UPLOAD RESUME
# # ============================================================

# @app.post("/upload-resume")
# async def upload_resume(
#     file: UploadFile = File(...)
# ):

#     try:

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         data = await file.read()

#         with open(
#             RESUME_PATH,
#             "wb"
#         ) as f:

#             f.write(data)

#         print(
#             f"[RESUME] Uploaded: "
#             f"{len(data)} bytes"
#         )

#         return {

#             "status": "success",

#             "message": "Resume uploaded successfully."

#         }

#     except Exception as e:

#         print(
#             f"[RESUME] Upload error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # START NEW INTERVIEW
# # ============================================================

# @app.post("/start-interview")
# async def start_interview():

#     global CURRENT_SESSION_ID
#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE

#     try:

#         # ----------------------------------------------------
#         # CREATE UNIQUE SESSION
#         # ----------------------------------------------------

#         CURRENT_SESSION_ID = (
#             f"interview_{uuid.uuid4().hex}"
#         )

#         print()
#         print("=" * 60)
#         print("[INTERVIEW] NEW INTERVIEW STARTED")
#         print(
#             f"[INTERVIEW] Session: "
#             f"{CURRENT_SESSION_ID}"
#         )
#         print("=" * 60)

#         # ----------------------------------------------------
#         # RESET DUPLICATE PROTECTION
#         # ----------------------------------------------------

#         LAST_AUDIO_HASH = None
#         LAST_MODEL_RESPONSE = None

#         # ----------------------------------------------------
#         # CREATE ADK SESSION
#         # ----------------------------------------------------

#         await session_service.create_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         # ----------------------------------------------------
#         # CLEAR OLD INTERVIEW DATA
#         # ----------------------------------------------------

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 [],
#                 f
#             )

#         with open(
#             EXPRESSIONS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         with open(
#             EVENTS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         if os.path.exists(
#             COMPRESSED_EVENTS_PATH
#         ):

#             with open(
#                 COMPRESSED_EVENTS_PATH,
#                 "w",
#                 encoding="utf-8"
#             ) as f:

#                 json.dump(
#                     [],
#                     f
#                 )

#         # ----------------------------------------------------
#         # ROBOT LISTENING
#         # ----------------------------------------------------

#         # ----------------------------------------------------
#         # ROBOT STATE
#         # The frontend controls the interview's visual sequence:
#         # GREETING -> SPEAKING -> LISTENING
#         # ----------------------------------------------------

#         # Do not set LISTENING here.
#         # The frontend will send the appropriate state after
#         # the interview-start request has completed.

#         return {

#             "status": "success",

#             "message":
#                 "New interview session started.",

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             f"[INTERVIEW] Start error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # TRANSCRIBE + AI RESPONSE
# # ============================================================

# @app.post("/transcribe")
# async def transcribe(
#     audio: UploadFile = File(...)
# ):

#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE
#     global CURRENT_SESSION_ID

#     # ========================================================
#     # IMPORTANT:
#     # Only one transcription request can run at a time.
#     # ========================================================

#     async with transcribe_lock:

#         request_id = uuid.uuid4().hex[:8]

#         print()
#         print("=" * 70)
#         print(
#             f"[TRANSCRIBE] NEW REQUEST "
#             f"ID={request_id}"
#         )
#         print("=" * 70)

#         try:

#             # ------------------------------------------------
#             # CHECK SESSION
#             # ------------------------------------------------

#             if not CURRENT_SESSION_ID:

#                 print(
#                     "[TRANSCRIBE] ERROR: "
#                     "No active interview session."
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "Please start a new interview first."

#                 }

#             # ------------------------------------------------
#             # ROBOT THINKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.THINKING
#             )

#             # ------------------------------------------------
#             # ANALYZE FACE EXPRESSIONS
#             # ------------------------------------------------

#             try:

#                 analyze_expressions()

#             except Exception as e:

#                 print(
#                     "[VISION] Expression analysis error:",
#                     e
#                 )

#             # ------------------------------------------------
#             # READ AUDIO
#             # ------------------------------------------------

#             audio_data = await audio.read()

#             if not audio_data:

#                 print(
#                     "[TRANSCRIBE] Empty audio."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not hear your answer. "
#                         "Please try again."

#                 }

#             print(
#                 f"[TRANSCRIBE] Audio size: "
#                 f"{len(audio_data)} bytes"
#             )

#             # ------------------------------------------------
#             # CREATE AUDIO HASH
#             # ------------------------------------------------

#             audio_hash = hashlib.sha256(
#                 audio_data
#             ).hexdigest()

#             print(
#                 f"[TRANSCRIBE] Audio hash: "
#                 f"{audio_hash[:16]}..."
#             )

#             # ------------------------------------------------
#             # DUPLICATE AUDIO CHECK
#             # ------------------------------------------------

#             if (
#                 LAST_AUDIO_HASH is not None
#                 and audio_hash == LAST_AUDIO_HASH
#             ):

#                 print()
#                 print(
#                     "[TRANSCRIBE] DUPLICATE AUDIO "
#                     "DETECTED."
#                 )

#                 print(
#                     "[TRANSCRIBE] "
#                     "Gemini will NOT be called again."
#                 )

#                 robot.set_state(
#                     RobotState.SPEAKING
#                 )

#                 return {

#                     "transcript":
#                         "(duplicate request)",

#                     "model":
#                         LAST_MODEL_RESPONSE
#                         or
#                         "Please continue."

#                 }

#             # ------------------------------------------------
#             # SAVE AUDIO
#             # ------------------------------------------------

#             os.makedirs(
#                 BASE_DIR,
#                 exist_ok=True
#             )

#             with open(
#                 AUDIO_PATH,
#                 "wb"
#             ) as f:

#                 f.write(audio_data)

#             print(
#                 f"[TRANSCRIBE] Saved audio: "
#                 f"{AUDIO_PATH}"
#             )

#             # ------------------------------------------------
#             # LOAD WHISPER
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Loading model..."
#             )

#             model = whisper.load_model(
#                 "base"
#             )

#             print(
#                 "[WHISPER] Model loaded."
#             )

#             # ------------------------------------------------
#             # TRANSCRIBE
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Transcribing..."
#             )

#             result = model.transcribe(
#                 AUDIO_PATH
#             )

#             text = (
#                 result
#                 .get("text", "")
#                 .strip()
#             )

#             print()
#             print(
#                 "[WHISPER] TRANSCRIPT:"
#             )
#             print(text)
#             print()

#             # ------------------------------------------------
#             # EMPTY TRANSCRIPT
#             # ------------------------------------------------

#             if not text:

#                 print(
#                     "[WHISPER] Empty transcript."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not understand your "
#                         "answer. Please try again."

#                 }

#             # ------------------------------------------------
#             # STORE HASH ONLY AFTER SUCCESSFUL TRANSCRIPTION
#             # ------------------------------------------------

#             LAST_AUDIO_HASH = audio_hash

#             # ------------------------------------------------
#             # VERIFY SESSION
#             # ------------------------------------------------

#             print(
#                 "[ADK] Using session:",
#                 CURRENT_SESSION_ID
#             )

#             # ------------------------------------------------
#             # SEND TO GEMINI
#             # ------------------------------------------------

#             model_response = await run_session(

#                 runner,

#                 text,

#                 CURRENT_SESSION_ID

#             )

#             # ------------------------------------------------
#             # HANDLE EMPTY MODEL RESPONSE
#             # ------------------------------------------------

#             if not model_response:

#                 print(
#                     "[ADK] No model response."
#                 )

#                 model_response = (
#                     "Thank you for your answer. "
#                     "Let's continue."
#                 )

#             # ------------------------------------------------
#             # SAVE LAST MODEL RESPONSE
#             # ------------------------------------------------

#             LAST_MODEL_RESPONSE = model_response

#             # ------------------------------------------------
#             # READ SESSION ONLY FOR LOGGING
#             #
#             # IMPORTANT:
#             # This does NOT call Gemini again.
#             # ------------------------------------------------

#             session = await session_service.get_session(

#                 app_name=APP_NAME,

#                 user_id=USER_ID,

#                 session_id=CURRENT_SESSION_ID

#             )

#             # ------------------------------------------------
#             # SAVE CONVERSATION
#             # ------------------------------------------------

#             save_conversation(
#                 session
#             )

#             # ------------------------------------------------
#             # ROBOT SPEAKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.SPEAKING
#             )

#             print()
#             print("=" * 70)
#             print(
#                 f"[TRANSCRIBE] REQUEST "
#                 f"{request_id} COMPLETE"
#             )
#             print(
#                 "[TRANSCRIBE] Candidate:",
#                 text
#             )
#             print(
#                 "[TRANSCRIBE] AI:",
#                 model_response
#             )
#             print("=" * 70)
#             print()

#             # ------------------------------------------------
#             # RETURN TO FRONTEND
#             # ------------------------------------------------

#             return {

#                 "transcript": text,

#                 "model": model_response

#             }

#         except Exception as e:

#             print()
#             print(
#                 "[TRANSCRIBE] ERROR:",
#                 str(e)
#             )

#             import traceback

#             traceback.print_exc()

#             robot.set_state(
#                 RobotState.LISTENING
#             )

#             return {

#                 "transcript": "",

#                 "model":
#                     "Sorry, I encountered an error. "
#                     "Please try again."

#             }


# # ============================================================
# # GENERATE FINAL REPORT
# # ============================================================

# @app.post("/generate-report")
# async def generate_report():

#     global CURRENT_SESSION_ID

#     print()
#     print("=" * 60)
#     print("[REPORT] GENERATING FINAL INTERVIEW REPORT")
#     print("=" * 60)

#     try:

#         if not CURRENT_SESSION_ID:

#             return {

#                 "status": "error",

#                 "message":
#                     "No active interview session."

#             }

#         print(
#             "[REPORT] Session:",
#             CURRENT_SESSION_ID
#         )

#         # ----------------------------------------------------
#         # GET CURRENT SESSION
#         # ----------------------------------------------------

#         session = await session_service.get_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         if not session:

#             return {

#                 "status": "error",

#                 "message":
#                     "Interview session not found."

#             }

#         # ----------------------------------------------------
#         # GENERATE REPORT
#         # ----------------------------------------------------

#         report = generate_interview_report(

#             session_service=session_service,

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID,

#             llm_agent=interviewAgent

#         )

#         print(
#             "[REPORT] Report generated successfully."
#         )

#         robot.set_state(
#             RobotState.GOODBYE
#         )

#         return {

#             "status": "success",

#             "report": report,

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             "[REPORT] Error:",
#             str(e)
#         )

#         import traceback

#         traceback.print_exc()

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROBOT STATE API
# # ============================================================

# @app.get("/robot-state")
# async def robot_state():

#     return {

#         "state":
#             robot.current_state,

#         "connected":
#             robot.connected

#     }


# # ============================================================
# # SET ROBOT STATE
# # ============================================================

# @app.post("/robot/state")
# async def set_robot_state(data: dict):

#     state = data.get("state")

#     valid_states = {

#         RobotState.IDLE,

#         RobotState.LISTENING,

#         RobotState.THINKING,

#         RobotState.SPEAKING,

#         RobotState.GREETING,

#         RobotState.ATTENTION,

#         RobotState.GOODBYE

#     }

#     if state not in valid_states:

#         return {

#             "status": "error",

#             "message":
#                 f"Invalid robot state: {state}"

#         }

#     robot.set_state(state)

#     return {

#         "status": "success",

#         "state":
#             robot.current_state

#     }


# # ============================================================
# # TEST ROBOT
# # ============================================================

# @app.get("/robot/test")
# async def robot_test():

#     robot.set_state(
#         RobotState.GREETING
#     )

#     return {

#         "status": "success",

#         "message":
#             "Robot test animation started."

#     }


# # ============================================================
# # MANUAL SERVO ANGLE
# # ============================================================

# @app.post("/robot/angle")
# async def robot_angle(data: dict):

#     try:

#         angle = int(
#             data.get(
#                 "angle",
#                 robot.CENTER_ANGLE
#             )
#         )

#         robot.send_angle(angle)

#         return {

#             "status": "success",

#             "angle": angle

#         }

#     except Exception as e:

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # STOP ROBOT
# # ============================================================

# @app.post("/robot/stop")
# async def robot_stop():

#     robot.stop_animation()

#     robot.stop_servo()

#     robot.current_state = RobotState.IDLE

#     return {

#         "status": "success",

#         "message":
#             "Robot stopped."

#     }


# # ============================================================
# # VIDEO FRAME
# # ============================================================

# @app.post("/video-frame")
# async def video_frame(
#     file: UploadFile = File(...)
# ):

#     try:

#         data = await file.read()

#         if not data:

#             return {

#                 "status": "error",

#                 "message":
#                     "Empty video frame."

#             }

#         np_arr = np.frombuffer(
#             data,
#             np.uint8
#         )

#         frame = cv2.imdecode(
#             np_arr,
#             cv2.IMREAD_COLOR
#         )

#         if frame is None:

#             return {

#                 "status": "error",

#                 "message":
#                     "Could not decode image."

#             }

#         # ----------------------------------------------------
#         # MediaPipe processing can be performed here if needed.
#         # ----------------------------------------------------

#         return {

#             "status": "success"

#         }

#     except Exception as e:

#         print(
#             "[VIDEO] Frame processing error:",
#             e
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROOT
# # ============================================================

# @app.get("/")
# async def root():

#     return {

#         "status": "online",

#         "application":
#             "Voice Based AI Interviewer",

#         "session":
#             CURRENT_SESSION_ID,

#         "robot_state":
#             robot.current_state,

#         "robot_connected":
#             robot.connected

#     }


# # ============================================================
# # RUN:
# #
# # uvicorn FinalBackend:app --reload
# #
# # ============================================================








# # ============================================================
# # FINAL BACKEND - VOICE BASED AI INTERVIEWER
# # ============================================================

# from fastapi import FastAPI, UploadFile, File
# from fastapi.responses import FileResponse, StreamingResponse
# from fastapi.middleware.cors import CORSMiddleware

# from contextlib import asynccontextmanager

# import pdfplumber
# import os
# import asyncio
# import uuid
# import json
# import time
# import hashlib
# import threading

# import cv2
# import numpy as np
# import mediapipe as mp

# from google.adk.agents import LlmAgent
# from google.adk.models.google_llm import Gemini
# from google.adk.sessions import InMemorySessionService
# from google.adk.runners import Runner
# from google.genai import types

# from mediapipe.tasks import python
# from mediapipe.tasks.python import vision

# from interview_event_detector1 import analyze_expressions
# from interview_report_generator import generate_interview_report

# import whisper
# import requests  # For WiFi communication with ESP32

# # Optional legacy serial mode (used only when USE_WIFI=false).
# try:
#     import serial
# except ImportError:
#     serial = None

# import pyttsx3


# GOOGLE_API_KEY = "AQ.Ab8RN6KsFdoZj_CiRKExRyTTFkNkyTCmjbpMifG_1gq2rPmGRw"
# os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# # ============================================================
# # CONFIGURATION
# # ============================================================

# # ESP32 Serial Configuration (Legacy - for serial communication)
# ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
# ESP32_BAUD = 115200

# # ESP32 WiFi Configuration (New - for wireless communication)
# ESP32_IP = os.getenv("ESP32_IP", "10.61.133.200")  # ESP32's IP address
# ESP32_PORT_HTTP = 80  # HTTP server port on ESP32
# USE_WIFI = os.getenv("USE_WIFI", "true").lower() == "true"  # Set to "true" to use WiFi

# APP_NAME = "InterviewApp"
# USER_ID = "demo_candidate"

# CURRENT_SESSION_ID = None

# # Prevent two /transcribe requests from being processed together.
# transcribe_lock = asyncio.Lock()

# # Duplicate request protection.
# LAST_AUDIO_HASH = None
# LAST_MODEL_RESPONSE = None

# # ============================================================
# # FILE PATHS
# # ============================================================

# # Keep every backend-generated file in the existing Outsiders data folder.
# # This preserves the location used by the earlier backend version.
# BASE_DIR = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders"
# os.makedirs(BASE_DIR, exist_ok=True)

# RESUME_PATH = os.path.join(BASE_DIR, "uploaded_resume.pdf")
# AUDIO_PATH = os.path.join(BASE_DIR, "recording.webm")
# CONVERSATION_PATH = os.path.join(BASE_DIR, "conversation.json")
# EXPRESSIONS_PATH = os.path.join(BASE_DIR, "expressions.log")
# EVENTS_PATH = os.path.join(BASE_DIR, "events.json")
# COMPRESSED_EVENTS_PATH = os.path.join(BASE_DIR, "compressed_events.json")

# # Video telemetry and generated report artifacts.
# MODEL_PATH = os.path.join(BASE_DIR, "face_landmarker.task")
# INTERVIEW_LOG_PATH = os.path.join(BASE_DIR, "interview_log.json")
# REPORT_PDF_PATH = os.path.join(BASE_DIR, "interview_analysis_report.pdf")

# # The detector is created lazily so a missing model file does not prevent
# # the API and robot endpoints from starting. Video processing initializes it
# # when the first frame arrives.
# face_landmarker = None
# face_landmarker_lock = threading.Lock()
# telemetry_lock = threading.Lock()
# VIDEO_TIMELINE = []
# INTERVIEW_STARTED_AT = None
# BLINK_COUNT = 0
# BLINK_STATE = False


# # ============================================================
# # VIDEO TELEMETRY HELPERS (MediaPipe Tasks Face Landmarker)
# # ============================================================

# # Landmark indices from the supplied reference implementation.
# LIP_TOP, LIP_BOTTOM = 13, 14
# LIP_LEFT, LIP_RIGHT = 61, 291
# LEFT_IRIS = [468, 469, 470, 471]
# LEFT_EYE_INNER, LEFT_EYE_OUTER = 133, 33
# L_EYE_TOP, L_EYE_BOTTOM = 159, 145
# R_EYE_TOP, R_EYE_BOTTOM = 386, 374
# L_EYE_LEFT, L_EYE_RIGHT = 33, 133
# R_EYE_LEFT, R_EYE_RIGHT = 362, 263


# def _get_face_landmarker():
#     """Create and cache the MediaPipe detector when the model is available."""
#     global face_landmarker
#     with face_landmarker_lock:
#         if face_landmarker is not None:
#             return face_landmarker
#         if not os.path.isfile(MODEL_PATH):
#             raise FileNotFoundError(
#                 f"MediaPipe model not found: {MODEL_PATH}. "
#                 "Place face_landmarker.task beside the backend data files."
#             )
#         base_options = python.BaseOptions(model_asset_path=MODEL_PATH)
#         options = vision.FaceLandmarkerOptions(
#             base_options=base_options,
#             output_face_blendshapes=True,
#             output_facial_transformation_matrixes=False,
#             num_faces=1
#         )
#         face_landmarker = vision.FaceLandmarker.create_from_options(options)
#         print(f"[VIDEO] MediaPipe FaceLandmarker loaded: {MODEL_PATH}")
#         return face_landmarker


# def _point_distance(p1, p2):
#     return float(np.linalg.norm(np.asarray(p1, dtype=np.float32) - np.asarray(p2, dtype=np.float32)))


# def _calculate_ear(coords, eye_top, eye_bottom, eye_left, eye_right):
#     vertical = _point_distance(coords[eye_top], coords[eye_bottom])
#     horizontal = _point_distance(coords[eye_left], coords[eye_right])
#     return vertical / (horizontal + 1e-6)


# def _write_json_atomic(path, data):
#     os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
#     temp_path = path + ".tmp"
#     with open(temp_path, "w", encoding="utf-8") as f:
#         json.dump(data, f, indent=2, ensure_ascii=False)
#     os.replace(temp_path, path)


# def _process_interview_frame(frame):
#     """Analyze one decoded BGR frame and append reference-style telemetry."""
#     global BLINK_COUNT, BLINK_STATE
#     detector = _get_face_landmarker()
#     height, width = frame.shape[:2]
#     rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#     mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
#     result = detector.detect(mp_image)
#     now = time.time()

#     with telemetry_lock:
#         started_at = INTERVIEW_STARTED_AT if INTERVIEW_STARTED_AT is not None else now
#         timestamp = round(max(0.0, now - started_at), 2)
#         record = {
#             "timestamp_seconds": timestamp,
#             "face_detected": False,
#             "gaze": "No Face Detected",
#             "speech": "Silent",
#             "expression": "Neutral",
#             "left_ear": None,
#             "right_ear": None,
#             "gaze_ratio": None,
#             "current_blink_total": BLINK_COUNT
#         }

#         if result.face_landmarks:
#             landmarks = result.face_landmarks[0]
#             coords = [(int(lm.x * width), int(lm.y * height)) for lm in landmarks]
#             record["face_detected"] = True

#             # Speaking: lip opening relative to mouth width, as in the reference.
#             if len(coords) > max(LIP_TOP, LIP_BOTTOM, LIP_LEFT, LIP_RIGHT):
#                 lip_dist = _point_distance(coords[LIP_TOP], coords[LIP_BOTTOM])
#                 lip_width = _point_distance(coords[LIP_LEFT], coords[LIP_RIGHT])
#                 if lip_dist / (lip_width + 1e-6) > 0.15:
#                     record["speech"] = "Speaking"

#             # Gaze estimate based on the left iris relative to the inner eye corner.
#             if len(coords) > max(LEFT_IRIS + [LEFT_EYE_INNER, LEFT_EYE_OUTER]):
#                 iris_center = np.mean([coords[i] for i in LEFT_IRIS], axis=0)
#                 eye_width = _point_distance(coords[LEFT_EYE_INNER], coords[LEFT_EYE_OUTER])
#                 gaze_dist = _point_distance(coords[LEFT_EYE_INNER], iris_center)
#                 gaze_ratio = gaze_dist / (eye_width + 1e-6)
#                 record["gaze_ratio"] = round(float(gaze_ratio), 4)
#                 record["gaze"] = "Eye-Contact" if 0.38 <= gaze_ratio <= 0.62 else "Looked Away"

#             # Blink counting via average eye aspect ratio (EAR).
#             required_eye_indices = max(L_EYE_TOP, L_EYE_BOTTOM, R_EYE_TOP, R_EYE_BOTTOM,
#                                        L_EYE_LEFT, L_EYE_RIGHT, R_EYE_LEFT, R_EYE_RIGHT)
#             if len(coords) > required_eye_indices:
#                 left_ear = _calculate_ear(coords, L_EYE_TOP, L_EYE_BOTTOM, L_EYE_LEFT, L_EYE_RIGHT)
#                 right_ear = _calculate_ear(coords, R_EYE_TOP, R_EYE_BOTTOM, R_EYE_LEFT, R_EYE_RIGHT)
#                 avg_ear = (left_ear + right_ear) / 2.0
#                 record["left_ear"] = round(left_ear, 4)
#                 record["right_ear"] = round(right_ear, 4)
#                 if avg_ear < 0.20:
#                     if not BLINK_STATE:
#                         BLINK_STATE = True
#                 elif BLINK_STATE:
#                     BLINK_COUNT += 1
#                     BLINK_STATE = False

#             # Interview expression priority matrix from the supplied reference.
#             if result.face_blendshapes:
#                 scores = {b.category_name: float(b.score) for b in result.face_blendshapes[0]}
#                 if scores.get("jawOpen", 0) > 0.35:
#                     expression = "Surprised"
#                 elif scores.get("mouthSmileLeft", 0) > 0.40 or scores.get("mouthSmileRight", 0) > 0.40:
#                     expression = "Smiling / Confident"
#                 elif scores.get("browDownLeft", 0) > 0.40 or scores.get("browDownRight", 0) > 0.40:
#                     expression = "Frowning / Deep Focus"
#                 elif scores.get("browOuterUpLeft", 0) > 0.35 or scores.get("mouthStretchLeft", 0) > 0.35:
#                     expression = "Anxious / Stressed"
#                 elif scores.get("mouthFrownLeft", 0) > 0.30 or scores.get("eyeLookInLeft", 0) > 0.40:
#                     expression = "Pensive / Evaluating"
#                 else:
#                     expression = "Neutral"
#                 record["blendshape_scores"] = scores
#                 record["expression"] = expression

#         record["current_blink_total"] = BLINK_COUNT
#         VIDEO_TIMELINE.append(record)
#         # Persist after every received frame so partial telemetry survives errors.
#         _write_json_atomic(INTERVIEW_LOG_PATH, VIDEO_TIMELINE)
#         # Keep the established event file available for existing project tooling.
#         _write_json_atomic(EVENTS_PATH, VIDEO_TIMELINE)
#         return record


# def _summarize_video_telemetry():
#     with telemetry_lock:
#         logs = list(VIDEO_TIMELINE)
#         blink_count = BLINK_COUNT
#     if not logs:
#         return {
#             "available": False,
#             "message": "No video frames were recorded during this interview.",
#             "frames_received": 0,
#             "face_detection_coverage_percent": 0.0,
#             "eye_contact_percent": None,
#             "looked_away_percent": None,
#             "speaking_frame_percent": None,
#             "blink_count": blink_count,
#             "blinks_per_minute": None,
#             "expression_percentages": {},
#             "timeline": []
#         }

#     total = len(logs)
#     face_logs = [x for x in logs if x.get("face_detected")]
#     observed = len(face_logs)
#     duration = max(float(logs[-1].get("timestamp_seconds", 0)), 0.0)
#     if INTERVIEW_STARTED_AT is not None:
#         duration = max(duration, time.time() - INTERVIEW_STARTED_AT)
#     gaze_valid = [x for x in face_logs if x.get("gaze") in ("Eye-Contact", "Looked Away")]
#     speaking = sum(1 for x in face_logs if x.get("speech") == "Speaking")
#     expression_names = ["Neutral", "Surprised", "Smiling / Confident", "Frowning / Deep Focus",
#                         "Anxious / Stressed", "Pensive / Evaluating"]
#     expression_pct = {}
#     for name in expression_names:
#         expression_pct[name] = round(100 * sum(1 for x in face_logs if x.get("expression") == name) / observed, 1) if observed else 0.0
#     eye_contact_pct = round(100 * sum(1 for x in gaze_valid if x.get("gaze") == "Eye-Contact") / len(gaze_valid), 1) if gaze_valid else None
#     looked_away_pct = round(100 * sum(1 for x in gaze_valid if x.get("gaze") == "Looked Away") / len(gaze_valid), 1) if gaze_valid else None
#     return {
#         "available": True,
#         "frames_received": total,
#         "face_detected_frames": observed,
#         "face_detection_coverage_percent": round(100 * observed / total, 1),
#         "session_duration_seconds": round(duration, 2),
#         "eye_contact_percent": eye_contact_pct,
#         "looked_away_percent": looked_away_pct,
#         "speaking_frame_percent": round(100 * speaking / observed, 1) if observed else None,
#         "blink_count": blink_count,
#         "blinks_per_minute": round(blink_count / (duration / 60), 1) if duration > 0 else None,
#         "expression_percentages": expression_pct,
#         "timeline": logs
#     }


# def _behavioral_recommendations(analytics):
#     if not analytics.get("available"):
#         return ["Video-based observations were unavailable; use the interview conversation and answers for evaluation."]
#     recs = []
#     gaze = analytics.get("eye_contact_percent")
#     if gaze is not None and gaze < 50:
#         recs.append("Camera engagement: consider positioning the camera near the screen and practising looking toward it while explaining answers.")
#     elif gaze is not None and gaze >= 70:
#         recs.append("Camera engagement: eye-contact estimates were consistently within the configured on-screen gaze range.")
#     coverage = analytics.get("face_detection_coverage_percent", 0)
#     if coverage < 60:
#         recs.append("Video quality: face detection coverage was limited. Improve lighting, camera framing, and keep the face unobstructed before drawing conclusions.")
#     expr = analytics.get("expression_percentages", {})
#     if expr.get("Smiling / Confident", 0) >= 8:
#         recs.append("Expression: smiling-related blendshape signals were observed; use these only as a descriptive observation, not proof of confidence.")
#     if expr.get("Frowning / Deep Focus", 0) >= 20:
#         recs.append("Expression: brow-lowering signals appeared frequently and may coincide with concentration; they cannot establish a candidate's mental state.")
#     if not recs:
#         recs.append("Continue practising clear, structured answers and review the recorded observations alongside the actual interview responses.")
#     return recs


# def _generate_comprehensive_pdf(ai_report, analytics, conversation, session_id):
#     """Build a detailed PDF combining interview content and video telemetry."""
#     from xml.sax.saxutils import escape
#     from reportlab.lib import colors
#     from reportlab.lib.pagesizes import letter
#     from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
#     from reportlab.lib.units import inch
#     from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

#     os.makedirs(BASE_DIR, exist_ok=True)
#     doc = SimpleDocTemplate(REPORT_PDF_PATH, pagesize=letter, rightMargin=0.62*inch,
#                             leftMargin=0.62*inch, topMargin=0.62*inch, bottomMargin=0.62*inch,
#                             title="Comprehensive AI Interview Report", author="Capstone Interview Analytics")
#     styles = getSampleStyleSheet()
#     styles.add(ParagraphStyle(name="ReportTitleCustom", parent=styles["Title"], fontSize=20, leading=25,
#                               textColor=colors.HexColor("#1A365D"), spaceAfter=8))
#     styles.add(ParagraphStyle(name="SectionCustom", parent=styles["Heading2"], fontSize=12, leading=16,
#                               textColor=colors.HexColor("#2B6CB0"), spaceBefore=12, spaceAfter=6))
#     styles.add(ParagraphStyle(name="SmallBodyCustom", parent=styles["BodyText"], fontSize=8.5, leading=12, spaceAfter=5))
#     styles.add(ParagraphStyle(name="QuestionCustom", parent=styles["BodyText"], fontSize=9, leading=13, spaceAfter=7))
#     story = [Paragraph("Comprehensive AI Interview Report", styles["ReportTitleCustom"]),
#              Paragraph(f"<b>Session ID:</b> {escape(str(session_id))}<br/><b>Generated:</b> {time.strftime('%Y-%m-%d %H:%M:%S')}", styles["Normal"]),
#              Spacer(1, 10)]

#     story.append(Paragraph("1. Executive Summary", styles["SectionCustom"]))
#     if isinstance(ai_report, (dict, list)):
#         ai_text = json.dumps(ai_report, ensure_ascii=False, indent=2, default=str)
#     else:
#         ai_text = str(ai_report or "No AI-generated assessment was returned.")
#     # Escape plain text, preserving readable paragraph breaks.
#     story.append(Paragraph(escape(ai_text).replace("\n", "<br/>"), styles["SmallBodyCustom"]))

#     story.append(Paragraph("2. Interview Conversation", styles["SectionCustom"]))
#     if conversation:
#         for idx, item in enumerate(conversation, 1):
#             role = str(item.get("role", "message")).capitalize()
#             message = escape(str(item.get("text", ""))).replace("\n", "<br/>")
#             story.append(Paragraph(f"<b>{idx}. {escape(role)}:</b> {message}", styles["QuestionCustom"]))
#     else:
#         story.append(Paragraph("No saved conversation transcript was found.", styles["SmallBodyCustom"]))

#     story.append(Paragraph("3. Video Telemetry Summary", styles["SectionCustom"]))
#     if analytics.get("available"):
#         metrics = [
#             ["Metric", "Observed result"],
#             ["Frames received", str(analytics.get("frames_received", 0))],
#             ["Face-detection coverage", f"{analytics.get('face_detection_coverage_percent', 0):.1f}%"],
#             ["Estimated eye-contact frames", "N/A" if analytics.get("eye_contact_percent") is None else f"{analytics['eye_contact_percent']:.1f}% of valid gaze frames"],
#             ["Looked-away frames", "N/A" if analytics.get("looked_away_percent") is None else f"{analytics['looked_away_percent']:.1f}% of valid gaze frames"],
#             ["Speaking mouth-shape frames", "N/A" if analytics.get("speaking_frame_percent") is None else f"{analytics['speaking_frame_percent']:.1f}% of face-detected frames"],
#             ["Registered blinks", str(analytics.get("blink_count", 0))],
#             ["Estimated blinks/minute", "N/A" if analytics.get("blinks_per_minute") is None else str(analytics["blinks_per_minute"])],
#             ["Observed duration", f"{analytics.get('session_duration_seconds', 0):.1f} seconds"]
#         ]
#         table = Table(metrics, colWidths=[2.15*inch, 4.3*inch], repeatRows=1)
#         table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
#                                    ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#1A365D")),
#                                    ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E0")),
#                                    ("VALIGN", (0,0), (-1,-1), "TOP"),
#                                    ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6),
#                                    ("TOPPADDING", (0,0), (-1,-1), 5), ("BOTTOMPADDING", (0,0), (-1,-1), 5)]))
#         story.append(table)
#         story.append(Spacer(1, 8))
#         story.append(Paragraph("Expression distribution (percentage of face-detected frames):", styles["SmallBodyCustom"]))
#         exp_rows = [["Expression label", "Share"]] + [[str(k), f"{v:.1f}%"] for k, v in analytics.get("expression_percentages", {}).items()]
#         exp_table = Table(exp_rows, colWidths=[4.5*inch, 1.95*inch], repeatRows=1)
#         exp_table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
#                                        ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E0")),
#                                        ("VALIGN", (0,0), (-1,-1), "TOP"), ("LEFTPADDING", (0,0), (-1,-1), 6),
#                                        ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4)]))
#         story.append(exp_table)
#     else:
#         story.append(Paragraph(escape(analytics.get("message", "No video telemetry available.")), styles["SmallBodyCustom"]))

#     story.append(Paragraph("4. Development Recommendations", styles["SectionCustom"]))
#     for rec in _behavioral_recommendations(analytics):
#         story.append(Paragraph("• " + escape(rec), styles["SmallBodyCustom"]))

#     story.append(Paragraph("5. Sampled Video Timeline", styles["SectionCustom"]))
#     timeline = analytics.get("timeline", [])
#     if timeline:
#         timeline_rows = [["Time (s)", "Face", "Gaze", "Mouth", "Expression", "Blinks"]]
#         for item in timeline:
#             timeline_rows.append([
#                 str(item.get("timestamp_seconds", "")),
#                 "Yes" if item.get("face_detected") else "No",
#                 str(item.get("gaze", "")),
#                 str(item.get("speech", "")),
#                 str(item.get("expression", "")),
#                 str(item.get("current_blink_total", 0))
#             ])
#         timeline_table = Table(timeline_rows, colWidths=[0.55*inch, 0.45*inch, 1.05*inch, 0.55*inch, 2.55*inch, 0.55*inch], repeatRows=1)
#         timeline_table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
#                                             ("GRID", (0,0), (-1,-1), 0.3, colors.HexColor("#CBD5E0")),
#                                             ("FONTSIZE", (0,0), (-1,-1), 6.5),
#                                             ("VALIGN", (0,0), (-1,-1), "TOP"),
#                                             ("LEFTPADDING", (0,0), (-1,-1), 3),
#                                             ("RIGHTPADDING", (0,0), (-1,-1), 3),
#                                             ("TOPPADDING", (0,0), (-1,-1), 3),
#                                             ("BOTTOMPADDING", (0,0), (-1,-1), 3)]))
#         story.append(timeline_table)
#     else:
#         story.append(Paragraph("No sampled video timeline was recorded.", styles["SmallBodyCustom"]))

#     story.append(Paragraph("6. Methodology and Limitations", styles["SectionCustom"]))
#     limitation = ("Video metrics are estimates from sampled webcam frames and configured MediaPipe landmark/blendshape thresholds. "
#                   "Because frame sampling may be sparse, blink counts can be undercounted. Mouth opening is only a visual proxy and "
#                   "does not verify that the candidate's voice is audible. Gaze and facial expressions do not reliably reveal honesty, "
#                   "confidence, stress, personality, or cognitive ability; they must not be used as standalone hiring criteria. "
#                   "Interpret these observations alongside the actual answers, role requirements, and interviewer judgement.")
#     story.append(Paragraph(escape(limitation), styles["SmallBodyCustom"]))
#     doc.build(story)
#     return REPORT_PDF_PATH


# # ============================================================
# # ROBOT STATES
# # ============================================================

# class RobotState:

#     IDLE = "IDLE"
#     LISTENING = "LISTENING"
#     THINKING = "THINKING"
#     SPEAKING = "SPEAKING"
#     GREETING = "GREETING"
#     ATTENTION = "ATTENTION"
#     GOODBYE = "GOODBYE"


# # ============================================================
# # ROBOT HEAD CONTROLLER
# # ============================================================

# class RobotHeadController:

#     def __init__(self):

#         self.serial_conn = None
#         self.connected = False

#         self.current_state = RobotState.IDLE

#         self.animation_thread = None
#         self.animation_running = False

#         self.lock = threading.Lock()

#         self.engine = None

#         # Servo configuration

#         # Servo configuration
#         self.MIN_ANGLE = 40
#         self.MAX_ANGLE = 140
#         self.CENTER_ANGLE = 90

#         # Smooth physical movement
#         self.STEP_DELAY = 0.02

#         # Animation control
#         self.animation_thread = None
#         self.animation_running = False
#         self.animation_id = 0

#         self.lock = threading.Lock()

#         # WiFi/HTTP configuration
#         self.use_wifi = USE_WIFI
#         self.esp32_url = f"http://{ESP32_IP}:{ESP32_PORT_HTTP}"


#     # --------------------------------------------------------
#     # CONNECT ESP32
#     # --------------------------------------------------------

#     def connect(self):

#         if self.use_wifi:
#             self.connect_wifi()
#         else:
#             self.connect_serial()

#     def connect_serial(self):

#         if serial is None:
#             print("[ROBOT] Serial mode requires pyserial. Install with: python -m pip install pyserial")
#             self.connected = False
#             return

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via Serial on {ESP32_PORT}...")

#             self.serial_conn = serial.Serial(
#                 ESP32_PORT,
#                 ESP32_BAUD,
#                 timeout=1
#             )

#             time.sleep(2)

#             self.connected = True

#             print("[ROBOT] ESP32 connected successfully via Serial.")

#             self.send_angle(self.CENTER_ANGLE)

#         except Exception as e:

#             print(f"[ROBOT] ESP32 Serial connection failed: {e}")

#             self.connected = False
#             self.serial_conn = None

#     def connect_wifi(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via WiFi at {self.esp32_url}...")

#             # Test connection by sending a status request
#             response = requests.get(
#                 f"{self.esp32_url}/status",
#                 timeout=5
#             )

#             if response.status_code == 200:
#                 self.connected = True
#                 print("[ROBOT] ESP32 connected successfully via WiFi.")
#                 print(f"[ROBOT] ESP32 Status: {response.json()}")
#                 self.send_angle(self.CENTER_ANGLE)
#             else:
#                 print(f"[ROBOT] ESP32 WiFi connection failed: HTTP {response.status_code}")
#                 self.connected = False

#         except Exception as e:

#             print(f"[ROBOT] ESP32 WiFi connection failed: {e}")
#             self.connected = False

#     # --------------------------------------------------------
#     # DISCONNECT
#     # --------------------------------------------------------

#     def disconnect(self):

#         self.stop_animation()

#         try:

#             if self.use_wifi:
#                 self.send_command("STOP")
#             elif self.serial_conn and self.serial_conn.is_open:
#                 self.send_command("STOP")
#                 self.serial_conn.close()

#         except Exception as e:

#             print(f"[ROBOT] Disconnect error: {e}")

#         self.connected = False

#         print("[ROBOT] ESP32 disconnected.")

#     # --------------------------------------------------------
#     # SEND COMMAND
#     # --------------------------------------------------------

#     def send_command(self, command):

#         if not self.connected:
#             return

#         try:

#             if self.use_wifi:
#                 self.send_command_wifi(command)
#             else:
#                 self.send_command_serial(command)

#         except Exception as e:

#             print(f"[ROBOT] Command send error: {e}")

#     def send_command_serial(self, command):

#         try:

#             with self.lock:

#                 self.serial_conn.write(
#                     (command + "\n").encode()
#                 )

#                 self.serial_conn.flush()

#         except Exception as e:

#             print(f"[ROBOT] Serial write error: {e}")

#     def send_command_wifi(self, command):

#         try:

#             with self.lock:

#                 response = requests.post(
#                     f"{self.esp32_url}/command",
#                     data=command,
#                     timeout=5
#                 )

#                 if response.status_code == 200:
#                     print(f"[ROBOT] WiFi command sent: {command}")
#                 else:
#                     print(f"[ROBOT] WiFi command failed: HTTP {response.status_code}")

#         except Exception as e:

#             print(f"[ROBOT] WiFi write error: {e}")

#     # # --------------------------------------------------------
#     # # SEND SERVO ANGLE
#     # # --------------------------------------------------------

#     # def send_angle(self, angle):

#     #     angle = max(
#     #         self.MIN_ANGLE,
#     #         min(self.MAX_ANGLE, int(angle))
#     #     )

#     #     self.send_command(f"ANGLE:{angle}")


#         # --------------------------------------------------------
#     # SEND SERVO ANGLE (HEAD)
#     # --------------------------------------------------------

#     def send_angle(self, angle):

#         angle = max(
#             self.MIN_ANGLE,
#             min(self.MAX_ANGLE, int(angle))
#         )

#         self.send_command(f"ANGLE:{angle}")

#     # --------------------------------------------------------
#     # SEND HAND ANGLES (NEW HELPER)
#     # --------------------------------------------------------

#     def send_hand_angles(self, left, right):
#         """
#         Sends independent, clamped target angles to the hand servos.
#         Because the ESP32 internally maps the right hand using (180 - angle),
#         sending identical angles from the backend results in physically 
#         coordinated, mirrored gestures.
#         """
#         left_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(left)))
#         right_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(right)))
        
#         self.send_command(f"LEFT:{left_clamped}")
#         self.send_command(f"RIGHT:{right_clamped}")

#     # --------------------------------------------------------
#     # STOP SERVO
#     # --------------------------------------------------------

#     def stop_servo(self):

#         self.send_command("STOP")

#     # --------------------------------------------------------
#     # ANIMATION
#     # --------------------------------------------------------

#     def start_animation(self, state):
#         self.stop_animation()

#         self.animation_running = True
#         generation = self.animation_id

#         self.animation_thread = threading.Thread(
#             target=self.animation_loop,
#             args=(state, generation),
#             daemon=True
#         )
#         self.animation_thread.start()

#     def stop_animation(self):
#         self.animation_running = False

#         # Invalidate every older animation thread.
#         self.animation_id += 1

#         old_thread = self.animation_thread

#         if (
#             old_thread
#             and old_thread.is_alive()
#             and old_thread != threading.current_thread()
#         ):
#             old_thread.join(timeout=0.7)

#         self.animation_thread = None

#     # --------------------------------------------------------
#     # ANIMATION LOOP (UPDATED TO INTEGRATE HAND GESTURES)
#     # --------------------------------------------------------

#     def animation_loop(self, state, generation):
#         """
#         State-driven robot head and hand animation.
#         Coordinated, non-blocking physical gestures.
#         """

#         def active():
#             return (
#                 self.animation_running
#                 and generation == self.animation_id
#             )

#         def move(head_ang, left_ang=90, right_ang=90, pause=0.0):
#             if not active():
#                 return False

#             # Dispatch head and hand instructions safely across Wi-Fi
#             self.send_angle(head_ang)
#             self.send_hand_angles(left_ang, right_ang)

#             if pause > 0:
#                 deadline = time.monotonic() + pause
#                 while active() and time.monotonic() < deadline:
#                     time.sleep(0.05)

#             return active()

#         try:
#             # ------------------------------------------
#             # IDLE / LISTENING / THINKING: Rest positions
#             # ------------------------------------------
#             if state == RobotState.IDLE:
#                 move(90, 90, 90)
#                 return

#             elif state == RobotState.LISTENING:
#                 # Attentive head tilt, hands relaxed at base rest (90)
#                 if not move(76, 90, 90, 0.8):
#                     return
#                 while active():
#                     time.sleep(0.05)

#             elif state == RobotState.THINKING:
#                 # Look aside, keep hands resting to express analytical calm
#                 if not move(108, 90, 90, 1.4):
#                     return
#                 while active():
#                     if not move(102, 90, 90, 1.8): break
#                     if not move(110, 90, 90, 1.2): break
#                     if not move(90, 90, 90, 2.5): break

#             # ------------------------------------------
#             # SPEAKING: Dynamic conversational expressions
#             # ------------------------------------------
#             elif state == RobotState.SPEAKING:
#                 if not move(90, 90, 90):
#                     return

#                 while active():
#                     # Subtle mirrored conversational expansion (opening up)
#                     if not move(98, 75, 75, 0.45): break
#                     if not move(90, 90, 90, 1.0): break
#                     # Alternating asymmetrical emphasis shifts
#                     if not move(82, 105, 80, 0.45): break
#                     if not move(90, 90, 90, 1.5): break

#             # ------------------------------------------
#             # GREETING: Welcome presentation gesture
#             # ------------------------------------------
#             elif state == RobotState.GREETING:
#                 # Graceful sweep opening both hands outward together
#                 if not move(72, 60, 60, 0.45): return
#                 if not move(108, 60, 60, 0.55): return
#                 # Gradually return to center balance positions
#                 if not move(78, 80, 80, 0.45): return
#                 move(90, 90, 90, 0.8)

#             # ------------------------------------------
#             # ATTENTION: Orient towards user
#             # ------------------------------------------
#             elif state == RobotState.ATTENTION:
#                 if not move(110, 90, 90, 0.8): return
#                 if not move(90, 90, 90, 1.0): return

#                 while active():
#                     if not move(96, 90, 90, 0.8): break
#                     if not move(90, 90, 90, 2.5): break

#             # ------------------------------------------
#             # GOODBYE: Closing polite gesture
#             # ------------------------------------------
#             elif state == RobotState.GOODBYE:
#                 # Brief parting hand gesture, then drop smoothly down to rest
#                 if not move(72, 70, 70, 0.45): return
#                 if not move(108, 70, 70, 0.55): return
#                 if not move(72, 90, 90, 0.45): return
#                 move(90, 90, 90, 1.0)

#         except Exception as e:
#             print(f"[ROBOT] Animation error: {e}")

#     # --------------------------------------------------------
#     # SET ROBOT STATE
#     # --------------------------------------------------------

#     def set_state(self, new_state):

#         thread_alive = (
#             self.animation_thread is not None
#             and self.animation_thread.is_alive()
#         )

#         if new_state == self.current_state and thread_alive:
#             return

#         print(
#             f"[ROBOT] STATE: "
#             f"{self.current_state} -> {new_state}"
#         )

#         self.current_state = new_state
#         self.start_animation(new_state)

#     # --------------------------------------------------------
#     # PYTTSX3 SPEAK
#     # --------------------------------------------------------

#     def speak(self, text):

#         """
#         Optional backend TTS.

#         CURRENT PROJECT FLOW:
#         Browser SpeechSynthesis handles the actual voice.

#         Therefore this function is NOT called by the ADK
#         callback.
#         """

#         if not text:
#             return

#         if self.engine is None:

#             try:

#                 self.engine = pyttsx3.init()

#             except Exception as e:

#                 print(
#                     f"[ROBOT] pyttsx3 initialization failed: {e}"
#                 )

#                 return

#         self.set_state(RobotState.SPEAKING)

#         try:

#             self.engine.say(text)
#             self.engine.runAndWait()

#         except Exception as e:

#             print(f"[ROBOT] TTS error: {e}")

#         finally:

#             self.set_state(RobotState.LISTENING)


# # ============================================================
# # CREATE ROBOT
# # ============================================================

# robot = RobotHeadController()


# # ============================================================
# # RESUME TEXT EXTRACTION
# # ============================================================

# def getText() -> str:

#     resume_path = RESUME_PATH

#     if not os.path.exists(resume_path):

#         print(
#             f"[RESUME] Uploaded resume not found: "
#             f"{resume_path}"
#         )

#         resume_path = "sample_resume.pdf"

#     if not os.path.exists(resume_path):

#         print("[RESUME] No resume PDF found.")

#         return ""

#     text = ""

#     try:

#         with pdfplumber.open(resume_path) as pdf:

#             for page in pdf.pages:

#                 page_text = page.extract_text()

#                 if page_text:

#                     text += page_text + "\n"

#         print(
#             f"[RESUME] Extracted "
#             f"{len(text)} characters."
#         )

#         return text

#     except Exception as e:

#         print(
#             f"[RESUME] Error extracting resume: {e}"
#         )

#         return ""


# # ============================================================
# # ADK CALLBACK
# # ============================================================

# def Speak(callback_context):

#     """
#     ADK callback.

#     IMPORTANT:
#     The browser is responsible for actual voice output.

#     Therefore this callback DOES NOT call pyttsx3.
#     """

#     print(
#         "[AGENT] Speak callback triggered - "
#         "browser will handle TTS"
#     )

#     return None


# # ============================================================
# # GEMINI CONFIGURATION
# # ============================================================

# retry_config = types.HttpRetryOptions(

#     attempts=5,

#     exp_base=7,

#     initial_delay=1,

#     http_status_codes=[
#         429,
#         500,
#         503,
#         504
#     ]
# )


# # ============================================================
# # CAMERA AGENT
# # ============================================================

# CameraAgent = LlmAgent(
#     name="CamAgent"
# )


# # ============================================================
# # INTERVIEW AGENT
# # ============================================================

# interviewAgent = LlmAgent(

#     name="InterviewAgent",

#     model=Gemini(
#         model="gemini-3.5-flash-lite",
#         retry_options=retry_config
#     ),

#     description=(
#         "You are an AI professional interviewer "
#         "who interviews candidates based on their resumes."
#     ),

#     instruction="""

# You are a professional interviewer conducting a
# technical recruitment interview.

# IMPORTANT RULES:

# 1. Use the getText() tool to extract the candidate's
#    resume text.

# 2. Study the candidate's resume carefully.

# 3. Ask ONLY ONE question at a time.

# 4. After asking a question, WAIT for the candidate's
#    answer before asking the next question.

# 5. Ask at least 2 questions about the candidate
#    personally, such as:
#    - Introduction
#    - Background
#    - Career goals
#    - Interests

# 6. Ask at least 4 technical questions based specifically
#    on the skills, technologies and projects present in
#    the candidate's resume.

# 7. Do NOT invent technologies or projects that are not
#    present in the resume.

# 8. Questions should progressively evaluate:
#    - Understanding
#    - Practical knowledge
#    - Problem solving
#    - Technical depth

# 9. Keep each interviewer response concise and natural
#    because it will be converted into speech.

# 10. Do not ask multiple questions in one response.

# 11. Do not repeat a question that has already been asked.

# 12. Maintain awareness of the previous conversation.

# 13. After all required questions have been completed,
#     provide an overall summary of the candidate's
#     performance.

# 14. The final summary should include:
#     - Strengths
#     - Technical knowledge
#     - Communication
#     - Problem solving
#     - Areas for improvement
#     - Overall assessment

# 15. Always use the candidate's resume information when
#     discussing their background, skills and projects.

# 16. Never generate a second answer to the same candidate
#     response.

# """,

#     after_agent_callback=Speak,

#     tools=[getText]
# )


# # ============================================================
# # ADK SESSION SERVICE
# # ============================================================

# session_service = InMemorySessionService()


# # ============================================================
# # RUNNER
# # ============================================================

# runner = Runner(

#     agent=interviewAgent,

#     app_name=APP_NAME,

#     session_service=session_service
# )


# # ============================================================
# # RUN ADK SESSION
# # ============================================================

# async def run_session(
#     runner: Runner,
#     query: str,
#     session_id: str
# ):

#     print()
#     print("=" * 60)
#     print("[ADK] NEW MODEL REQUEST")
#     print(f"[ADK] Session ID : {session_id}")
#     print(f"[ADK] User       : {USER_ID}")
#     print(f"[ADK] Query      : {query}")
#     print("=" * 60)

#     if not query or not query.strip():

#         print(
#             "[ADK] Empty user query. "
#             "Skipping model request."
#         )

#         return None

#     query_content = types.Content(

#         role="user",

#         parts=[
#             types.Part(
#                 text=query.strip()
#             )
#         ]

#     )

#     model_text = None

#     try:

#         async for event in runner.run_async(

#             user_id=USER_ID,

#             session_id=session_id,

#             new_message=query_content

#         ):

#             # Only use the final response.

#             if not event.is_final_response():
#                 continue

#             if not event.content:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     model_text = part.text.strip()

#                     print()
#                     print("[ADK] FINAL MODEL RESPONSE:")
#                     print(model_text)
#                     print()

#                     break

#             if model_text:
#                 break

#     except Exception as e:

#         print(
#             f"[ADK] Model execution error: {e}"
#         )

#         raise

#     if not model_text:

#         print(
#             "[ADK] WARNING: "
#             "No final model response received."
#         )

#     return model_text


# # ============================================================
# # SAVE CONVERSATION
# # ============================================================

# def save_conversation(session):

#     conversation_data = []

#     try:

#         if not session:
#             return conversation_data

#         for event in session.events:

#             if not event.content:
#                 continue

#             role = event.content.role

#             if role not in ["user", "model"]:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     conversation_data.append({

#                         "role": role,

#                         "text": part.text.strip()

#                     })

#         os.makedirs(
#             os.path.dirname(CONVERSATION_PATH),
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 conversation_data,
#                 f,
#                 indent=4,
#                 ensure_ascii=False
#             )

#         print(
#             f"[CONVERSATION] Saved "
#             f"{len(conversation_data)} messages."
#         )

#     except Exception as e:

#         print(
#             f"[CONVERSATION] Save error: {e}"
#         )

#     return conversation_data


# # ============================================================
# # FASTAPI LIFESPAN
# # ============================================================

# @asynccontextmanager
# async def lifespan(app: FastAPI):

#     print()
#     print("=" * 60)
#     print("VOICE BASED AI INTERVIEWER BACKEND")
#     print("=" * 60)

#     robot.connect()

#     if robot.connected:

#         robot.current_state = RobotState.IDLE

#         robot.start_animation(
#             RobotState.IDLE
#         )

#     yield

#     print(
#         "[SERVER] Shutting down..."
#     )

#     robot.disconnect()


# # ============================================================
# # FASTAPI APP
# # ============================================================

# app = FastAPI(
#     lifespan=lifespan
# )


# # ============================================================
# # CORS
# # ============================================================

# app.add_middleware(

#     CORSMiddleware,

#     allow_origins=["*"],

#     allow_credentials=True,

#     allow_methods=["*"],

#     allow_headers=["*"]

# )


# # ============================================================
# # UPLOAD RESUME
# # ============================================================

# @app.post("/upload-resume")
# async def upload_resume(
#     file: UploadFile = File(...)
# ):

#     try:

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         data = await file.read()

#         with open(
#             RESUME_PATH,
#             "wb"
#         ) as f:

#             f.write(data)

#         print(
#             f"[RESUME] Uploaded: "
#             f"{len(data)} bytes"
#         )

#         return {

#             "status": "success",

#             "message": "Resume uploaded successfully."

#         }

#     except Exception as e:

#         print(
#             f"[RESUME] Upload error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # START NEW INTERVIEW
# # ============================================================

# @app.post("/start-interview")
# async def start_interview():

#     global CURRENT_SESSION_ID
#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE

#     try:

#         # ----------------------------------------------------
#         # CREATE UNIQUE SESSION
#         # ----------------------------------------------------

#         CURRENT_SESSION_ID = (
#             f"interview_{uuid.uuid4().hex}"
#         )

#         print()
#         print("=" * 60)
#         print("[INTERVIEW] NEW INTERVIEW STARTED")
#         print(
#             f"[INTERVIEW] Session: "
#             f"{CURRENT_SESSION_ID}"
#         )
#         print("=" * 60)

#         # ----------------------------------------------------
#         # RESET DUPLICATE PROTECTION
#         # ----------------------------------------------------

#         LAST_AUDIO_HASH = None
#         LAST_MODEL_RESPONSE = None

#         # Reset video telemetry for this interview only.
#         global VIDEO_TIMELINE, INTERVIEW_STARTED_AT, BLINK_COUNT, BLINK_STATE
#         with telemetry_lock:
#             VIDEO_TIMELINE = []
#             INTERVIEW_STARTED_AT = time.time()
#             BLINK_COUNT = 0
#             BLINK_STATE = False
#         os.makedirs(BASE_DIR, exist_ok=True)
#         _write_json_atomic(INTERVIEW_LOG_PATH, [])

#         # ----------------------------------------------------
#         # CREATE ADK SESSION
#         # ----------------------------------------------------

#         await session_service.create_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         # ----------------------------------------------------
#         # CLEAR OLD INTERVIEW DATA
#         # ----------------------------------------------------

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 [],
#                 f
#             )

#         with open(
#             EXPRESSIONS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         with open(
#             EVENTS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         if os.path.exists(
#             COMPRESSED_EVENTS_PATH
#         ):

#             with open(
#                 COMPRESSED_EVENTS_PATH,
#                 "w",
#                 encoding="utf-8"
#             ) as f:

#                 json.dump(
#                     [],
#                     f
#                 )

#         # ----------------------------------------------------
#         # ROBOT GREETING
#         # ----------------------------------------------------
#         # Frontend face sequence: GREETING -> SPEAKING while browser
#         # TTS speaks -> LISTENING after the greeting finishes.
#         robot.set_state(RobotState.GREETING)

#         return {

#             "status": "success",

#             "message":
#                 "New interview session started.",

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             f"[INTERVIEW] Start error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # TRANSCRIBE + AI RESPONSE
# # ============================================================

# @app.post("/transcribe")
# async def transcribe(
#     audio: UploadFile = File(...)
# ):

#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE
#     global CURRENT_SESSION_ID

#     # ========================================================
#     # IMPORTANT:
#     # Only one transcription request can run at a time.
#     # ========================================================

#     async with transcribe_lock:

#         request_id = uuid.uuid4().hex[:8]

#         print()
#         print("=" * 70)
#         print(
#             f"[TRANSCRIBE] NEW REQUEST "
#             f"ID={request_id}"
#         )
#         print("=" * 70)

#         try:

#             # ------------------------------------------------
#             # CHECK SESSION
#             # ------------------------------------------------

#             if not CURRENT_SESSION_ID:

#                 print(
#                     "[TRANSCRIBE] ERROR: "
#                     "No active interview session."
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "Please start a new interview first."

#                 }

#             # Keep this request tied to its original session if a new
#             # interview is started while audio/model processing is active.
#             session_id = CURRENT_SESSION_ID

#             # ------------------------------------------------
#             # ROBOT THINKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.THINKING
#             )

#             # ------------------------------------------------
#             # READ AUDIO
#             # ------------------------------------------------

#             audio_data = await audio.read()

#             if not audio_data:

#                 print(
#                     "[TRANSCRIBE] Empty audio."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not hear your answer. "
#                         "Please try again."

#                 }

#             print(
#                 f"[TRANSCRIBE] Audio size: "
#                 f"{len(audio_data)} bytes"
#             )

#             # ------------------------------------------------
#             # CREATE AUDIO HASH
#             # ------------------------------------------------

#             audio_hash = hashlib.sha256(
#                 audio_data
#             ).hexdigest()

#             print(
#                 f"[TRANSCRIBE] Audio hash: "
#                 f"{audio_hash[:16]}..."
#             )

#             # ------------------------------------------------
#             # DUPLICATE AUDIO CHECK
#             # ------------------------------------------------

#             if (
#                 LAST_AUDIO_HASH is not None
#                 and audio_hash == LAST_AUDIO_HASH
#             ):

#                 print()
#                 print(
#                     "[TRANSCRIBE] DUPLICATE AUDIO "
#                     "DETECTED."
#                 )

#                 print(
#                     "[TRANSCRIBE] "
#                     "Gemini will NOT be called again."
#                 )

#                 robot.set_state(
#                     RobotState.SPEAKING
#                 )

#                 return {

#                     "transcript":
#                         "(duplicate request)",

#                     "model":
#                         LAST_MODEL_RESPONSE
#                         or
#                         "Please continue."

#                 }

#             # ------------------------------------------------
#             # SAVE AUDIO
#             # ------------------------------------------------

#             os.makedirs(
#                 BASE_DIR,
#                 exist_ok=True
#             )

#             with open(
#                 AUDIO_PATH,
#                 "wb"
#             ) as f:

#                 f.write(audio_data)

#             print(
#                 f"[TRANSCRIBE] Saved audio: "
#                 f"{AUDIO_PATH}"
#             )

#             # ------------------------------------------------
#             # LOAD WHISPER
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Loading model..."
#             )

#             model = whisper.load_model(
#                 "base"
#             )

#             print(
#                 "[WHISPER] Model loaded."
#             )

#             # ------------------------------------------------
#             # TRANSCRIBE
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Transcribing..."
#             )

#             result = model.transcribe(
#                 AUDIO_PATH
#             )

#             text = (
#                 result
#                 .get("text", "")
#                 .strip()
#             )

#             print()
#             print(
#                 "[WHISPER] TRANSCRIPT:"
#             )
#             print(text)
#             print()

#             # ------------------------------------------------
#             # EMPTY TRANSCRIPT
#             # ------------------------------------------------

#             if not text:

#                 print(
#                     "[WHISPER] Empty transcript."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not understand your "
#                         "answer. Please try again."

#                 }

#             # ------------------------------------------------
#             # VERIFY SESSION
#             # ------------------------------------------------

#             print(
#                 "[ADK] Using session:",
#                 session_id
#             )

#             # ------------------------------------------------
#             # SEND TO GEMINI
#             # ------------------------------------------------

#             model_response = await run_session(

#                 runner,

#                 text,

#                 session_id

#             )

#             # ------------------------------------------------
#             # HANDLE EMPTY MODEL RESPONSE
#             # ------------------------------------------------

#             if not model_response:

#                 print(
#                     "[ADK] No model response."
#                 )

#                 model_response = (
#                     "Thank you for your answer. "
#                     "Let's continue."
#                 )

#             # ------------------------------------------------
#             # SAVE LAST MODEL RESPONSE
#             # ------------------------------------------------

#             LAST_MODEL_RESPONSE = model_response

#             # Store duplicate protection only after a successful model
#             # response; failed model calls can then be retried.
#             LAST_AUDIO_HASH = audio_hash

#             # ------------------------------------------------
#             # READ SESSION ONLY FOR LOGGING
#             #
#             # IMPORTANT:
#             # This does NOT call Gemini again.
#             # ------------------------------------------------

#             session = await session_service.get_session(

#                 app_name=APP_NAME,

#                 user_id=USER_ID,

#                 session_id=session_id

#             )

#             # ------------------------------------------------
#             # SAVE CONVERSATION
#             # ------------------------------------------------

#             save_conversation(
#                 session
#             )

#             # ------------------------------------------------
#             # ROBOT SPEAKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.SPEAKING
#             )

#             print()
#             print("=" * 70)
#             print(
#                 f"[TRANSCRIBE] REQUEST "
#                 f"{request_id} COMPLETE"
#             )
#             print(
#                 "[TRANSCRIBE] Candidate:",
#                 text
#             )
#             print(
#                 "[TRANSCRIBE] AI:",
#                 model_response
#             )
#             print("=" * 70)
#             print()

#             # ------------------------------------------------
#             # RETURN TO FRONTEND
#             # ------------------------------------------------

#             return {

#                 "transcript": text,

#                 "model": model_response

#             }

#         except Exception as e:

#             print()
#             print(
#                 "[TRANSCRIBE] ERROR:",
#                 str(e)
#             )

#             import traceback

#             traceback.print_exc()

#             robot.set_state(
#                 RobotState.LISTENING
#             )

#             return {

#                 "transcript": "",

#                 "model":
#                     "Sorry, I encountered an error. "
#                     "Please try again."

#             }


# # ============================================================
# # GENERATE FINAL REPORT
# # ============================================================

# @app.post("/generate-report")
# async def generate_report():
#     global CURRENT_SESSION_ID

#     print("\n" + "=" * 60)
#     print("[REPORT] GENERATING COMPREHENSIVE INTERVIEW REPORT")
#     print("=" * 60)

#     try:
#         if not CURRENT_SESSION_ID:
#             return {"status": "error", "message": "No active interview session."}

#         session = await session_service.get_session(
#             app_name=APP_NAME, user_id=USER_ID, session_id=CURRENT_SESSION_ID
#         )
#         if not session:
#             return {"status": "error", "message": "Interview session not found."}

#         # Preserve the existing AI interview assessment, then combine it with
#         # the complete saved conversation and the newly processed telemetry.
#         ai_report = generate_interview_report(
#             session_service=session_service,
#             app_name=APP_NAME,
#             user_id=USER_ID,
#             session_id=CURRENT_SESSION_ID,
#             llm_agent=interviewAgent
#         )

#         analytics = _summarize_video_telemetry()
#         try:
#             with open(CONVERSATION_PATH, "r", encoding="utf-8") as f:
#                 conversation = json.load(f)
#             if not isinstance(conversation, list):
#                 conversation = []
#         except (OSError, json.JSONDecodeError):
#             conversation = []

#         report_pdf = _generate_comprehensive_pdf(
#             ai_report=ai_report,
#             analytics=analytics,
#             conversation=conversation,
#             session_id=CURRENT_SESSION_ID
#         )

#         report_data = {
#             "session_id": CURRENT_SESSION_ID,
#             "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
#             "ai_assessment": ai_report,
#             "conversation": conversation,
#             "video_analytics": {k: v for k, v in analytics.items() if k != "timeline"},
#             "behavioral_recommendations": _behavioral_recommendations(analytics),
#             "pdf_report_url": "/download-report"
#         }
#         _write_json_atomic(os.path.join(BASE_DIR, "comprehensive_interview_report.json"), report_data)

#         print(f"[REPORT] Comprehensive PDF created: {report_pdf}")
#         robot.set_state(RobotState.GOODBYE)

#         return {
#             "status": "success",
#             # Keep the existing `report` field for frontend compatibility.
#             "report": ai_report,
#             "comprehensive_report": report_data,
#             "video_analytics": report_data["video_analytics"],
#             "pdf_report_url": "/download-report",
#             "session_id": CURRENT_SESSION_ID
#         }

#     except Exception as e:
#         print("[REPORT] Error:", str(e))
#         import traceback
#         traceback.print_exc()
#         return {"status": "error", "message": str(e)}


# @app.get("/download-report")
# async def download_report():
#     if not os.path.isfile(REPORT_PDF_PATH):
#         return {"status": "error", "message": "Report PDF has not been generated yet."}
#     return FileResponse(
#         REPORT_PDF_PATH,
#         media_type="application/pdf",
#         filename="comprehensive_interview_report.pdf"
#     )


# # ============================================================
# # ROBOT STATE API
# # ============================================================

# @app.get("/robot-state")
# async def robot_state():

#     return {

#         "state":
#             robot.current_state,

#         "connected":
#             robot.connected

#     }


# # ============================================================
# # SET ROBOT STATE
# # ============================================================

# @app.post("/robot/state")
# async def set_robot_state(data: dict):

#     state = data.get("state")

#     valid_states = {

#         RobotState.IDLE,

#         RobotState.LISTENING,

#         RobotState.THINKING,

#         RobotState.SPEAKING,

#         RobotState.GREETING,

#         RobotState.ATTENTION,

#         RobotState.GOODBYE

#     }

#     if state not in valid_states:

#         return {

#             "status": "error",

#             "message":
#                 f"Invalid robot state: {state}"

#         }

#     robot.set_state(state)

#     return {

#         "status": "success" if robot.connected else "warning",

#         "state": robot.current_state,

#         "connected": robot.connected,

#         "message": (
#             "State updated."
#             if robot.connected
#             else "Backend state updated, but ESP32 is not connected."
#         )

#     }


# # ============================================================
# # TEST ROBOT
# # ============================================================

# @app.get("/robot/test")
# async def robot_test():

#     robot.set_state(
#         RobotState.GREETING
#     )

#     return {

#         "status": "success",

#         "message":
#             "Robot test animation started."

#     }


# # ============================================================
# # MANUAL SERVO ANGLE
# # ============================================================

# @app.post("/robot/angle")
# async def robot_angle(data: dict):

#     try:

#         angle = int(
#             data.get(
#                 "angle",
#                 robot.CENTER_ANGLE
#             )
#         )

#         accepted_angle = max(robot.MIN_ANGLE, min(robot.MAX_ANGLE, angle))
#         robot.send_angle(accepted_angle)

#         return {

#             "status": "success" if robot.connected else "warning",

#             "angle": accepted_angle,

#             "connected": robot.connected,

#             "message": (
#                 "Angle command sent."
#                 if robot.connected
#                 else "Angle was validated, but ESP32 is not connected."
#             )

#         }

#     except Exception as e:

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # STOP ROBOT
# # ============================================================

# @app.post("/robot/stop")
# async def robot_stop():

#     robot.stop_animation()
#     robot.stop_servo()

#     # Report IDLE after stopping. set_state() can restart IDLE later
#     # because it checks whether an animation thread is actually alive.
#     robot.current_state = RobotState.IDLE

#     return {

#         "status": "success",

#         "message":
#             "Robot stopped."

#     }


# # ============================================================
# # VIDEO FRAME
# # ============================================================

# @app.post("/video-frame")
# async def video_frame(file: UploadFile = File(...)):
#     global INTERVIEW_STARTED_AT
#     try:
#         data = await file.read()
#         if not data:
#             return {"status": "error", "message": "Empty video frame."}

#         np_arr = np.frombuffer(data, np.uint8)
#         frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
#         if frame is None:
#             return {"status": "error", "message": "Could not decode image."}

#         if INTERVIEW_STARTED_AT is None:
#             # Allow testing the endpoint directly, while the normal app path
#             # resets the clock in /start-interview.
#             with telemetry_lock:
#                 if INTERVIEW_STARTED_AT is None:
#                     INTERVIEW_STARTED_AT = time.time()

#         record = _process_interview_frame(frame)
#         return {
#             "status": "success",
#             "face_detected": record["face_detected"],
#             "gaze": record["gaze"],
#             "speech": record["speech"],
#             "expression": record["expression"],
#             "blink_count": record["current_blink_total"],
#             "timestamp_seconds": record["timestamp_seconds"]
#         }
#     except Exception as e:
#         print("[VIDEO] Frame processing error:", e)
#         return {"status": "error", "message": str(e)}


# # ============================================================
# # ROOT
# # ============================================================

# @app.get("/")
# async def root():

#     return {

#         "status": "online",

#         "application":
#             "Voice Based AI Interviewer",

#         "session":
#             CURRENT_SESSION_ID,

#         "robot_state":
#             robot.current_state,

#         "robot_connected":
#             robot.connected

#     }


# # ============================================================
# # RUN:
# #
# # uvicorn FinalBackend:app --reload
# #
# # ============================================================

















# # ============================================================
# # FINAL BACKEND - VOICE BASED AI INTERVIEWER
# # ============================================================

# from fastapi import FastAPI, UploadFile, File
# from fastapi.responses import FileResponse, StreamingResponse
# from fastapi.middleware.cors import CORSMiddleware

# from contextlib import asynccontextmanager

# import pdfplumber
# import os
# import asyncio
# import uuid
# import json
# import time
# import hashlib
# import threading

# import cv2
# import numpy as np
# import mediapipe as mp

# from google.adk.agents import LlmAgent
# from google.adk.models.google_llm import Gemini
# from google.adk.sessions import InMemorySessionService
# from google.adk.runners import Runner
# from google.genai import types

# from mediapipe.tasks import python
# from mediapipe.tasks.python import vision

# from interview_event_detector1 import analyze_expressions
# from interview_report_generator import generate_interview_report

# import whisper
# import requests  # For WiFi communication with ESP32

# import pyttsx3


# GOOGLE_API_KEY = "AQ.Ab8RN6KsFdoZj_CiRKExRyTTFkNkyTCmjbpMifG_1gq2rPmGRw"
# os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# # ============================================================
# # CONFIGURATION
# # ============================================================

# # ESP32 Serial Configuration (Legacy - for serial communication)
# ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
# ESP32_BAUD = 115200

# # ESP32 WiFi Configuration (New - for wireless communication)
# ESP32_IP = os.getenv("ESP32_IP", "192.168.1.100")  # ESP32's IP address
# ESP32_PORT_HTTP = 80  # HTTP server port on ESP32
# USE_WIFI = os.getenv("USE_WIFI", "true").lower() == "true"  # Set to "true" to use WiFi

# APP_NAME = "InterviewApp"
# USER_ID = "demo_candidate"

# CURRENT_SESSION_ID = None

# # Prevent two /transcribe requests from being processed together.
# transcribe_lock = asyncio.Lock()

# # Duplicate request protection.
# LAST_AUDIO_HASH = None
# LAST_MODEL_RESPONSE = None

# # ============================================================
# # FILE PATHS
# # ============================================================

# BASE_DIR = os.getenv("INTERVIEW_DATA_DIR", os.path.dirname(os.path.abspath(__file__)))

# RESUME_PATH = os.path.join(BASE_DIR, "uploaded_resume.pdf")
# AUDIO_PATH = os.path.join(BASE_DIR, "recording.webm")
# CONVERSATION_PATH = os.path.join(BASE_DIR, "conversation.json")
# EXPRESSIONS_PATH = os.path.join(BASE_DIR, "expressions.log")
# EVENTS_PATH = os.path.join(BASE_DIR, "events.json")
# COMPRESSED_EVENTS_PATH = os.path.join(BASE_DIR, "compressed_events.json")


# # ============================================================
# # ROBOT STATES
# # ============================================================

# class RobotState:

#     IDLE = "IDLE"
#     LISTENING = "LISTENING"
#     THINKING = "THINKING"
#     SPEAKING = "SPEAKING"
#     GREETING = "GREETING"
#     ATTENTION = "ATTENTION"
#     GOODBYE = "GOODBYE"


# # ============================================================
# # ROBOT HEAD CONTROLLER
# # ============================================================

# class RobotHeadController:

#     def __init__(self):

#         self.serial_conn = None
#         self.connected = False

#         self.current_state = RobotState.IDLE

#         self.animation_thread = None
#         self.animation_running = False

#         self.lock = threading.Lock()

#         self.engine = None

#         # Servo configuration

#         # Servo configuration
#         self.MIN_ANGLE = 40
#         self.MAX_ANGLE = 140
#         self.CENTER_ANGLE = 90

#         # Smooth physical movement
#         self.STEP_DELAY = 0.02

#         # Animation control
#         self.animation_thread = None
#         self.animation_running = False
#         self.animation_id = 0

#         self.lock = threading.Lock()

#         # WiFi/HTTP configuration
#         self.use_wifi = USE_WIFI
#         self.esp32_url = f"http://{ESP32_IP}:{ESP32_PORT_HTTP}"


#     # --------------------------------------------------------
#     # CONNECT ESP32
#     # --------------------------------------------------------

#     def connect(self):

#         if self.use_wifi:
#             self.connect_wifi()
#         else:
#             self.connect_serial()

#     def connect_serial(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via Serial on {ESP32_PORT}...")

#             self.serial_conn = serial.Serial(
#                 ESP32_PORT,
#                 ESP32_BAUD,
#                 timeout=1
#             )

#             time.sleep(2)

#             self.connected = True

#             print("[ROBOT] ESP32 connected successfully via Serial.")

#             self.send_angle(self.CENTER_ANGLE)

#         except Exception as e:

#             print(f"[ROBOT] ESP32 Serial connection failed: {e}")

#             self.connected = False
#             self.serial_conn = None

#     def connect_wifi(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via WiFi at {self.esp32_url}...")

#             # Test connection by sending a status request
#             response = requests.get(
#                 f"{self.esp32_url}/status",
#                 timeout=5
#             )

#             if response.status_code == 200:
#                 self.connected = True
#                 print("[ROBOT] ESP32 connected successfully via WiFi.")
#                 print(f"[ROBOT] ESP32 Status: {response.json()}")
#                 self.send_angle(self.CENTER_ANGLE)
#             else:
#                 print(f"[ROBOT] ESP32 WiFi connection failed: HTTP {response.status_code}")
#                 self.connected = False

#         except Exception as e:

#             print(f"[ROBOT] ESP32 WiFi connection failed: {e}")
#             self.connected = False

#     # --------------------------------------------------------
#     # DISCONNECT
#     # --------------------------------------------------------

#     def disconnect(self):

#         self.stop_animation()

#         try:

#             if self.use_wifi:
#                 self.send_command("STOP")
#             elif self.serial_conn and self.serial_conn.is_open:
#                 self.send_command("STOP")
#                 self.serial_conn.close()

#         except Exception as e:

#             print(f"[ROBOT] Disconnect error: {e}")

#         self.connected = False

#         print("[ROBOT] ESP32 disconnected.")

#     # --------------------------------------------------------
#     # SEND COMMAND
#     # --------------------------------------------------------

#     def send_command(self, command):

#         if not self.connected:
#             return

#         try:

#             if self.use_wifi:
#                 self.send_command_wifi(command)
#             else:
#                 self.send_command_serial(command)

#         except Exception as e:

#             print(f"[ROBOT] Command send error: {e}")

#     def send_command_serial(self, command):

#         try:

#             with self.lock:

#                 self.serial_conn.write(
#                     (command + "\n").encode()
#                 )

#                 self.serial_conn.flush()

#         except Exception as e:

#             print(f"[ROBOT] Serial write error: {e}")

#     def send_command_wifi(self, command):

#         try:

#             with self.lock:

#                 response = requests.post(
#                     f"{self.esp32_url}/command",
#                     data=command,
#                     timeout=5
#                 )

#                 if response.status_code == 200:
#                     print(f"[ROBOT] WiFi command sent: {command}")
#                 else:
#                     print(f"[ROBOT] WiFi command failed: HTTP {response.status_code}")

#         except Exception as e:

#             print(f"[ROBOT] WiFi write error: {e}")

#     # --------------------------------------------------------
#     # SEND SERVO ANGLE
#     # --------------------------------------------------------

#     def send_angle(self, angle):

#         angle = max(
#             self.MIN_ANGLE,
#             min(self.MAX_ANGLE, int(angle))
#         )

#         self.send_command(f"ANGLE:{angle}")

#     # --------------------------------------------------------
#     # STOP SERVO
#     # --------------------------------------------------------

#     def stop_servo(self):

#         self.send_command("STOP")

#     # --------------------------------------------------------
#     # ANIMATION
#     # --------------------------------------------------------

    
#     def start_animation(self, state):
#         self.stop_animation()

#         self.animation_running = True
#         generation = self.animation_id

#         self.animation_thread = threading.Thread(
#             target=self.animation_loop,
#             args=(state, generation),
#             daemon=True
#         )
#         self.animation_thread.start()

#     def stop_animation(self):
#         self.animation_running = False

#         # Invalidate every older animation thread.
#         self.animation_id += 1

#         old_thread = self.animation_thread

#         if (
#             old_thread
#             and old_thread.is_alive()
#             and old_thread != threading.current_thread()
#         ):
#             old_thread.join(timeout=0.7)

#         self.animation_thread = None


#     # --------------------------------------------------------
#     # ANIMATION LOOP
#     # --------------------------------------------------------

    
#     def animation_loop(self, state, generation):
#         """
#         State-driven robot head animation.

#         The backend owns the animation.
#         ESP32 receives ANGLE commands only.
#         """

#         def active():
#             return (
#                 self.animation_running
#                 and generation == self.animation_id
#             )

#         def move(angle, pause=0.0):
#             if not active():
#                 return False

#             self.send_angle(angle)

#             if pause > 0:
#                 deadline = time.monotonic() + pause

#                 while active() and time.monotonic() < deadline:
#                     time.sleep(0.05)

#             return active()

#         try:
#             # ------------------------------------------
#             # IDLE: calm, centered, occasional movement
#             # ------------------------------------------
#             if state == RobotState.IDLE:
#                 move(90)
#                 # Do not continuously move while idle.
#                 return

#             # ------------------------------------------
#             # LISTENING: attentive, deliberate head tilt
#             # ------------------------------------------
            
#             elif state == RobotState.LISTENING:
#                 # Tilt once and hold the listening pose.
#                 if not move(76, 0.8):
#                     return

#                 # Stay tilted until another state is requested.
#                 while active():
#                     time.sleep(0.05)


#             # ------------------------------------------
#             # THINKING: look aside, pause, return
#             # ------------------------------------------
#             elif state == RobotState.THINKING:
#                 if not move(108, 1.4):
#                     return

#                 while active():
#                     if not move(102, 1.8):
#                         break
#                     if not move(110, 1.2):
#                         break
#                     if not move(90, 2.5):
#                         break

#             # ------------------------------------------
#             # SPEAKING: restrained conversational gestures
#             # ------------------------------------------
#             elif state == RobotState.SPEAKING:
#                 if not move(90):
#                     return

#                 while active():
#                     if not move(98, 0.45):
#                         break
#                     if not move(90, 1.0):
#                         break
#                     if not move(82, 0.45):
#                         break
#                     if not move(90, 1.5):
#                         break

#             # ------------------------------------------
#             # GREETING: one clear welcoming gesture
#             # ------------------------------------------
#             elif state == RobotState.GREETING:
#                 if not move(72, 0.45):
#                     return
#                 if not move(108, 0.55):
#                     return
#                 if not move(78, 0.45):
#                     return
#                 move(90, 0.8)

#             # ------------------------------------------
#             # ATTENTION: turn toward the candidate
#             # ------------------------------------------
#             elif state == RobotState.ATTENTION:
#                 if not move(110, 0.8):
#                     return
#                 if not move(90, 1.0):
#                     return

#                 while active():
#                     if not move(96, 0.8):
#                         break
#                     if not move(90, 2.5):
#                         break

#             # ------------------------------------------
#             # GOODBYE: deliberate farewell movement
#             # ------------------------------------------
#             elif state == RobotState.GOODBYE:
#                 if not move(72, 0.45):
#                     return
#                 if not move(108, 0.55):
#                     return
#                 if not move(72, 0.45):
#                     return
#                 move(90, 1.0)

#         except Exception as e:
#             print(f"[ROBOT] Animation error: {e}")

#     # --------------------------------------------------------
#     # SET ROBOT STATE
#     # --------------------------------------------------------

#     def set_state(self, new_state):

#         if new_state == self.current_state:
#             return

#         print(
#             f"[ROBOT] STATE: "
#             f"{self.current_state} -> {new_state}"
#         )

#         self.current_state = new_state

#         self.start_animation(new_state)

#     # --------------------------------------------------------
#     # PYTTSX3 SPEAK
#     # --------------------------------------------------------

#     def speak(self, text):

#         """
#         Optional backend TTS.

#         CURRENT PROJECT FLOW:
#         Browser SpeechSynthesis handles the actual voice.

#         Therefore this function is NOT called by the ADK
#         callback.
#         """

#         if not text:
#             return

#         if self.engine is None:

#             try:

#                 self.engine = pyttsx3.init()

#             except Exception as e:

#                 print(
#                     f"[ROBOT] pyttsx3 initialization failed: {e}"
#                 )

#                 return

#         self.set_state(RobotState.SPEAKING)

#         try:

#             self.engine.say(text)
#             self.engine.runAndWait()

#         except Exception as e:

#             print(f"[ROBOT] TTS error: {e}")

#         finally:

#             self.set_state(RobotState.LISTENING)


# # ============================================================
# # CREATE ROBOT
# # ============================================================

# robot = RobotHeadController()


# # ============================================================
# # RESUME TEXT EXTRACTION
# # ============================================================

# def getText() -> str:

#     resume_path = RESUME_PATH

#     if not os.path.exists(resume_path):

#         print(
#             f"[RESUME] Uploaded resume not found: "
#             f"{resume_path}"
#         )

#         resume_path = "sample_resume.pdf"

#     if not os.path.exists(resume_path):

#         print("[RESUME] No resume PDF found.")

#         return ""

#     text = ""

#     try:

#         with pdfplumber.open(resume_path) as pdf:

#             for page in pdf.pages:

#                 page_text = page.extract_text()

#                 if page_text:

#                     text += page_text + "\n"

#         print(
#             f"[RESUME] Extracted "
#             f"{len(text)} characters."
#         )

#         return text

#     except Exception as e:

#         print(
#             f"[RESUME] Error extracting resume: {e}"
#         )

#         return ""


# # ============================================================
# # ADK CALLBACK
# # ============================================================

# def Speak(callback_context):

#     """
#     ADK callback.

#     IMPORTANT:
#     The browser is responsible for actual voice output.

#     Therefore this callback DOES NOT call pyttsx3.
#     """

#     print(
#         "[AGENT] Speak callback triggered - "
#         "browser will handle TTS"
#     )

#     return None


# # ============================================================
# # GEMINI CONFIGURATION
# # ============================================================

# retry_config = types.HttpRetryOptions(

#     attempts=5,

#     exp_base=7,

#     initial_delay=1,

#     http_status_codes=[
#         429,
#         500,
#         503,
#         504
#     ]
# )


# # ============================================================
# # CAMERA AGENT
# # ============================================================

# CameraAgent = LlmAgent(
#     name="CamAgent"
# )


# # ============================================================
# # INTERVIEW AGENT
# # ============================================================

# interviewAgent = LlmAgent(

#     name="InterviewAgent",

#     model=Gemini(
#         model="gemini-3.5-flash-lite",
#         retry_options=retry_config
#     ),

#     description=(
#         "You are an AI professional interviewer "
#         "who interviews candidates based on their resumes."
#     ),

#     instruction="""

# You are a professional interviewer conducting a
# technical recruitment interview.

# IMPORTANT RULES:

# 1. Use the getText() tool to extract the candidate's
#    resume text.

# 2. Study the candidate's resume carefully.

# 3. Ask ONLY ONE question at a time.

# 4. After asking a question, WAIT for the candidate's
#    answer before asking the next question.

# 5. Ask at least 2 questions about the candidate
#    personally, such as:
#    - Introduction
#    - Background
#    - Career goals
#    - Interests

# 6. Ask at least 4 technical questions based specifically
#    on the skills, technologies and projects present in
#    the candidate's resume.

# 7. Do NOT invent technologies or projects that are not
#    present in the resume.

# 8. Questions should progressively evaluate:
#    - Understanding
#    - Practical knowledge
#    - Problem solving
#    - Technical depth

# 9. Keep each interviewer response concise and natural
#    because it will be converted into speech.

# 10. Do not ask multiple questions in one response.

# 11. Do not repeat a question that has already been asked.

# 12. Maintain awareness of the previous conversation.

# 13. After all required questions have been completed,
#     provide an overall summary of the candidate's
#     performance.

# 14. The final summary should include:
#     - Strengths
#     - Technical knowledge
#     - Communication
#     - Problem solving
#     - Areas for improvement
#     - Overall assessment

# 15. Always use the candidate's resume information when
#     discussing their background, skills and projects.

# 16. Never generate a second answer to the same candidate
#     response.

# """,

#     after_agent_callback=Speak,

#     tools=[getText]
# )


# # ============================================================
# # ADK SESSION SERVICE
# # ============================================================

# session_service = InMemorySessionService()


# # ============================================================
# # RUNNER
# # ============================================================

# runner = Runner(

#     agent=interviewAgent,

#     app_name=APP_NAME,

#     session_service=session_service
# )


# # ============================================================
# # RUN ADK SESSION
# # ============================================================

# async def run_session(
#     runner: Runner,
#     query: str,
#     session_id: str
# ):

#     print()
#     print("=" * 60)
#     print("[ADK] NEW MODEL REQUEST")
#     print(f"[ADK] Session ID : {session_id}")
#     print(f"[ADK] User       : {USER_ID}")
#     print(f"[ADK] Query      : {query}")
#     print("=" * 60)

#     if not query or not query.strip():

#         print(
#             "[ADK] Empty user query. "
#             "Skipping model request."
#         )

#         return None

#     query_content = types.Content(

#         role="user",

#         parts=[
#             types.Part(
#                 text=query.strip()
#             )
#         ]

#     )

#     model_text = None

#     try:

#         async for event in runner.run_async(

#             user_id=USER_ID,

#             session_id=session_id,

#             new_message=query_content

#         ):

#             # Only use the final response.

#             if not event.is_final_response():
#                 continue

#             if not event.content:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     model_text = part.text.strip()

#                     print()
#                     print("[ADK] FINAL MODEL RESPONSE:")
#                     print(model_text)
#                     print()

#                     break

#             if model_text:
#                 break

#     except Exception as e:

#         print(
#             f"[ADK] Model execution error: {e}"
#         )

#         raise

#     if not model_text:

#         print(
#             "[ADK] WARNING: "
#             "No final model response received."
#         )

#     return model_text


# # ============================================================
# # SAVE CONVERSATION
# # ============================================================

# def save_conversation(session):

#     conversation_data = []

#     try:

#         if not session:
#             return conversation_data

#         for event in session.events:

#             if not event.content:
#                 continue

#             role = event.content.role

#             if role not in ["user", "model"]:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     conversation_data.append({

#                         "role": role,

#                         "text": part.text.strip()

#                     })

#         os.makedirs(
#             os.path.dirname(CONVERSATION_PATH),
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 conversation_data,
#                 f,
#                 indent=4,
#                 ensure_ascii=False
#             )

#         print(
#             f"[CONVERSATION] Saved "
#             f"{len(conversation_data)} messages."
#         )

#     except Exception as e:

#         print(
#             f"[CONVERSATION] Save error: {e}"
#         )

#     return conversation_data


# # ============================================================
# # FASTAPI LIFESPAN
# # ============================================================

# @asynccontextmanager
# async def lifespan(app: FastAPI):

#     print()
#     print("=" * 60)
#     print("VOICE BASED AI INTERVIEWER BACKEND")
#     print("=" * 60)

#     robot.connect()

#     if robot.connected:

#         robot.current_state = RobotState.IDLE

#         robot.start_animation(
#             RobotState.IDLE
#         )

#     yield

#     print(
#         "[SERVER] Shutting down..."
#     )

#     robot.disconnect()


# # ============================================================
# # FASTAPI APP
# # ============================================================

# app = FastAPI(
#     lifespan=lifespan
# )


# # ============================================================
# # CORS
# # ============================================================

# app.add_middleware(

#     CORSMiddleware,

#     allow_origins=["*"],

#     allow_credentials=True,

#     allow_methods=["*"],

#     allow_headers=["*"]

# )


# # ============================================================
# # UPLOAD RESUME
# # ============================================================

# @app.post("/upload-resume")
# async def upload_resume(
#     file: UploadFile = File(...)
# ):

#     try:

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         data = await file.read()

#         with open(
#             RESUME_PATH,
#             "wb"
#         ) as f:

#             f.write(data)

#         print(
#             f"[RESUME] Uploaded: "
#             f"{len(data)} bytes"
#         )

#         return {

#             "status": "success",

#             "message": "Resume uploaded successfully."

#         }

#     except Exception as e:

#         print(
#             f"[RESUME] Upload error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # START NEW INTERVIEW
# # ============================================================

# @app.post("/start-interview")
# async def start_interview():

#     global CURRENT_SESSION_ID
#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE

#     try:

#         # ----------------------------------------------------
#         # CREATE UNIQUE SESSION
#         # ----------------------------------------------------

#         CURRENT_SESSION_ID = (
#             f"interview_{uuid.uuid4().hex}"
#         )

#         print()
#         print("=" * 60)
#         print("[INTERVIEW] NEW INTERVIEW STARTED")
#         print(
#             f"[INTERVIEW] Session: "
#             f"{CURRENT_SESSION_ID}"
#         )
#         print("=" * 60)

#         # ----------------------------------------------------
#         # RESET DUPLICATE PROTECTION
#         # ----------------------------------------------------

#         LAST_AUDIO_HASH = None
#         LAST_MODEL_RESPONSE = None

#         # ----------------------------------------------------
#         # CREATE ADK SESSION
#         # ----------------------------------------------------

#         await session_service.create_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         # ----------------------------------------------------
#         # CLEAR OLD INTERVIEW DATA
#         # ----------------------------------------------------

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 [],
#                 f
#             )

#         with open(
#             EXPRESSIONS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         with open(
#             EVENTS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         if os.path.exists(
#             COMPRESSED_EVENTS_PATH
#         ):

#             with open(
#                 COMPRESSED_EVENTS_PATH,
#                 "w",
#                 encoding="utf-8"
#             ) as f:

#                 json.dump(
#                     [],
#                     f
#                 )

#         # ----------------------------------------------------
#         # ROBOT LISTENING
#         # ----------------------------------------------------

#         # ----------------------------------------------------
#         # ROBOT STATE
#         # The frontend controls the interview's visual sequence:
#         # GREETING -> SPEAKING -> LISTENING
#         # ----------------------------------------------------

#         # Do not set LISTENING here.
#         # The frontend will send the appropriate state after
#         # the interview-start request has completed.

#         return {

#             "status": "success",

#             "message":
#                 "New interview session started.",

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             f"[INTERVIEW] Start error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # TRANSCRIBE + AI RESPONSE
# # ============================================================

# @app.post("/transcribe")
# async def transcribe(
#     audio: UploadFile = File(...)
# ):

#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE
#     global CURRENT_SESSION_ID

#     # ========================================================
#     # IMPORTANT:
#     # Only one transcription request can run at a time.
#     # ========================================================

#     async with transcribe_lock:

#         request_id = uuid.uuid4().hex[:8]

#         print()
#         print("=" * 70)
#         print(
#             f"[TRANSCRIBE] NEW REQUEST "
#             f"ID={request_id}"
#         )
#         print("=" * 70)

#         try:

#             # ------------------------------------------------
#             # CHECK SESSION
#             # ------------------------------------------------

#             if not CURRENT_SESSION_ID:

#                 print(
#                     "[TRANSCRIBE] ERROR: "
#                     "No active interview session."
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "Please start a new interview first."

#                 }

#             # ------------------------------------------------
#             # ROBOT THINKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.THINKING
#             )

#             # ------------------------------------------------
#             # ANALYZE FACE EXPRESSIONS
#             # ------------------------------------------------

#             try:

#                 analyze_expressions()

#             except Exception as e:

#                 print(
#                     "[VISION] Expression analysis error:",
#                     e
#                 )

#             # ------------------------------------------------
#             # READ AUDIO
#             # ------------------------------------------------

#             audio_data = await audio.read()

#             if not audio_data:

#                 print(
#                     "[TRANSCRIBE] Empty audio."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not hear your answer. "
#                         "Please try again."

#                 }

#             print(
#                 f"[TRANSCRIBE] Audio size: "
#                 f"{len(audio_data)} bytes"
#             )

#             # ------------------------------------------------
#             # CREATE AUDIO HASH
#             # ------------------------------------------------

#             audio_hash = hashlib.sha256(
#                 audio_data
#             ).hexdigest()

#             print(
#                 f"[TRANSCRIBE] Audio hash: "
#                 f"{audio_hash[:16]}..."
#             )

#             # ------------------------------------------------
#             # DUPLICATE AUDIO CHECK
#             # ------------------------------------------------

#             if (
#                 LAST_AUDIO_HASH is not None
#                 and audio_hash == LAST_AUDIO_HASH
#             ):

#                 print()
#                 print(
#                     "[TRANSCRIBE] DUPLICATE AUDIO "
#                     "DETECTED."
#                 )

#                 print(
#                     "[TRANSCRIBE] "
#                     "Gemini will NOT be called again."
#                 )

#                 robot.set_state(
#                     RobotState.SPEAKING
#                 )

#                 return {

#                     "transcript":
#                         "(duplicate request)",

#                     "model":
#                         LAST_MODEL_RESPONSE
#                         or
#                         "Please continue."

#                 }

#             # ------------------------------------------------
#             # SAVE AUDIO
#             # ------------------------------------------------

#             os.makedirs(
#                 BASE_DIR,
#                 exist_ok=True
#             )

#             with open(
#                 AUDIO_PATH,
#                 "wb"
#             ) as f:

#                 f.write(audio_data)

#             print(
#                 f"[TRANSCRIBE] Saved audio: "
#                 f"{AUDIO_PATH}"
#             )

#             # ------------------------------------------------
#             # LOAD WHISPER
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Loading model..."
#             )

#             model = whisper.load_model(
#                 "base"
#             )

#             print(
#                 "[WHISPER] Model loaded."
#             )

#             # ------------------------------------------------
#             # TRANSCRIBE
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Transcribing..."
#             )

#             result = model.transcribe(
#                 AUDIO_PATH
#             )

#             text = (
#                 result
#                 .get("text", "")
#                 .strip()
#             )

#             print()
#             print(
#                 "[WHISPER] TRANSCRIPT:"
#             )
#             print(text)
#             print()

#             # ------------------------------------------------
#             # EMPTY TRANSCRIPT
#             # ------------------------------------------------

#             if not text:

#                 print(
#                     "[WHISPER] Empty transcript."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not understand your "
#                         "answer. Please try again."

#                 }

#             # ------------------------------------------------
#             # STORE HASH ONLY AFTER SUCCESSFUL TRANSCRIPTION
#             # ------------------------------------------------

#             LAST_AUDIO_HASH = audio_hash

#             # ------------------------------------------------
#             # VERIFY SESSION
#             # ------------------------------------------------

#             print(
#                 "[ADK] Using session:",
#                 CURRENT_SESSION_ID
#             )

#             # ------------------------------------------------
#             # SEND TO GEMINI
#             # ------------------------------------------------

#             model_response = await run_session(

#                 runner,

#                 text,

#                 CURRENT_SESSION_ID

#             )

#             # ------------------------------------------------
#             # HANDLE EMPTY MODEL RESPONSE
#             # ------------------------------------------------

#             if not model_response:

#                 print(
#                     "[ADK] No model response."
#                 )

#                 model_response = (
#                     "Thank you for your answer. "
#                     "Let's continue."
#                 )

#             # ------------------------------------------------
#             # SAVE LAST MODEL RESPONSE
#             # ------------------------------------------------

#             LAST_MODEL_RESPONSE = model_response

#             # ------------------------------------------------
#             # READ SESSION ONLY FOR LOGGING
#             #
#             # IMPORTANT:
#             # This does NOT call Gemini again.
#             # ------------------------------------------------

#             session = await session_service.get_session(

#                 app_name=APP_NAME,

#                 user_id=USER_ID,

#                 session_id=CURRENT_SESSION_ID

#             )

#             # ------------------------------------------------
#             # SAVE CONVERSATION
#             # ------------------------------------------------

#             save_conversation(
#                 session
#             )

#             # ------------------------------------------------
#             # ROBOT SPEAKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.SPEAKING
#             )

#             print()
#             print("=" * 70)
#             print(
#                 f"[TRANSCRIBE] REQUEST "
#                 f"{request_id} COMPLETE"
#             )
#             print(
#                 "[TRANSCRIBE] Candidate:",
#                 text
#             )
#             print(
#                 "[TRANSCRIBE] AI:",
#                 model_response
#             )
#             print("=" * 70)
#             print()

#             # ------------------------------------------------
#             # RETURN TO FRONTEND
#             # ------------------------------------------------

#             return {

#                 "transcript": text,

#                 "model": model_response

#             }

#         except Exception as e:

#             print()
#             print(
#                 "[TRANSCRIBE] ERROR:",
#                 str(e)
#             )

#             import traceback

#             traceback.print_exc()

#             robot.set_state(
#                 RobotState.LISTENING
#             )

#             return {

#                 "transcript": "",

#                 "model":
#                     "Sorry, I encountered an error. "
#                     "Please try again."

#             }


# # ============================================================
# # GENERATE FINAL REPORT
# # ============================================================

# @app.post("/generate-report")
# async def generate_report():

#     global CURRENT_SESSION_ID

#     print()
#     print("=" * 60)
#     print("[REPORT] GENERATING FINAL INTERVIEW REPORT")
#     print("=" * 60)

#     try:

#         if not CURRENT_SESSION_ID:

#             return {

#                 "status": "error",

#                 "message":
#                     "No active interview session."

#             }

#         print(
#             "[REPORT] Session:",
#             CURRENT_SESSION_ID
#         )

#         # ----------------------------------------------------
#         # GET CURRENT SESSION
#         # ----------------------------------------------------

#         session = await session_service.get_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         if not session:

#             return {

#                 "status": "error",

#                 "message":
#                     "Interview session not found."

#             }

#         # ----------------------------------------------------
#         # GENERATE REPORT
#         # ----------------------------------------------------

#         report = generate_interview_report(

#             session_service=session_service,

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID,

#             llm_agent=interviewAgent

#         )

#         print(
#             "[REPORT] Report generated successfully."
#         )

#         robot.set_state(
#             RobotState.GOODBYE
#         )

#         return {

#             "status": "success",

#             "report": report,

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             "[REPORT] Error:",
#             str(e)
#         )

#         import traceback

#         traceback.print_exc()

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROBOT STATE API
# # ============================================================

# @app.get("/robot-state")
# async def robot_state():

#     return {

#         "state":
#             robot.current_state,

#         "connected":
#             robot.connected

#     }


# # ============================================================
# # SET ROBOT STATE
# # ============================================================

# @app.post("/robot/state")
# async def set_robot_state(data: dict):

#     state = data.get("state")

#     valid_states = {

#         RobotState.IDLE,

#         RobotState.LISTENING,

#         RobotState.THINKING,

#         RobotState.SPEAKING,

#         RobotState.GREETING,

#         RobotState.ATTENTION,

#         RobotState.GOODBYE

#     }

#     if state not in valid_states:

#         return {

#             "status": "error",

#             "message":
#                 f"Invalid robot state: {state}"

#         }

#     robot.set_state(state)

#     return {

#         "status": "success",

#         "state":
#             robot.current_state

#     }


# # ============================================================
# # TEST ROBOT
# # ============================================================

# @app.get("/robot/test")
# async def robot_test():

#     robot.set_state(
#         RobotState.GREETING
#     )

#     return {

#         "status": "success",

#         "message":
#             "Robot test animation started."

#     }


# # ============================================================
# # MANUAL SERVO ANGLE
# # ============================================================

# @app.post("/robot/angle")
# async def robot_angle(data: dict):

#     try:

#         angle = int(
#             data.get(
#                 "angle",
#                 robot.CENTER_ANGLE
#             )
#         )

#         robot.send_angle(angle)

#         return {

#             "status": "success",

#             "angle": angle

#         }

#     except Exception as e:

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # STOP ROBOT
# # ============================================================

# @app.post("/robot/stop")
# async def robot_stop():

#     robot.stop_animation()

#     robot.stop_servo()

#     robot.current_state = RobotState.IDLE

#     return {

#         "status": "success",

#         "message":
#             "Robot stopped."

#     }


# # ============================================================
# # VIDEO FRAME
# # ============================================================

# @app.post("/video-frame")
# async def video_frame(
#     file: UploadFile = File(...)
# ):

#     try:

#         data = await file.read()

#         if not data:

#             return {

#                 "status": "error",

#                 "message":
#                     "Empty video frame."

#             }

#         np_arr = np.frombuffer(
#             data,
#             np.uint8
#         )

#         frame = cv2.imdecode(
#             np_arr,
#             cv2.IMREAD_COLOR
#         )

#         if frame is None:

#             return {

#                 "status": "error",

#                 "message":
#                     "Could not decode image."

#             }

#         # ----------------------------------------------------
#         # MediaPipe processing can be performed here if needed.
#         # ----------------------------------------------------

#         return {

#             "status": "success"

#         }

#     except Exception as e:

#         print(
#             "[VIDEO] Frame processing error:",
#             e
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROOT
# # ============================================================

# @app.get("/")
# async def root():

#     return {

#         "status": "online",

#         "application":
#             "Voice Based AI Interviewer",

#         "session":
#             CURRENT_SESSION_ID,

#         "robot_state":
#             robot.current_state,

#         "robot_connected":
#             robot.connected

#     }


# # ============================================================
# # RUN:
# #
# # uvicorn FinalBackend:app --reload
# #
# # ============================================================





# # ============================================================
# # FINAL BACKEND -- VOICE BASED AI INTERVIEWER
# # ============================================================

# from fastapi import FastAPI, UploadFile, File
# from fastapi.responses import FileResponse, StreamingResponse
# from fastapi.middleware.cors import CORSMiddleware

# from contextlib import asynccontextmanager

# import pdfplumber
# import os
# import asyncio
# import uuid
# import json
# import time
# import hashlib
# import threading

# import cv2
# import numpy as np
# import mediapipe as mp

# from google.adk.agents import LlmAgent
# from google.adk.models.google_llm import Gemini
# from google.adk.sessions import InMemorySessionService
# from google.adk.runners import Runner
# from google.genai import types

# from mediapipe.tasks import python
# from mediapipe.tasks.python import vision

# from interview_event_detector1 import analyze_expressions
# from interview_report_generator import generate_interview_report

# import whisper
# import requests  # For WiFi communication with ESP32

# # Optional legacy serial mode (used only when USE_WIFI=false).
# try:
#     import serial
# except ImportError:
#     serial = None

# import pyttsx3


# GOOGLE_API_KEY = "AQ.Ab8RN6KsFdoZj_CiRKExRyTTFkNkyTCmjbpMifG_1gq2rPmGRw"
# os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# # ============================================================
# # CONFIGURATION
# # ============================================================

# # ESP32 Serial Configuration (Legacy - for serial communication)
# ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
# ESP32_BAUD = 115200

# # ESP32 WiFi Configuration (New - for wireless communication)
# ESP32_IP = os.getenv("ESP32_IP", "10.61.133.200")  # ESP32's IP address
# ESP32_PORT_HTTP = 80  # HTTP server port on ESP32
# USE_WIFI = os.getenv("USE_WIFI", "true").lower() == "true"  # Set to "true" to use WiFi

# APP_NAME = "InterviewApp"
# USER_ID = "demo_candidate"

# CURRENT_SESSION_ID = None

# # Prevent two /transcribe requests from being processed together.
# transcribe_lock = asyncio.Lock()

# # Duplicate request protection.
# LAST_AUDIO_HASH = None
# LAST_MODEL_RESPONSE = None

# # ============================================================
# # FILE PATHS
# # ============================================================

# BASE_DIR = os.getenv("INTERVIEW_DATA_DIR", os.path.dirname(os.path.abspath(__file__)))

# RESUME_PATH = os.path.join(BASE_DIR, "uploaded_resume.pdf")
# AUDIO_PATH = os.path.join(BASE_DIR, "recording.webm")
# CONVERSATION_PATH = os.path.join(BASE_DIR, "conversation.json")
# EXPRESSIONS_PATH = os.path.join(BASE_DIR, "expressions.log")
# EVENTS_PATH = os.path.join(BASE_DIR, "events.json")
# COMPRESSED_EVENTS_PATH = os.path.join(BASE_DIR, "compressed_events.json")

# # Video telemetry and generated report artifacts.
# MODEL_PATH = os.path.join(BASE_DIR, "face_landmarker.task")
# INTERVIEW_LOG_PATH = os.path.join(BASE_DIR, "interview_log.json")
# REPORT_PDF_PATH = os.path.join(BASE_DIR, "interview_analysis_report.pdf")

# # The detector is created lazily so a missing model file does not prevent
# # the API and robot endpoints from starting. Video processing initializes it
# # when the first frame arrives.
# face_landmarker = None
# face_landmarker_lock = threading.Lock()
# telemetry_lock = threading.Lock()
# VIDEO_TIMELINE = []
# INTERVIEW_STARTED_AT = None
# BLINK_COUNT = 0
# BLINK_STATE = False


# # ============================================================
# # VIDEO TELEMETRY HELPERS (MediaPipe Tasks Face Landmarker)
# # ============================================================

# # Landmark indices from the supplied reference implementation.
# LIP_TOP, LIP_BOTTOM = 13, 14
# LIP_LEFT, LIP_RIGHT = 61, 291
# LEFT_IRIS = [468, 469, 470, 471]
# LEFT_EYE_INNER, LEFT_EYE_OUTER = 133, 33
# L_EYE_TOP, L_EYE_BOTTOM = 159, 145
# R_EYE_TOP, R_EYE_BOTTOM = 386, 374
# L_EYE_LEFT, L_EYE_RIGHT = 33, 133
# R_EYE_LEFT, R_EYE_RIGHT = 362, 263


# def _get_face_landmarker():
#     """Create and cache the MediaPipe detector when the model is available."""
#     global face_landmarker
#     with face_landmarker_lock:
#         if face_landmarker is not None:
#             return face_landmarker
#         if not os.path.isfile(MODEL_PATH):
#             raise FileNotFoundError(
#                 f"MediaPipe model not found: {MODEL_PATH}. "
#                 "Place face_landmarker.task beside the backend data files."
#             )
#         base_options = python.BaseOptions(model_asset_path=MODEL_PATH)
#         options = vision.FaceLandmarkerOptions(
#             base_options=base_options,
#             output_face_blendshapes=True,
#             output_facial_transformation_matrixes=False,
#             num_faces=1
#         )
#         face_landmarker = vision.FaceLandmarker.create_from_options(options)
#         print(f"[VIDEO] MediaPipe FaceLandmarker loaded: {MODEL_PATH}")
#         return face_landmarker


# def _point_distance(p1, p2):
#     return float(np.linalg.norm(np.asarray(p1, dtype=np.float32) - np.asarray(p2, dtype=np.float32)))


# def _calculate_ear(coords, eye_top, eye_bottom, eye_left, eye_right):
#     vertical = _point_distance(coords[eye_top], coords[eye_bottom])
#     horizontal = _point_distance(coords[eye_left], coords[eye_right])
#     return vertical / (horizontal + 1e-6)


# def _write_json_atomic(path, data):
#     os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
#     temp_path = path + ".tmp"
#     with open(temp_path, "w", encoding="utf-8") as f:
#         json.dump(data, f, indent=2, ensure_ascii=False)
#     os.replace(temp_path, path)


# def _process_interview_frame(frame):
#     """Analyze one decoded BGR frame and append reference-style telemetry."""
#     global BLINK_COUNT, BLINK_STATE
#     detector = _get_face_landmarker()
#     height, width = frame.shape[:2]
#     rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
#     mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
#     result = detector.detect(mp_image)
#     now = time.time()

#     with telemetry_lock:
#         started_at = INTERVIEW_STARTED_AT if INTERVIEW_STARTED_AT is not None else now
#         timestamp = round(max(0.0, now - started_at), 2)
#         record = {
#             "timestamp_seconds": timestamp,
#             "face_detected": False,
#             "gaze": "No Face Detected",
#             "speech": "Silent",
#             "expression": "Neutral",
#             "left_ear": None,
#             "right_ear": None,
#             "gaze_ratio": None,
#             "current_blink_total": BLINK_COUNT
#         }

#         if result.face_landmarks:
#             landmarks = result.face_landmarks[0]
#             coords = [(int(lm.x * width), int(lm.y * height)) for lm in landmarks]
#             record["face_detected"] = True

#             # Speaking: lip opening relative to mouth width, as in the reference.
#             if len(coords) > max(LIP_TOP, LIP_BOTTOM, LIP_LEFT, LIP_RIGHT):
#                 lip_dist = _point_distance(coords[LIP_TOP], coords[LIP_BOTTOM])
#                 lip_width = _point_distance(coords[LIP_LEFT], coords[LIP_RIGHT])
#                 if lip_dist / (lip_width + 1e-6) > 0.15:
#                     record["speech"] = "Speaking"

#             # Gaze estimate based on the left iris relative to the inner eye corner.
#             if len(coords) > max(LEFT_IRIS + [LEFT_EYE_INNER, LEFT_EYE_OUTER]):
#                 iris_center = np.mean([coords[i] for i in LEFT_IRIS], axis=0)
#                 eye_width = _point_distance(coords[LEFT_EYE_INNER], coords[LEFT_EYE_OUTER])
#                 gaze_dist = _point_distance(coords[LEFT_EYE_INNER], iris_center)
#                 gaze_ratio = gaze_dist / (eye_width + 1e-6)
#                 record["gaze_ratio"] = round(float(gaze_ratio), 4)
#                 record["gaze"] = "Eye-Contact" if 0.38 <= gaze_ratio <= 0.62 else "Looked Away"

#             # Blink counting via average eye aspect ratio (EAR).
#             required_eye_indices = max(L_EYE_TOP, L_EYE_BOTTOM, R_EYE_TOP, R_EYE_BOTTOM,
#                                        L_EYE_LEFT, L_EYE_RIGHT, R_EYE_LEFT, R_EYE_RIGHT)
#             if len(coords) > required_eye_indices:
#                 left_ear = _calculate_ear(coords, L_EYE_TOP, L_EYE_BOTTOM, L_EYE_LEFT, L_EYE_RIGHT)
#                 right_ear = _calculate_ear(coords, R_EYE_TOP, R_EYE_BOTTOM, R_EYE_LEFT, R_EYE_RIGHT)
#                 avg_ear = (left_ear + right_ear) / 2.0
#                 record["left_ear"] = round(left_ear, 4)
#                 record["right_ear"] = round(right_ear, 4)
#                 if avg_ear < 0.20:
#                     if not BLINK_STATE:
#                         BLINK_STATE = True
#                 elif BLINK_STATE:
#                     BLINK_COUNT += 1
#                     BLINK_STATE = False

#             # Interview expression priority matrix from the supplied reference.
#             if result.face_blendshapes:
#                 scores = {b.category_name: float(b.score) for b in result.face_blendshapes[0]}
#                 if scores.get("jawOpen", 0) > 0.35:
#                     expression = "Surprised"
#                 elif scores.get("mouthSmileLeft", 0) > 0.40 or scores.get("mouthSmileRight", 0) > 0.40:
#                     expression = "Smiling / Confident"
#                 elif scores.get("browDownLeft", 0) > 0.40 or scores.get("browDownRight", 0) > 0.40:
#                     expression = "Frowning / Deep Focus"
#                 elif scores.get("browOuterUpLeft", 0) > 0.35 or scores.get("mouthStretchLeft", 0) > 0.35:
#                     expression = "Anxious / Stressed"
#                 elif scores.get("mouthFrownLeft", 0) > 0.30 or scores.get("eyeLookInLeft", 0) > 0.40:
#                     expression = "Pensive / Evaluating"
#                 else:
#                     expression = "Neutral"
#                 record["blendshape_scores"] = scores
#                 record["expression"] = expression

#         record["current_blink_total"] = BLINK_COUNT
#         VIDEO_TIMELINE.append(record)
#         # Persist after every received frame so partial telemetry survives errors.
#         _write_json_atomic(INTERVIEW_LOG_PATH, VIDEO_TIMELINE)
#         # Keep the established event file available for existing project tooling.
#         _write_json_atomic(EVENTS_PATH, VIDEO_TIMELINE)
#         return record


# def _summarize_video_telemetry():
#     with telemetry_lock:
#         logs = list(VIDEO_TIMELINE)
#         blink_count = BLINK_COUNT
#     if not logs:
#         return {
#             "available": False,
#             "message": "No video frames were recorded during this interview.",
#             "frames_received": 0,
#             "face_detection_coverage_percent": 0.0,
#             "eye_contact_percent": None,
#             "looked_away_percent": None,
#             "speaking_frame_percent": None,
#             "blink_count": blink_count,
#             "blinks_per_minute": None,
#             "expression_percentages": {},
#             "timeline": []
#         }

#     total = len(logs)
#     face_logs = [x for x in logs if x.get("face_detected")]
#     observed = len(face_logs)
#     duration = max(float(logs[-1].get("timestamp_seconds", 0)), 0.0)
#     if INTERVIEW_STARTED_AT is not None:
#         duration = max(duration, time.time() - INTERVIEW_STARTED_AT)
#     gaze_valid = [x for x in face_logs if x.get("gaze") in ("Eye-Contact", "Looked Away")]
#     speaking = sum(1 for x in face_logs if x.get("speech") == "Speaking")
#     expression_names = ["Neutral", "Surprised", "Smiling / Confident", "Frowning / Deep Focus",
#                         "Anxious / Stressed", "Pensive / Evaluating"]
#     expression_pct = {}
#     for name in expression_names:
#         expression_pct[name] = round(100 * sum(1 for x in face_logs if x.get("expression") == name) / observed, 1) if observed else 0.0
#     eye_contact_pct = round(100 * sum(1 for x in gaze_valid if x.get("gaze") == "Eye-Contact") / len(gaze_valid), 1) if gaze_valid else None
#     looked_away_pct = round(100 * sum(1 for x in gaze_valid if x.get("gaze") == "Looked Away") / len(gaze_valid), 1) if gaze_valid else None
#     return {
#         "available": True,
#         "frames_received": total,
#         "face_detected_frames": observed,
#         "face_detection_coverage_percent": round(100 * observed / total, 1),
#         "session_duration_seconds": round(duration, 2),
#         "eye_contact_percent": eye_contact_pct,
#         "looked_away_percent": looked_away_pct,
#         "speaking_frame_percent": round(100 * speaking / observed, 1) if observed else None,
#         "blink_count": blink_count,
#         "blinks_per_minute": round(blink_count / (duration / 60), 1) if duration > 0 else None,
#         "expression_percentages": expression_pct,
#         "timeline": logs
#     }


# def _behavioral_recommendations(analytics):
#     if not analytics.get("available"):
#         return ["Video-based observations were unavailable; use the interview conversation and answers for evaluation."]
#     recs = []
#     gaze = analytics.get("eye_contact_percent")
#     if gaze is not None and gaze < 50:
#         recs.append("Camera engagement: consider positioning the camera near the screen and practising looking toward it while explaining answers.")
#     elif gaze is not None and gaze >= 70:
#         recs.append("Camera engagement: eye-contact estimates were consistently within the configured on-screen gaze range.")
#     coverage = analytics.get("face_detection_coverage_percent", 0)
#     if coverage < 60:
#         recs.append("Video quality: face detection coverage was limited. Improve lighting, camera framing, and keep the face unobstructed before drawing conclusions.")
#     expr = analytics.get("expression_percentages", {})
#     if expr.get("Smiling / Confident", 0) >= 8:
#         recs.append("Expression: smiling-related blendshape signals were observed; use these only as a descriptive observation, not proof of confidence.")
#     if expr.get("Frowning / Deep Focus", 0) >= 20:
#         recs.append("Expression: brow-lowering signals appeared frequently and may coincide with concentration; they cannot establish a candidate's mental state.")
#     if not recs:
#         recs.append("Continue practising clear, structured answers and review the recorded observations alongside the actual interview responses.")
#     return recs


# def _generate_comprehensive_pdf(ai_report, analytics, conversation, session_id):
#     """Build a detailed PDF combining interview content and video telemetry."""
#     from xml.sax.saxutils import escape
#     from reportlab.lib import colors
#     from reportlab.lib.pagesizes import letter
#     from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
#     from reportlab.lib.units import inch
#     from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

#     os.makedirs(BASE_DIR, exist_ok=True)
#     doc = SimpleDocTemplate(REPORT_PDF_PATH, pagesize=letter, rightMargin=0.62*inch,
#                             leftMargin=0.62*inch, topMargin=0.62*inch, bottomMargin=0.62*inch,
#                             title="Comprehensive AI Interview Report", author="Capstone Interview Analytics")
#     styles = getSampleStyleSheet()
#     styles.add(ParagraphStyle(name="ReportTitleCustom", parent=styles["Title"], fontSize=20, leading=25,
#                               textColor=colors.HexColor("#1A365D"), spaceAfter=8))
#     styles.add(ParagraphStyle(name="SectionCustom", parent=styles["Heading2"], fontSize=12, leading=16,
#                               textColor=colors.HexColor("#2B6CB0"), spaceBefore=12, spaceAfter=6))
#     styles.add(ParagraphStyle(name="SmallBodyCustom", parent=styles["BodyText"], fontSize=8.5, leading=12, spaceAfter=5))
#     styles.add(ParagraphStyle(name="QuestionCustom", parent=styles["BodyText"], fontSize=9, leading=13, spaceAfter=7))
#     story = [Paragraph("Comprehensive AI Interview Report", styles["ReportTitleCustom"]),
#              Paragraph(f"<b>Session ID:</b> {escape(str(session_id))}<br/><b>Generated:</b> {time.strftime('%Y-%m-%d %H:%M:%S')}", styles["Normal"]),
#              Spacer(1, 10)]

#     story.append(Paragraph("1. Executive Summary", styles["SectionCustom"]))
#     if isinstance(ai_report, (dict, list)):
#         ai_text = json.dumps(ai_report, ensure_ascii=False, indent=2, default=str)
#     else:
#         ai_text = str(ai_report or "No AI-generated assessment was returned.")
#     # Escape plain text, preserving readable paragraph breaks.
#     story.append(Paragraph(escape(ai_text).replace("\n", "<br/>"), styles["SmallBodyCustom"]))

#     story.append(Paragraph("2. Interview Conversation", styles["SectionCustom"]))
#     if conversation:
#         for idx, item in enumerate(conversation, 1):
#             role = str(item.get("role", "message")).capitalize()
#             message = escape(str(item.get("text", ""))).replace("\n", "<br/>")
#             story.append(Paragraph(f"<b>{idx}. {escape(role)}:</b> {message}", styles["QuestionCustom"]))
#     else:
#         story.append(Paragraph("No saved conversation transcript was found.", styles["SmallBodyCustom"]))

#     story.append(Paragraph("3. Video Telemetry Summary", styles["SectionCustom"]))
#     if analytics.get("available"):
#         metrics = [
#             ["Metric", "Observed result"],
#             ["Frames received", str(analytics.get("frames_received", 0))],
#             ["Face-detection coverage", f"{analytics.get('face_detection_coverage_percent', 0):.1f}%"],
#             ["Estimated eye-contact frames", "N/A" if analytics.get("eye_contact_percent") is None else f"{analytics['eye_contact_percent']:.1f}% of valid gaze frames"],
#             ["Looked-away frames", "N/A" if analytics.get("looked_away_percent") is None else f"{analytics['looked_away_percent']:.1f}% of valid gaze frames"],
#             ["Speaking mouth-shape frames", "N/A" if analytics.get("speaking_frame_percent") is None else f"{analytics['speaking_frame_percent']:.1f}% of face-detected frames"],
#             ["Registered blinks", str(analytics.get("blink_count", 0))],
#             ["Estimated blinks/minute", "N/A" if analytics.get("blinks_per_minute") is None else str(analytics["blinks_per_minute"])],
#             ["Observed duration", f"{analytics.get('session_duration_seconds', 0):.1f} seconds"]
#         ]
#         table = Table(metrics, colWidths=[2.15*inch, 4.3*inch], repeatRows=1)
#         table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
#                                    ("TEXTCOLOR", (0,0), (-1,0), colors.HexColor("#1A365D")),
#                                    ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E0")),
#                                    ("VALIGN", (0,0), (-1,-1), "TOP"),
#                                    ("LEFTPADDING", (0,0), (-1,-1), 6), ("RIGHTPADDING", (0,0), (-1,-1), 6),
#                                    ("TOPPADDING", (0,0), (-1,-1), 5), ("BOTTOMPADDING", (0,0), (-1,-1), 5)]))
#         story.append(table)
#         story.append(Spacer(1, 8))
#         story.append(Paragraph("Expression distribution (percentage of face-detected frames):", styles["SmallBodyCustom"]))
#         exp_rows = [["Expression label", "Share"]] + [[str(k), f"{v:.1f}%"] for k, v in analytics.get("expression_percentages", {}).items()]
#         exp_table = Table(exp_rows, colWidths=[4.5*inch, 1.95*inch], repeatRows=1)
#         exp_table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
#                                        ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#CBD5E0")),
#                                        ("VALIGN", (0,0), (-1,-1), "TOP"), ("LEFTPADDING", (0,0), (-1,-1), 6),
#                                        ("TOPPADDING", (0,0), (-1,-1), 4), ("BOTTOMPADDING", (0,0), (-1,-1), 4)]))
#         story.append(exp_table)
#     else:
#         story.append(Paragraph(escape(analytics.get("message", "No video telemetry available.")), styles["SmallBodyCustom"]))

#     story.append(Paragraph("4. Development Recommendations", styles["SectionCustom"]))
#     for rec in _behavioral_recommendations(analytics):
#         story.append(Paragraph("• " + escape(rec), styles["SmallBodyCustom"]))

#     story.append(Paragraph("5. Sampled Video Timeline", styles["SectionCustom"]))
#     timeline = analytics.get("timeline", [])
#     if timeline:
#         timeline_rows = [["Time (s)", "Face", "Gaze", "Mouth", "Expression", "Blinks"]]
#         for item in timeline:
#             timeline_rows.append([
#                 str(item.get("timestamp_seconds", "")),
#                 "Yes" if item.get("face_detected") else "No",
#                 str(item.get("gaze", "")),
#                 str(item.get("speech", "")),
#                 str(item.get("expression", "")),
#                 str(item.get("current_blink_total", 0))
#             ])
#         timeline_table = Table(timeline_rows, colWidths=[0.55*inch, 0.45*inch, 1.05*inch, 0.55*inch, 2.55*inch, 0.55*inch], repeatRows=1)
#         timeline_table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), colors.HexColor("#EDF2F7")),
#                                             ("GRID", (0,0), (-1,-1), 0.3, colors.HexColor("#CBD5E0")),
#                                             ("FONTSIZE", (0,0), (-1,-1), 6.5),
#                                             ("VALIGN", (0,0), (-1,-1), "TOP"),
#                                             ("LEFTPADDING", (0,0), (-1,-1), 3),
#                                             ("RIGHTPADDING", (0,0), (-1,-1), 3),
#                                             ("TOPPADDING", (0,0), (-1,-1), 3),
#                                             ("BOTTOMPADDING", (0,0), (-1,-1), 3)]))
#         story.append(timeline_table)
#     else:
#         story.append(Paragraph("No sampled video timeline was recorded.", styles["SmallBodyCustom"]))

#     story.append(Paragraph("6. Methodology and Limitations", styles["SectionCustom"]))
#     limitation = ("Video metrics are estimates from sampled webcam frames and configured MediaPipe landmark/blendshape thresholds. "
#                   "Because frame sampling may be sparse, blink counts can be undercounted. Mouth opening is only a visual proxy and "
#                   "does not verify that the candidate's voice is audible. Gaze and facial expressions do not reliably reveal honesty, "
#                   "confidence, stress, personality, or cognitive ability; they must not be used as standalone hiring criteria. "
#                   "Interpret these observations alongside the actual answers, role requirements, and interviewer judgement.")
#     story.append(Paragraph(escape(limitation), styles["SmallBodyCustom"]))
#     doc.build(story)
#     return REPORT_PDF_PATH


# # ============================================================
# # ROBOT STATES
# # ============================================================

# class RobotState:

#     IDLE = "IDLE"
#     LISTENING = "LISTENING"
#     THINKING = "THINKING"
#     SPEAKING = "SPEAKING"
#     GREETING = "GREETING"
#     ATTENTION = "ATTENTION"
#     GOODBYE = "GOODBYE"


# # ============================================================
# # ROBOT HEAD CONTROLLER
# # ============================================================

# class RobotHeadController:

#     def __init__(self):

#         self.serial_conn = None
#         self.connected = False

#         self.current_state = RobotState.IDLE

#         self.animation_thread = None
#         self.animation_running = False

#         self.lock = threading.Lock()

#         self.engine = None

#         # Servo configuration

#         # Servo configuration
#         self.MIN_ANGLE = 40
#         self.MAX_ANGLE = 140
#         self.CENTER_ANGLE = 90

#         # Smooth physical movement
#         self.STEP_DELAY = 0.02

#         # Animation control
#         self.animation_thread = None
#         self.animation_running = False
#         self.animation_id = 0

#         self.lock = threading.Lock()

#         # WiFi/HTTP configuration
#         self.use_wifi = USE_WIFI
#         self.esp32_url = f"http://{ESP32_IP}:{ESP32_PORT_HTTP}"


#     # --------------------------------------------------------
#     # CONNECT ESP32
#     # --------------------------------------------------------

#     def connect(self):

#         if self.use_wifi:
#             self.connect_wifi()
#         else:
#             self.connect_serial()

#     def connect_serial(self):

#         if serial is None:
#             print("[ROBOT] Serial mode requires pyserial. Install with: python -m pip install pyserial")
#             self.connected = False
#             return

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via Serial on {ESP32_PORT}...")

#             self.serial_conn = serial.Serial(
#                 ESP32_PORT,
#                 ESP32_BAUD,
#                 timeout=1
#             )

#             time.sleep(2)

#             self.connected = True

#             print("[ROBOT] ESP32 connected successfully via Serial.")

#             self.send_angle(self.CENTER_ANGLE)

#         except Exception as e:

#             print(f"[ROBOT] ESP32 Serial connection failed: {e}")

#             self.connected = False
#             self.serial_conn = None

#     def connect_wifi(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via WiFi at {self.esp32_url}...")

#             # Test connection by sending a status request
#             response = requests.get(
#                 f"{self.esp32_url}/status",
#                 timeout=5
#             )

#             if response.status_code == 200:
#                 self.connected = True
#                 print("[ROBOT] ESP32 connected successfully via WiFi.")
#                 print(f"[ROBOT] ESP32 Status: {response.json()}")
#                 self.send_angle(self.CENTER_ANGLE)
#             else:
#                 print(f"[ROBOT] ESP32 WiFi connection failed: HTTP {response.status_code}")
#                 self.connected = False

#         except Exception as e:

#             print(f"[ROBOT] ESP32 WiFi connection failed: {e}")
#             self.connected = False

#     # --------------------------------------------------------
#     # DISCONNECT
#     # --------------------------------------------------------

#     def disconnect(self):

#         self.stop_animation()

#         try:

#             if self.use_wifi:
#                 self.send_command("STOP")
#             elif self.serial_conn and self.serial_conn.is_open:
#                 self.send_command("STOP")
#                 self.serial_conn.close()

#         except Exception as e:

#             print(f"[ROBOT] Disconnect error: {e}")

#         self.connected = False

#         print("[ROBOT] ESP32 disconnected.")

#     # --------------------------------------------------------
#     # SEND COMMAND
#     # --------------------------------------------------------

#     def send_command(self, command):

#         if not self.connected:
#             return

#         try:

#             if self.use_wifi:
#                 self.send_command_wifi(command)
#             else:
#                 self.send_command_serial(command)

#         except Exception as e:

#             print(f"[ROBOT] Command send error: {e}")

#     def send_command_serial(self, command):

#         try:

#             with self.lock:

#                 self.serial_conn.write(
#                     (command + "\n").encode()
#                 )

#                 self.serial_conn.flush()

#         except Exception as e:

#             print(f"[ROBOT] Serial write error: {e}")

#     def send_command_wifi(self, command):

#         try:

#             with self.lock:

#                 response = requests.post(
#                     f"{self.esp32_url}/command",
#                     data=command,
#                     timeout=5
#                 )

#                 if response.status_code == 200:
#                     print(f"[ROBOT] WiFi command sent: {command}")
#                 else:
#                     print(f"[ROBOT] WiFi command failed: HTTP {response.status_code}")

#         except Exception as e:

#             print(f"[ROBOT] WiFi write error: {e}")

#     # # --------------------------------------------------------
#     # # SEND SERVO ANGLE
#     # # --------------------------------------------------------

#     # def send_angle(self, angle):

#     #     angle = max(
#     #         self.MIN_ANGLE,
#     #         min(self.MAX_ANGLE, int(angle))
#     #     )

#     #     self.send_command(f"ANGLE:{angle}")


#         # --------------------------------------------------------
#     # SEND SERVO ANGLE (HEAD)
#     # --------------------------------------------------------

#     def send_angle(self, angle):

#         angle = max(
#             self.MIN_ANGLE,
#             min(self.MAX_ANGLE, int(angle))
#         )

#         self.send_command(f"ANGLE:{angle}")

#     # --------------------------------------------------------
#     # SEND HAND ANGLES (NEW HELPER)
#     # --------------------------------------------------------

#     def send_hand_angles(self, left, right):
#         """
#         Sends independent, clamped target angles to the hand servos.
#         Because the ESP32 internally maps the right hand using (180 - angle),
#         sending identical angles from the backend results in physically 
#         coordinated, mirrored gestures.
#         """
#         left_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(left)))
#         right_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(right)))
        
#         self.send_command(f"LEFT:{left_clamped}")
#         self.send_command(f"RIGHT:{right_clamped}")

#     # --------------------------------------------------------
#     # STOP SERVO
#     # --------------------------------------------------------

#     def stop_servo(self):

#         self.send_command("STOP")

#     # --------------------------------------------------------
#     # ANIMATION
#     # --------------------------------------------------------

#     def start_animation(self, state):
#         self.stop_animation()

#         self.animation_running = True
#         generation = self.animation_id

#         self.animation_thread = threading.Thread(
#             target=self.animation_loop,
#             args=(state, generation),
#             daemon=True
#         )
#         self.animation_thread.start()

#     def stop_animation(self):
#         self.animation_running = False

#         # Invalidate every older animation thread.
#         self.animation_id += 1

#         old_thread = self.animation_thread

#         if (
#             old_thread
#             and old_thread.is_alive()
#             and old_thread != threading.current_thread()
#         ):
#             old_thread.join(timeout=0.7)

#         self.animation_thread = None

#     # --------------------------------------------------------
#     # ANIMATION LOOP (UPDATED TO INTEGRATE HAND GESTURES)
#     # --------------------------------------------------------

#     def animation_loop(self, state, generation):
#         """
#         State-driven robot head and hand animation.
#         Coordinated, non-blocking physical gestures.
#         """

#         def active():
#             return (
#                 self.animation_running
#                 and generation == self.animation_id
#             )

#         def move(head_ang, left_ang=90, right_ang=90, pause=0.0):
#             if not active():
#                 return False

#             # Dispatch head and hand instructions safely across Wi-Fi
#             self.send_angle(head_ang)
#             self.send_hand_angles(left_ang, right_ang)

#             if pause > 0:
#                 deadline = time.monotonic() + pause
#                 while active() and time.monotonic() < deadline:
#                     time.sleep(0.05)

#             return active()

#         try:
#             # ------------------------------------------
#             # IDLE / LISTENING / THINKING: Rest positions
#             # ------------------------------------------
#             if state == RobotState.IDLE:
#                 move(90, 90, 90)
#                 return

#             elif state == RobotState.LISTENING:
#                 # Attentive head tilt, hands relaxed at base rest (90)
#                 if not move(76, 90, 90, 0.8):
#                     return
#                 while active():
#                     time.sleep(0.05)

#             elif state == RobotState.THINKING:
#                 # Look aside, keep hands resting to express analytical calm
#                 if not move(108, 90, 90, 1.4):
#                     return
#                 while active():
#                     if not move(102, 90, 90, 1.8): break
#                     if not move(110, 90, 90, 1.2): break
#                     if not move(90, 90, 90, 2.5): break

#             # ------------------------------------------
#             # SPEAKING: Dynamic conversational expressions
#             # ------------------------------------------
#             elif state == RobotState.SPEAKING:
#                 if not move(90, 90, 90):
#                     return

#                 while active():
#                     # Subtle mirrored conversational expansion (opening up)
#                     if not move(98, 75, 75, 0.45): break
#                     if not move(90, 90, 90, 1.0): break
#                     # Alternating asymmetrical emphasis shifts
#                     if not move(82, 105, 80, 0.45): break
#                     if not move(90, 90, 90, 1.5): break

#             # ------------------------------------------
#             # GREETING: Welcome presentation gesture
#             # ------------------------------------------
#             elif state == RobotState.GREETING:
#                 # Graceful sweep opening both hands outward together
#                 if not move(72, 60, 60, 0.45): return
#                 if not move(108, 60, 60, 0.55): return
#                 # Gradually return to center balance positions
#                 if not move(78, 80, 80, 0.45): return
#                 move(90, 90, 90, 0.8)

#             # ------------------------------------------
#             # ATTENTION: Orient towards user
#             # ------------------------------------------
#             elif state == RobotState.ATTENTION:
#                 if not move(110, 90, 90, 0.8): return
#                 if not move(90, 90, 90, 1.0): return

#                 while active():
#                     if not move(96, 90, 90, 0.8): break
#                     if not move(90, 90, 90, 2.5): break

#             # ------------------------------------------
#             # GOODBYE: Closing polite gesture
#             # ------------------------------------------
#             elif state == RobotState.GOODBYE:
#                 # Brief parting hand gesture, then drop smoothly down to rest
#                 if not move(72, 70, 70, 0.45): return
#                 if not move(108, 70, 70, 0.55): return
#                 if not move(72, 90, 90, 0.45): return
#                 move(90, 90, 90, 1.0)

#         except Exception as e:
#             print(f"[ROBOT] Animation error: {e}")

#     # --------------------------------------------------------
#     # SET ROBOT STATE
#     # --------------------------------------------------------

#     def set_state(self, new_state):

#         thread_alive = (
#             self.animation_thread is not None
#             and self.animation_thread.is_alive()
#         )

#         if new_state == self.current_state and thread_alive:
#             return

#         print(
#             f"[ROBOT] STATE: "
#             f"{self.current_state} -> {new_state}"
#         )

#         self.current_state = new_state
#         self.start_animation(new_state)

#     # --------------------------------------------------------
#     # PYTTSX3 SPEAK
#     # --------------------------------------------------------

#     def speak(self, text):

#         """
#         Optional backend TTS.

#         CURRENT PROJECT FLOW:
#         Browser SpeechSynthesis handles the actual voice.

#         Therefore this function is NOT called by the ADK
#         callback.
#         """

#         if not text:
#             return

#         if self.engine is None:

#             try:

#                 self.engine = pyttsx3.init()

#             except Exception as e:

#                 print(
#                     f"[ROBOT] pyttsx3 initialization failed: {e}"
#                 )

#                 return

#         self.set_state(RobotState.SPEAKING)

#         try:

#             self.engine.say(text)
#             self.engine.runAndWait()

#         except Exception as e:

#             print(f"[ROBOT] TTS error: {e}")

#         finally:

#             self.set_state(RobotState.LISTENING)


# # ============================================================
# # CREATE ROBOT
# # ============================================================

# robot = RobotHeadController()


# # ============================================================
# # RESUME TEXT EXTRACTION
# # ============================================================

# def getText() -> str:

#     resume_path = RESUME_PATH

#     if not os.path.exists(resume_path):

#         print(
#             f"[RESUME] Uploaded resume not found: "
#             f"{resume_path}"
#         )

#         resume_path = "sample_resume.pdf"

#     if not os.path.exists(resume_path):

#         print("[RESUME] No resume PDF found.")

#         return ""

#     text = ""

#     try:

#         with pdfplumber.open(resume_path) as pdf:

#             for page in pdf.pages:

#                 page_text = page.extract_text()

#                 if page_text:

#                     text += page_text + "\n"

#         print(
#             f"[RESUME] Extracted "
#             f"{len(text)} characters."
#         )

#         return text

#     except Exception as e:

#         print(
#             f"[RESUME] Error extracting resume: {e}"
#         )

#         return ""


# # ============================================================
# # ADK CALLBACK
# # ============================================================

# def Speak(callback_context):

#     """
#     ADK callback.

#     IMPORTANT:
#     The browser is responsible for actual voice output.

#     Therefore this callback DOES NOT call pyttsx3.
#     """

#     print(
#         "[AGENT] Speak callback triggered - "
#         "browser will handle TTS"
#     )

#     return None


# # ============================================================
# # GEMINI CONFIGURATION
# # ============================================================

# retry_config = types.HttpRetryOptions(

#     attempts=5,

#     exp_base=7,

#     initial_delay=1,

#     http_status_codes=[
#         429,
#         500,
#         503,
#         504
#     ]
# )


# # ============================================================
# # CAMERA AGENT
# # ============================================================

# CameraAgent = LlmAgent(
#     name="CamAgent"
# )


# # ============================================================
# # INTERVIEW AGENT
# # ============================================================

# interviewAgent = LlmAgent(

#     name="InterviewAgent",

#     model=Gemini(
#         model="gemini-3.5-flash-lite",
#         retry_options=retry_config
#     ),

#     description=(
#         "You are an AI professional interviewer "
#         "who interviews candidates based on their resumes."
#     ),

#     instruction="""

# You are a professional interviewer conducting a
# technical recruitment interview.

# IMPORTANT RULES:

# 1. Use the getText() tool to extract the candidate's
#    resume text.

# 2. Study the candidate's resume carefully.

# 3. Ask ONLY ONE question at a time.

# 4. After asking a question, WAIT for the candidate's
#    answer before asking the next question.

# 5. Ask at least 2 questions about the candidate
#    personally, such as:
#    - Introduction
#    - Background
#    - Career goals
#    - Interests

# 6. Ask at least 4 technical questions based specifically
#    on the skills, technologies and projects present in
#    the candidate's resume.

# 7. Do NOT invent technologies or projects that are not
#    present in the resume.

# 8. Questions should progressively evaluate:
#    - Understanding
#    - Practical knowledge
#    - Problem solving
#    - Technical depth

# 9. Keep each interviewer response concise and natural
#    because it will be converted into speech.

# 10. Do not ask multiple questions in one response.

# 11. Do not repeat a question that has already been asked.

# 12. Maintain awareness of the previous conversation.

# 13. After all required questions have been completed,
#     provide an overall summary of the candidate's
#     performance.

# 14. The final summary should include:
#     - Strengths
#     - Technical knowledge
#     - Communication
#     - Problem solving
#     - Areas for improvement
#     - Overall assessment

# 15. Always use the candidate's resume information when
#     discussing their background, skills and projects.

# 16. Never generate a second answer to the same candidate
#     response.

# """,

#     after_agent_callback=Speak,

#     tools=[getText]
# )


# # ============================================================
# # ADK SESSION SERVICE
# # ============================================================

# session_service = InMemorySessionService()


# # ============================================================
# # RUNNER
# # ============================================================

# runner = Runner(

#     agent=interviewAgent,

#     app_name=APP_NAME,

#     session_service=session_service
# )


# # ============================================================
# # RUN ADK SESSION
# # ============================================================

# async def run_session(
#     runner: Runner,
#     query: str,
#     session_id: str
# ):

#     print()
#     print("=" * 60)
#     print("[ADK] NEW MODEL REQUEST")
#     print(f"[ADK] Session ID : {session_id}")
#     print(f"[ADK] User       : {USER_ID}")
#     print(f"[ADK] Query      : {query}")
#     print("=" * 60)

#     if not query or not query.strip():

#         print(
#             "[ADK] Empty user query. "
#             "Skipping model request."
#         )

#         return None

#     query_content = types.Content(

#         role="user",

#         parts=[
#             types.Part(
#                 text=query.strip()
#             )
#         ]

#     )

#     model_text = None

#     try:

#         async for event in runner.run_async(

#             user_id=USER_ID,

#             session_id=session_id,

#             new_message=query_content

#         ):

#             # Only use the final response.

#             if not event.is_final_response():
#                 continue

#             if not event.content:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     model_text = part.text.strip()

#                     print()
#                     print("[ADK] FINAL MODEL RESPONSE:")
#                     print(model_text)
#                     print()

#                     break

#             if model_text:
#                 break

#     except Exception as e:

#         print(
#             f"[ADK] Model execution error: {e}"
#         )

#         raise

#     if not model_text:

#         print(
#             "[ADK] WARNING: "
#             "No final model response received."
#         )

#     return model_text


# # ============================================================
# # SAVE CONVERSATION
# # ============================================================

# def save_conversation(session):

#     conversation_data = []

#     try:

#         if not session:
#             return conversation_data

#         for event in session.events:

#             if not event.content:
#                 continue

#             role = event.content.role

#             if role not in ["user", "model"]:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     conversation_data.append({

#                         "role": role,

#                         "text": part.text.strip()

#                     })

#         os.makedirs(
#             os.path.dirname(CONVERSATION_PATH),
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 conversation_data,
#                 f,
#                 indent=4,
#                 ensure_ascii=False
#             )

#         print(
#             f"[CONVERSATION] Saved "
#             f"{len(conversation_data)} messages."
#         )

#     except Exception as e:

#         print(
#             f"[CONVERSATION] Save error: {e}"
#         )

#     return conversation_data


# # ============================================================
# # FASTAPI LIFESPAN
# # ============================================================

# @asynccontextmanager
# async def lifespan(app: FastAPI):

#     print()
#     print("=" * 60)
#     print("VOICE BASED AI INTERVIEWER BACKEND")
#     print("=" * 60)

#     robot.connect()

#     if robot.connected:

#         robot.current_state = RobotState.IDLE

#         robot.start_animation(
#             RobotState.IDLE
#         )

#     yield

#     print(
#         "[SERVER] Shutting down..."
#     )

#     robot.disconnect()


# # ============================================================
# # FASTAPI APP
# # ============================================================

# app = FastAPI(
#     lifespan=lifespan
# )


# # ============================================================
# # CORS
# # ============================================================

# app.add_middleware(

#     CORSMiddleware,

#     allow_origins=["*"],

#     allow_credentials=True,

#     allow_methods=["*"],

#     allow_headers=["*"]

# )


# # ============================================================
# # UPLOAD RESUME
# # ============================================================

# @app.post("/upload-resume")
# async def upload_resume(
#     file: UploadFile = File(...)
# ):

#     try:

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         data = await file.read()

#         with open(
#             RESUME_PATH,
#             "wb"
#         ) as f:

#             f.write(data)

#         print(
#             f"[RESUME] Uploaded: "
#             f"{len(data)} bytes"
#         )

#         return {

#             "status": "success",

#             "message": "Resume uploaded successfully."

#         }

#     except Exception as e:

#         print(
#             f"[RESUME] Upload error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # START NEW INTERVIEW
# # ============================================================

# @app.post("/start-interview")
# async def start_interview():

#     global CURRENT_SESSION_ID
#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE

#     try:

#         # ----------------------------------------------------
#         # CREATE UNIQUE SESSION
#         # ----------------------------------------------------

#         CURRENT_SESSION_ID = (
#             f"interview_{uuid.uuid4().hex}"
#         )

#         print()
#         print("=" * 60)
#         print("[INTERVIEW] NEW INTERVIEW STARTED")
#         print(
#             f"[INTERVIEW] Session: "
#             f"{CURRENT_SESSION_ID}"
#         )
#         print("=" * 60)

#         # ----------------------------------------------------
#         # RESET DUPLICATE PROTECTION
#         # ----------------------------------------------------

#         LAST_AUDIO_HASH = None
#         LAST_MODEL_RESPONSE = None

#         # Reset video telemetry for this interview only.
#         global VIDEO_TIMELINE, INTERVIEW_STARTED_AT, BLINK_COUNT, BLINK_STATE
#         with telemetry_lock:
#             VIDEO_TIMELINE = []
#             INTERVIEW_STARTED_AT = time.time()
#             BLINK_COUNT = 0
#             BLINK_STATE = False
#         os.makedirs(BASE_DIR, exist_ok=True)
#         _write_json_atomic(INTERVIEW_LOG_PATH, [])

#         # ----------------------------------------------------
#         # CREATE ADK SESSION
#         # ----------------------------------------------------

#         await session_service.create_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         # ----------------------------------------------------
#         # CLEAR OLD INTERVIEW DATA
#         # ----------------------------------------------------

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 [],
#                 f
#             )

#         with open(
#             EXPRESSIONS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         with open(
#             EVENTS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         if os.path.exists(
#             COMPRESSED_EVENTS_PATH
#         ):

#             with open(
#                 COMPRESSED_EVENTS_PATH,
#                 "w",
#                 encoding="utf-8"
#             ) as f:

#                 json.dump(
#                     [],
#                     f
#                 )

#         # ----------------------------------------------------
#         # ROBOT GREETING
#         # ----------------------------------------------------
#         # Frontend face sequence: GREETING -> SPEAKING while browser
#         # TTS speaks -> LISTENING after the greeting finishes.
#         robot.set_state(RobotState.GREETING)

#         return {

#             "status": "success",

#             "message":
#                 "New interview session started.",

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             f"[INTERVIEW] Start error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # TRANSCRIBE + AI RESPONSE
# # ============================================================

# @app.post("/transcribe")
# async def transcribe(
#     audio: UploadFile = File(...)
# ):

#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE
#     global CURRENT_SESSION_ID

#     # ========================================================
#     # IMPORTANT:
#     # Only one transcription request can run at a time.
#     # ========================================================

#     async with transcribe_lock:

#         request_id = uuid.uuid4().hex[:8]

#         print()
#         print("=" * 70)
#         print(
#             f"[TRANSCRIBE] NEW REQUEST "
#             f"ID={request_id}"
#         )
#         print("=" * 70)

#         try:

#             # ------------------------------------------------
#             # CHECK SESSION
#             # ------------------------------------------------

#             if not CURRENT_SESSION_ID:

#                 print(
#                     "[TRANSCRIBE] ERROR: "
#                     "No active interview session."
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "Please start a new interview first."

#                 }

#             # Keep this request tied to its original session if a new
#             # interview is started while audio/model processing is active.
#             session_id = CURRENT_SESSION_ID

#             # ------------------------------------------------
#             # ROBOT THINKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.THINKING
#             )

#             # ------------------------------------------------
#             # READ AUDIO
#             # ------------------------------------------------

#             audio_data = await audio.read()

#             if not audio_data:

#                 print(
#                     "[TRANSCRIBE] Empty audio."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not hear your answer. "
#                         "Please try again."

#                 }

#             print(
#                 f"[TRANSCRIBE] Audio size: "
#                 f"{len(audio_data)} bytes"
#             )

#             # ------------------------------------------------
#             # CREATE AUDIO HASH
#             # ------------------------------------------------

#             audio_hash = hashlib.sha256(
#                 audio_data
#             ).hexdigest()

#             print(
#                 f"[TRANSCRIBE] Audio hash: "
#                 f"{audio_hash[:16]}..."
#             )

#             # ------------------------------------------------
#             # DUPLICATE AUDIO CHECK
#             # ------------------------------------------------

#             if (
#                 LAST_AUDIO_HASH is not None
#                 and audio_hash == LAST_AUDIO_HASH
#             ):

#                 print()
#                 print(
#                     "[TRANSCRIBE] DUPLICATE AUDIO "
#                     "DETECTED."
#                 )

#                 print(
#                     "[TRANSCRIBE] "
#                     "Gemini will NOT be called again."
#                 )

#                 robot.set_state(
#                     RobotState.SPEAKING
#                 )

#                 return {

#                     "transcript":
#                         "(duplicate request)",

#                     "model":
#                         LAST_MODEL_RESPONSE
#                         or
#                         "Please continue."

#                 }

#             # ------------------------------------------------
#             # SAVE AUDIO
#             # ------------------------------------------------

#             os.makedirs(
#                 BASE_DIR,
#                 exist_ok=True
#             )

#             with open(
#                 AUDIO_PATH,
#                 "wb"
#             ) as f:

#                 f.write(audio_data)

#             print(
#                 f"[TRANSCRIBE] Saved audio: "
#                 f"{AUDIO_PATH}"
#             )

#             # ------------------------------------------------
#             # LOAD WHISPER
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Loading model..."
#             )

#             model = whisper.load_model(
#                 "base"
#             )

#             print(
#                 "[WHISPER] Model loaded."
#             )

#             # ------------------------------------------------
#             # TRANSCRIBE
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Transcribing..."
#             )

#             result = model.transcribe(
#                 AUDIO_PATH
#             )

#             text = (
#                 result
#                 .get("text", "")
#                 .strip()
#             )

#             print()
#             print(
#                 "[WHISPER] TRANSCRIPT:"
#             )
#             print(text)
#             print()

#             # ------------------------------------------------
#             # EMPTY TRANSCRIPT
#             # ------------------------------------------------

#             if not text:

#                 print(
#                     "[WHISPER] Empty transcript."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not understand your "
#                         "answer. Please try again."

#                 }

#             # ------------------------------------------------
#             # VERIFY SESSION
#             # ------------------------------------------------

#             print(
#                 "[ADK] Using session:",
#                 session_id
#             )

#             # ------------------------------------------------
#             # SEND TO GEMINI
#             # ------------------------------------------------

#             model_response = await run_session(

#                 runner,

#                 text,

#                 session_id

#             )

#             # ------------------------------------------------
#             # HANDLE EMPTY MODEL RESPONSE
#             # ------------------------------------------------

#             if not model_response:

#                 print(
#                     "[ADK] No model response."
#                 )

#                 model_response = (
#                     "Thank you for your answer. "
#                     "Let's continue."
#                 )

#             # ------------------------------------------------
#             # SAVE LAST MODEL RESPONSE
#             # ------------------------------------------------

#             LAST_MODEL_RESPONSE = model_response

#             # Store duplicate protection only after a successful model
#             # response; failed model calls can then be retried.
#             LAST_AUDIO_HASH = audio_hash

#             # ------------------------------------------------
#             # READ SESSION ONLY FOR LOGGING
#             #
#             # IMPORTANT:
#             # This does NOT call Gemini again.
#             # ------------------------------------------------

#             session = await session_service.get_session(

#                 app_name=APP_NAME,

#                 user_id=USER_ID,

#                 session_id=session_id

#             )

#             # ------------------------------------------------
#             # SAVE CONVERSATION
#             # ------------------------------------------------

#             save_conversation(
#                 session
#             )

#             # ------------------------------------------------
#             # ROBOT SPEAKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.SPEAKING
#             )

#             print()
#             print("=" * 70)
#             print(
#                 f"[TRANSCRIBE] REQUEST "
#                 f"{request_id} COMPLETE"
#             )
#             print(
#                 "[TRANSCRIBE] Candidate:",
#                 text
#             )
#             print(
#                 "[TRANSCRIBE] AI:",
#                 model_response
#             )
#             print("=" * 70)
#             print()

#             # ------------------------------------------------
#             # RETURN TO FRONTEND
#             # ------------------------------------------------

#             return {

#                 "transcript": text,

#                 "model": model_response

#             }

#         except Exception as e:

#             print()
#             print(
#                 "[TRANSCRIBE] ERROR:",
#                 str(e)
#             )

#             import traceback

#             traceback.print_exc()

#             robot.set_state(
#                 RobotState.LISTENING
#             )

#             return {

#                 "transcript": "",

#                 "model":
#                     "Sorry, I encountered an error. "
#                     "Please try again."

#             }


# # ============================================================
# # GENERATE FINAL REPORT
# # ============================================================

# @app.post("/generate-report")
# async def generate_report():
#     global CURRENT_SESSION_ID

#     print("\n" + "=" * 60)
#     print("[REPORT] GENERATING COMPREHENSIVE INTERVIEW REPORT")
#     print("=" * 60)

#     try:
#         if not CURRENT_SESSION_ID:
#             return {"status": "error", "message": "No active interview session."}

#         session = await session_service.get_session(
#             app_name=APP_NAME, user_id=USER_ID, session_id=CURRENT_SESSION_ID
#         )
#         if not session:
#             return {"status": "error", "message": "Interview session not found."}

#         # Preserve the existing AI interview assessment, then combine it with
#         # the complete saved conversation and the newly processed telemetry.
#         ai_report = generate_interview_report(
#             session_service=session_service,
#             app_name=APP_NAME,
#             user_id=USER_ID,
#             session_id=CURRENT_SESSION_ID,
#             llm_agent=interviewAgent
#         )

#         analytics = _summarize_video_telemetry()
#         try:
#             with open(CONVERSATION_PATH, "r", encoding="utf-8") as f:
#                 conversation = json.load(f)
#             if not isinstance(conversation, list):
#                 conversation = []
#         except (OSError, json.JSONDecodeError):
#             conversation = []

#         report_pdf = _generate_comprehensive_pdf(
#             ai_report=ai_report,
#             analytics=analytics,
#             conversation=conversation,
#             session_id=CURRENT_SESSION_ID
#         )

#         report_data = {
#             "session_id": CURRENT_SESSION_ID,
#             "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
#             "ai_assessment": ai_report,
#             "conversation": conversation,
#             "video_analytics": {k: v for k, v in analytics.items() if k != "timeline"},
#             "behavioral_recommendations": _behavioral_recommendations(analytics),
#             "pdf_report_url": "/download-report"
#         }
#         _write_json_atomic(os.path.join(BASE_DIR, "comprehensive_interview_report.json"), report_data)

#         print(f"[REPORT] Comprehensive PDF created: {report_pdf}")
#         robot.set_state(RobotState.GOODBYE)

#         return {
#             "status": "success",
#             # Keep the existing `report` field for frontend compatibility.
#             "report": ai_report,
#             "comprehensive_report": report_data,
#             "video_analytics": report_data["video_analytics"],
#             "pdf_report_url": "/download-report",
#             "session_id": CURRENT_SESSION_ID
#         }

#     except Exception as e:
#         print("[REPORT] Error:", str(e))
#         import traceback
#         traceback.print_exc()
#         return {"status": "error", "message": str(e)}


# @app.get("/download-report")
# async def download_report():
#     if not os.path.isfile(REPORT_PDF_PATH):
#         return {"status": "error", "message": "Report PDF has not been generated yet."}
#     return FileResponse(
#         REPORT_PDF_PATH,
#         media_type="application/pdf",
#         filename="comprehensive_interview_report.pdf"
#     )


# # ============================================================
# # ROBOT STATE API
# # ============================================================

# @app.get("/robot-state")
# async def robot_state():

#     return {

#         "state":
#             robot.current_state,

#         "connected":
#             robot.connected

#     }


# # ============================================================
# # SET ROBOT STATE
# # ============================================================

# @app.post("/robot/state")
# async def set_robot_state(data: dict):

#     state = data.get("state")

#     valid_states = {

#         RobotState.IDLE,

#         RobotState.LISTENING,

#         RobotState.THINKING,

#         RobotState.SPEAKING,

#         RobotState.GREETING,

#         RobotState.ATTENTION,

#         RobotState.GOODBYE

#     }

#     if state not in valid_states:

#         return {

#             "status": "error",

#             "message":
#                 f"Invalid robot state: {state}"

#         }

#     robot.set_state(state)

#     return {

#         "status": "success" if robot.connected else "warning",

#         "state": robot.current_state,

#         "connected": robot.connected,

#         "message": (
#             "State updated."
#             if robot.connected
#             else "Backend state updated, but ESP32 is not connected."
#         )

#     }


# # ============================================================
# # TEST ROBOT
# # ============================================================

# @app.get("/robot/test")
# async def robot_test():

#     robot.set_state(
#         RobotState.GREETING
#     )

#     return {

#         "status": "success",

#         "message":
#             "Robot test animation started."

#     }


# # ============================================================
# # MANUAL SERVO ANGLE
# # ============================================================

# @app.post("/robot/angle")
# async def robot_angle(data: dict):

#     try:

#         angle = int(
#             data.get(
#                 "angle",
#                 robot.CENTER_ANGLE
#             )
#         )

#         accepted_angle = max(robot.MIN_ANGLE, min(robot.MAX_ANGLE, angle))
#         robot.send_angle(accepted_angle)

#         return {

#             "status": "success" if robot.connected else "warning",

#             "angle": accepted_angle,

#             "connected": robot.connected,

#             "message": (
#                 "Angle command sent."
#                 if robot.connected
#                 else "Angle was validated, but ESP32 is not connected."
#             )

#         }

#     except Exception as e:

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # STOP ROBOT
# # ============================================================

# @app.post("/robot/stop")
# async def robot_stop():

#     robot.stop_animation()
#     robot.stop_servo()

#     # Report IDLE after stopping. set_state() can restart IDLE later
#     # because it checks whether an animation thread is actually alive.
#     robot.current_state = RobotState.IDLE

#     return {

#         "status": "success",

#         "message":
#             "Robot stopped."

#     }


# # ============================================================
# # VIDEO FRAME
# # ============================================================

# @app.post("/video-frame")
# async def video_frame(file: UploadFile = File(...)):
#     global INTERVIEW_STARTED_AT
#     try:
#         data = await file.read()
#         if not data:
#             return {"status": "error", "message": "Empty video frame."}

#         np_arr = np.frombuffer(data, np.uint8)
#         frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
#         if frame is None:
#             return {"status": "error", "message": "Could not decode image."}

#         if INTERVIEW_STARTED_AT is None:
#             # Allow testing the endpoint directly, while the normal app path
#             # resets the clock in /start-interview.
#             with telemetry_lock:
#                 if INTERVIEW_STARTED_AT is None:
#                     INTERVIEW_STARTED_AT = time.time()

#         record = _process_interview_frame(frame)
#         return {
#             "status": "success",
#             "face_detected": record["face_detected"],
#             "gaze": record["gaze"],
#             "speech": record["speech"],
#             "expression": record["expression"],
#             "blink_count": record["current_blink_total"],
#             "timestamp_seconds": record["timestamp_seconds"]
#         }
#     except Exception as e:
#         print("[VIDEO] Frame processing error:", e)
#         return {"status": "error", "message": str(e)}


# # ============================================================
# # ROOT
# # ============================================================

# @app.get("/")
# async def root():

#     return {

#         "status": "online",

#         "application":
#             "Voice Based AI Interviewer",

#         "session":
#             CURRENT_SESSION_ID,

#         "robot_state":
#             robot.current_state,

#         "robot_connected":
#             robot.connected

#     }


# # ============================================================
# # RUN:
# #
# # uvicorn FinalBackend:app --reload
# #
# # ============================================================

















# # ============================================================
# # FINAL BACKEND - VOICE BASED AI INTERVIEWER
# # ============================================================

# from fastapi import FastAPI, UploadFile, File
# from fastapi.responses import FileResponse, StreamingResponse
# from fastapi.middleware.cors import CORSMiddleware

# from contextlib import asynccontextmanager

# import pdfplumber
# import os
# import asyncio
# import uuid
# import json
# import time
# import hashlib
# import threading

# import cv2
# import numpy as np
# import mediapipe as mp

# from google.adk.agents import LlmAgent
# from google.adk.models.google_llm import Gemini
# from google.adk.sessions import InMemorySessionService
# from google.adk.runners import Runner
# from google.genai import types

# from mediapipe.tasks import python
# from mediapipe.tasks.python import vision

# from interview_event_detector1 import analyze_expressions
# from interview_report_generator import generate_interview_report

# import whisper
# import requests  # For WiFi communication with ESP32

# import pyttsx3


# GOOGLE_API_KEY = "AQ.Ab8RN6KsFdoZj_CiRKExRyTTFkNkyTCmjbpMifG_1gq2rPmGRw"
# os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# # ============================================================
# # CONFIGURATION
# # ============================================================

# # ESP32 Serial Configuration (Legacy - for serial communication)
# ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
# ESP32_BAUD = 115200

# # ESP32 WiFi Configuration (New - for wireless communication)
# ESP32_IP = os.getenv("ESP32_IP", "192.168.1.100")  # ESP32's IP address
# ESP32_PORT_HTTP = 80  # HTTP server port on ESP32
# USE_WIFI = os.getenv("USE_WIFI", "true").lower() == "true"  # Set to "true" to use WiFi

# APP_NAME = "InterviewApp"
# USER_ID = "demo_candidate"

# CURRENT_SESSION_ID = None

# # Prevent two /transcribe requests from being processed together.
# transcribe_lock = asyncio.Lock()

# # Duplicate request protection.
# LAST_AUDIO_HASH = None
# LAST_MODEL_RESPONSE = None

# # ============================================================
# # FILE PATHS
# # ============================================================

# BASE_DIR = os.getenv("INTERVIEW_DATA_DIR", os.path.dirname(os.path.abspath(__file__)))

# RESUME_PATH = os.path.join(BASE_DIR, "uploaded_resume.pdf")
# AUDIO_PATH = os.path.join(BASE_DIR, "recording.webm")
# CONVERSATION_PATH = os.path.join(BASE_DIR, "conversation.json")
# EXPRESSIONS_PATH = os.path.join(BASE_DIR, "expressions.log")
# EVENTS_PATH = os.path.join(BASE_DIR, "events.json")
# COMPRESSED_EVENTS_PATH = os.path.join(BASE_DIR, "compressed_events.json")


# # ============================================================
# # ROBOT STATES
# # ============================================================

# class RobotState:

#     IDLE = "IDLE"
#     LISTENING = "LISTENING"
#     THINKING = "THINKING"
#     SPEAKING = "SPEAKING"
#     GREETING = "GREETING"
#     ATTENTION = "ATTENTION"
#     GOODBYE = "GOODBYE"


# # ============================================================
# # ROBOT HEAD CONTROLLER
# # ============================================================

# class RobotHeadController:

#     def __init__(self):

#         self.serial_conn = None
#         self.connected = False

#         self.current_state = RobotState.IDLE

#         self.animation_thread = None
#         self.animation_running = False

#         self.lock = threading.Lock()

#         self.engine = None

#         # Servo configuration

#         # Servo configuration
#         self.MIN_ANGLE = 40
#         self.MAX_ANGLE = 140
#         self.CENTER_ANGLE = 90

#         # Smooth physical movement
#         self.STEP_DELAY = 0.02

#         # Animation control
#         self.animation_thread = None
#         self.animation_running = False
#         self.animation_id = 0

#         self.lock = threading.Lock()

#         # WiFi/HTTP configuration
#         self.use_wifi = USE_WIFI
#         self.esp32_url = f"http://{ESP32_IP}:{ESP32_PORT_HTTP}"


#     # --------------------------------------------------------
#     # CONNECT ESP32
#     # --------------------------------------------------------

#     def connect(self):

#         if self.use_wifi:
#             self.connect_wifi()
#         else:
#             self.connect_serial()

#     def connect_serial(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via Serial on {ESP32_PORT}...")

#             self.serial_conn = serial.Serial(
#                 ESP32_PORT,
#                 ESP32_BAUD,
#                 timeout=1
#             )

#             time.sleep(2)

#             self.connected = True

#             print("[ROBOT] ESP32 connected successfully via Serial.")

#             self.send_angle(self.CENTER_ANGLE)

#         except Exception as e:

#             print(f"[ROBOT] ESP32 Serial connection failed: {e}")

#             self.connected = False
#             self.serial_conn = None

#     def connect_wifi(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via WiFi at {self.esp32_url}...")

#             # Test connection by sending a status request
#             response = requests.get(
#                 f"{self.esp32_url}/status",
#                 timeout=5
#             )

#             if response.status_code == 200:
#                 self.connected = True
#                 print("[ROBOT] ESP32 connected successfully via WiFi.")
#                 print(f"[ROBOT] ESP32 Status: {response.json()}")
#                 self.send_angle(self.CENTER_ANGLE)
#             else:
#                 print(f"[ROBOT] ESP32 WiFi connection failed: HTTP {response.status_code}")
#                 self.connected = False

#         except Exception as e:

#             print(f"[ROBOT] ESP32 WiFi connection failed: {e}")
#             self.connected = False

#     # --------------------------------------------------------
#     # DISCONNECT
#     # --------------------------------------------------------

#     def disconnect(self):

#         self.stop_animation()

#         try:

#             if self.use_wifi:
#                 self.send_command("STOP")
#             elif self.serial_conn and self.serial_conn.is_open:
#                 self.send_command("STOP")
#                 self.serial_conn.close()

#         except Exception as e:

#             print(f"[ROBOT] Disconnect error: {e}")

#         self.connected = False

#         print("[ROBOT] ESP32 disconnected.")

#     # --------------------------------------------------------
#     # SEND COMMAND
#     # --------------------------------------------------------

#     def send_command(self, command):

#         if not self.connected:
#             return

#         try:

#             if self.use_wifi:
#                 self.send_command_wifi(command)
#             else:
#                 self.send_command_serial(command)

#         except Exception as e:

#             print(f"[ROBOT] Command send error: {e}")

#     def send_command_serial(self, command):

#         try:

#             with self.lock:

#                 self.serial_conn.write(
#                     (command + "\n").encode()
#                 )

#                 self.serial_conn.flush()

#         except Exception as e:

#             print(f"[ROBOT] Serial write error: {e}")

#     def send_command_wifi(self, command):

#         try:

#             with self.lock:

#                 response = requests.post(
#                     f"{self.esp32_url}/command",
#                     data=command,
#                     timeout=5
#                 )

#                 if response.status_code == 200:
#                     print(f"[ROBOT] WiFi command sent: {command}")
#                 else:
#                     print(f"[ROBOT] WiFi command failed: HTTP {response.status_code}")

#         except Exception as e:

#             print(f"[ROBOT] WiFi write error: {e}")

#     # --------------------------------------------------------
#     # SEND SERVO ANGLE
#     # --------------------------------------------------------

#     def send_angle(self, angle):

#         angle = max(
#             self.MIN_ANGLE,
#             min(self.MAX_ANGLE, int(angle))
#         )

#         self.send_command(f"ANGLE:{angle}")

#     # --------------------------------------------------------
#     # STOP SERVO
#     # --------------------------------------------------------

#     def stop_servo(self):

#         self.send_command("STOP")

#     # --------------------------------------------------------
#     # ANIMATION
#     # --------------------------------------------------------

    
#     def start_animation(self, state):
#         self.stop_animation()

#         self.animation_running = True
#         generation = self.animation_id

#         self.animation_thread = threading.Thread(
#             target=self.animation_loop,
#             args=(state, generation),
#             daemon=True
#         )
#         self.animation_thread.start()

#     def stop_animation(self):
#         self.animation_running = False

#         # Invalidate every older animation thread.
#         self.animation_id += 1

#         old_thread = self.animation_thread

#         if (
#             old_thread
#             and old_thread.is_alive()
#             and old_thread != threading.current_thread()
#         ):
#             old_thread.join(timeout=0.7)

#         self.animation_thread = None


#     # --------------------------------------------------------
#     # ANIMATION LOOP
#     # --------------------------------------------------------

    
#     def animation_loop(self, state, generation):
#         """
#         State-driven robot head animation.

#         The backend owns the animation.
#         ESP32 receives ANGLE commands only.
#         """

#         def active():
#             return (
#                 self.animation_running
#                 and generation == self.animation_id
#             )

#         def move(angle, pause=0.0):
#             if not active():
#                 return False

#             self.send_angle(angle)

#             if pause > 0:
#                 deadline = time.monotonic() + pause

#                 while active() and time.monotonic() < deadline:
#                     time.sleep(0.05)

#             return active()

#         try:
#             # ------------------------------------------
#             # IDLE: calm, centered, occasional movement
#             # ------------------------------------------
#             if state == RobotState.IDLE:
#                 move(90)
#                 # Do not continuously move while idle.
#                 return

#             # ------------------------------------------
#             # LISTENING: attentive, deliberate head tilt
#             # ------------------------------------------
            
#             elif state == RobotState.LISTENING:
#                 # Tilt once and hold the listening pose.
#                 if not move(76, 0.8):
#                     return

#                 # Stay tilted until another state is requested.
#                 while active():
#                     time.sleep(0.05)


#             # ------------------------------------------
#             # THINKING: look aside, pause, return
#             # ------------------------------------------
#             elif state == RobotState.THINKING:
#                 if not move(108, 1.4):
#                     return

#                 while active():
#                     if not move(102, 1.8):
#                         break
#                     if not move(110, 1.2):
#                         break
#                     if not move(90, 2.5):
#                         break

#             # ------------------------------------------
#             # SPEAKING: restrained conversational gestures
#             # ------------------------------------------
#             elif state == RobotState.SPEAKING:
#                 if not move(90):
#                     return

#                 while active():
#                     if not move(98, 0.45):
#                         break
#                     if not move(90, 1.0):
#                         break
#                     if not move(82, 0.45):
#                         break
#                     if not move(90, 1.5):
#                         break

#             # ------------------------------------------
#             # GREETING: one clear welcoming gesture
#             # ------------------------------------------
#             elif state == RobotState.GREETING:
#                 if not move(72, 0.45):
#                     return
#                 if not move(108, 0.55):
#                     return
#                 if not move(78, 0.45):
#                     return
#                 move(90, 0.8)

#             # ------------------------------------------
#             # ATTENTION: turn toward the candidate
#             # ------------------------------------------
#             elif state == RobotState.ATTENTION:
#                 if not move(110, 0.8):
#                     return
#                 if not move(90, 1.0):
#                     return

#                 while active():
#                     if not move(96, 0.8):
#                         break
#                     if not move(90, 2.5):
#                         break

#             # ------------------------------------------
#             # GOODBYE: deliberate farewell movement
#             # ------------------------------------------
#             elif state == RobotState.GOODBYE:
#                 if not move(72, 0.45):
#                     return
#                 if not move(108, 0.55):
#                     return
#                 if not move(72, 0.45):
#                     return
#                 move(90, 1.0)

#         except Exception as e:
#             print(f"[ROBOT] Animation error: {e}")

#     # --------------------------------------------------------
#     # SET ROBOT STATE
#     # --------------------------------------------------------

#     def set_state(self, new_state):

#         if new_state == self.current_state:
#             return

#         print(
#             f"[ROBOT] STATE: "
#             f"{self.current_state} -> {new_state}"
#         )

#         self.current_state = new_state

#         self.start_animation(new_state)

#     # --------------------------------------------------------
#     # PYTTSX3 SPEAK
#     # --------------------------------------------------------

#     def speak(self, text):

#         """
#         Optional backend TTS.

#         CURRENT PROJECT FLOW:
#         Browser SpeechSynthesis handles the actual voice.

#         Therefore this function is NOT called by the ADK
#         callback.
#         """

#         if not text:
#             return

#         if self.engine is None:

#             try:

#                 self.engine = pyttsx3.init()

#             except Exception as e:

#                 print(
#                     f"[ROBOT] pyttsx3 initialization failed: {e}"
#                 )

#                 return

#         self.set_state(RobotState.SPEAKING)

#         try:

#             self.engine.say(text)
#             self.engine.runAndWait()

#         except Exception as e:

#             print(f"[ROBOT] TTS error: {e}")

#         finally:

#             self.set_state(RobotState.LISTENING)


# # ============================================================
# # CREATE ROBOT
# # ============================================================

# robot = RobotHeadController()


# # ============================================================
# # RESUME TEXT EXTRACTION
# # ============================================================

# def getText() -> str:

#     resume_path = RESUME_PATH

#     if not os.path.exists(resume_path):

#         print(
#             f"[RESUME] Uploaded resume not found: "
#             f"{resume_path}"
#         )

#         resume_path = "sample_resume.pdf"

#     if not os.path.exists(resume_path):

#         print("[RESUME] No resume PDF found.")

#         return ""

#     text = ""

#     try:

#         with pdfplumber.open(resume_path) as pdf:

#             for page in pdf.pages:

#                 page_text = page.extract_text()

#                 if page_text:

#                     text += page_text + "\n"

#         print(
#             f"[RESUME] Extracted "
#             f"{len(text)} characters."
#         )

#         return text

#     except Exception as e:

#         print(
#             f"[RESUME] Error extracting resume: {e}"
#         )

#         return ""


# # ============================================================
# # ADK CALLBACK
# # ============================================================

# def Speak(callback_context):

#     """
#     ADK callback.

#     IMPORTANT:
#     The browser is responsible for actual voice output.

#     Therefore this callback DOES NOT call pyttsx3.
#     """

#     print(
#         "[AGENT] Speak callback triggered - "
#         "browser will handle TTS"
#     )

#     return None


# # ============================================================
# # GEMINI CONFIGURATION
# # ============================================================

# retry_config = types.HttpRetryOptions(

#     attempts=5,

#     exp_base=7,

#     initial_delay=1,

#     http_status_codes=[
#         429,
#         500,
#         503,
#         504
#     ]
# )


# # ============================================================
# # CAMERA AGENT
# # ============================================================

# CameraAgent = LlmAgent(
#     name="CamAgent"
# )


# # ============================================================
# # INTERVIEW AGENT
# # ============================================================

# interviewAgent = LlmAgent(

#     name="InterviewAgent",

#     model=Gemini(
#         model="gemini-3.5-flash-lite",
#         retry_options=retry_config
#     ),

#     description=(
#         "You are an AI professional interviewer "
#         "who interviews candidates based on their resumes."
#     ),

#     instruction="""

# You are a professional interviewer conducting a
# technical recruitment interview.

# IMPORTANT RULES:

# 1. Use the getText() tool to extract the candidate's
#    resume text.

# 2. Study the candidate's resume carefully.

# 3. Ask ONLY ONE question at a time.

# 4. After asking a question, WAIT for the candidate's
#    answer before asking the next question.

# 5. Ask at least 2 questions about the candidate
#    personally, such as:
#    - Introduction
#    - Background
#    - Career goals
#    - Interests

# 6. Ask at least 4 technical questions based specifically
#    on the skills, technologies and projects present in
#    the candidate's resume.

# 7. Do NOT invent technologies or projects that are not
#    present in the resume.

# 8. Questions should progressively evaluate:
#    - Understanding
#    - Practical knowledge
#    - Problem solving
#    - Technical depth

# 9. Keep each interviewer response concise and natural
#    because it will be converted into speech.

# 10. Do not ask multiple questions in one response.

# 11. Do not repeat a question that has already been asked.

# 12. Maintain awareness of the previous conversation.

# 13. After all required questions have been completed,
#     provide an overall summary of the candidate's
#     performance.

# 14. The final summary should include:
#     - Strengths
#     - Technical knowledge
#     - Communication
#     - Problem solving
#     - Areas for improvement
#     - Overall assessment

# 15. Always use the candidate's resume information when
#     discussing their background, skills and projects.

# 16. Never generate a second answer to the same candidate
#     response.

# """,

#     after_agent_callback=Speak,

#     tools=[getText]
# )


# # ============================================================
# # ADK SESSION SERVICE
# # ============================================================

# session_service = InMemorySessionService()


# # ============================================================
# # RUNNER
# # ============================================================

# runner = Runner(

#     agent=interviewAgent,

#     app_name=APP_NAME,

#     session_service=session_service
# )


# # ============================================================
# # RUN ADK SESSION
# # ============================================================

# async def run_session(
#     runner: Runner,
#     query: str,
#     session_id: str
# ):

#     print()
#     print("=" * 60)
#     print("[ADK] NEW MODEL REQUEST")
#     print(f"[ADK] Session ID : {session_id}")
#     print(f"[ADK] User       : {USER_ID}")
#     print(f"[ADK] Query      : {query}")
#     print("=" * 60)

#     if not query or not query.strip():

#         print(
#             "[ADK] Empty user query. "
#             "Skipping model request."
#         )

#         return None

#     query_content = types.Content(

#         role="user",

#         parts=[
#             types.Part(
#                 text=query.strip()
#             )
#         ]

#     )

#     model_text = None

#     try:

#         async for event in runner.run_async(

#             user_id=USER_ID,

#             session_id=session_id,

#             new_message=query_content

#         ):

#             # Only use the final response.

#             if not event.is_final_response():
#                 continue

#             if not event.content:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     model_text = part.text.strip()

#                     print()
#                     print("[ADK] FINAL MODEL RESPONSE:")
#                     print(model_text)
#                     print()

#                     break

#             if model_text:
#                 break

#     except Exception as e:

#         print(
#             f"[ADK] Model execution error: {e}"
#         )

#         raise

#     if not model_text:

#         print(
#             "[ADK] WARNING: "
#             "No final model response received."
#         )

#     return model_text


# # ============================================================
# # SAVE CONVERSATION
# # ============================================================

# def save_conversation(session):

#     conversation_data = []

#     try:

#         if not session:
#             return conversation_data

#         for event in session.events:

#             if not event.content:
#                 continue

#             role = event.content.role

#             if role not in ["user", "model"]:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     conversation_data.append({

#                         "role": role,

#                         "text": part.text.strip()

#                     })

#         os.makedirs(
#             os.path.dirname(CONVERSATION_PATH),
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 conversation_data,
#                 f,
#                 indent=4,
#                 ensure_ascii=False
#             )

#         print(
#             f"[CONVERSATION] Saved "
#             f"{len(conversation_data)} messages."
#         )

#     except Exception as e:

#         print(
#             f"[CONVERSATION] Save error: {e}"
#         )

#     return conversation_data


# # ============================================================
# # FASTAPI LIFESPAN
# # ============================================================

# @asynccontextmanager
# async def lifespan(app: FastAPI):

#     print()
#     print("=" * 60)
#     print("VOICE BASED AI INTERVIEWER BACKEND")
#     print("=" * 60)

#     robot.connect()

#     if robot.connected:

#         robot.current_state = RobotState.IDLE

#         robot.start_animation(
#             RobotState.IDLE
#         )

#     yield

#     print(
#         "[SERVER] Shutting down..."
#     )

#     robot.disconnect()


# # ============================================================
# # FASTAPI APP
# # ============================================================

# app = FastAPI(
#     lifespan=lifespan
# )


# # ============================================================
# # CORS
# # ============================================================

# app.add_middleware(

#     CORSMiddleware,

#     allow_origins=["*"],

#     allow_credentials=True,

#     allow_methods=["*"],

#     allow_headers=["*"]

# )


# # ============================================================
# # UPLOAD RESUME
# # ============================================================

# @app.post("/upload-resume")
# async def upload_resume(
#     file: UploadFile = File(...)
# ):

#     try:

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         data = await file.read()

#         with open(
#             RESUME_PATH,
#             "wb"
#         ) as f:

#             f.write(data)

#         print(
#             f"[RESUME] Uploaded: "
#             f"{len(data)} bytes"
#         )

#         return {

#             "status": "success",

#             "message": "Resume uploaded successfully."

#         }

#     except Exception as e:

#         print(
#             f"[RESUME] Upload error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # START NEW INTERVIEW
# # ============================================================

# @app.post("/start-interview")
# async def start_interview():

#     global CURRENT_SESSION_ID
#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE

#     try:

#         # ----------------------------------------------------
#         # CREATE UNIQUE SESSION
#         # ----------------------------------------------------

#         CURRENT_SESSION_ID = (
#             f"interview_{uuid.uuid4().hex}"
#         )

#         print()
#         print("=" * 60)
#         print("[INTERVIEW] NEW INTERVIEW STARTED")
#         print(
#             f"[INTERVIEW] Session: "
#             f"{CURRENT_SESSION_ID}"
#         )
#         print("=" * 60)

#         # ----------------------------------------------------
#         # RESET DUPLICATE PROTECTION
#         # ----------------------------------------------------

#         LAST_AUDIO_HASH = None
#         LAST_MODEL_RESPONSE = None

#         # ----------------------------------------------------
#         # CREATE ADK SESSION
#         # ----------------------------------------------------

#         await session_service.create_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         # ----------------------------------------------------
#         # CLEAR OLD INTERVIEW DATA
#         # ----------------------------------------------------

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 [],
#                 f
#             )

#         with open(
#             EXPRESSIONS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         with open(
#             EVENTS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         if os.path.exists(
#             COMPRESSED_EVENTS_PATH
#         ):

#             with open(
#                 COMPRESSED_EVENTS_PATH,
#                 "w",
#                 encoding="utf-8"
#             ) as f:

#                 json.dump(
#                     [],
#                     f
#                 )

#         # ----------------------------------------------------
#         # ROBOT LISTENING
#         # ----------------------------------------------------

#         # ----------------------------------------------------
#         # ROBOT STATE
#         # The frontend controls the interview's visual sequence:
#         # GREETING -> SPEAKING -> LISTENING
#         # ----------------------------------------------------

#         # Do not set LISTENING here.
#         # The frontend will send the appropriate state after
#         # the interview-start request has completed.

#         return {

#             "status": "success",

#             "message":
#                 "New interview session started.",

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             f"[INTERVIEW] Start error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # TRANSCRIBE + AI RESPONSE
# # ============================================================

# @app.post("/transcribe")
# async def transcribe(
#     audio: UploadFile = File(...)
# ):

#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE
#     global CURRENT_SESSION_ID

#     # ========================================================
#     # IMPORTANT:
#     # Only one transcription request can run at a time.
#     # ========================================================

#     async with transcribe_lock:

#         request_id = uuid.uuid4().hex[:8]

#         print()
#         print("=" * 70)
#         print(
#             f"[TRANSCRIBE] NEW REQUEST "
#             f"ID={request_id}"
#         )
#         print("=" * 70)

#         try:

#             # ------------------------------------------------
#             # CHECK SESSION
#             # ------------------------------------------------

#             if not CURRENT_SESSION_ID:

#                 print(
#                     "[TRANSCRIBE] ERROR: "
#                     "No active interview session."
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "Please start a new interview first."

#                 }

#             # ------------------------------------------------
#             # ROBOT THINKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.THINKING
#             )

#             # ------------------------------------------------
#             # ANALYZE FACE EXPRESSIONS
#             # ------------------------------------------------

#             try:

#                 analyze_expressions()

#             except Exception as e:

#                 print(
#                     "[VISION] Expression analysis error:",
#                     e
#                 )

#             # ------------------------------------------------
#             # READ AUDIO
#             # ------------------------------------------------

#             audio_data = await audio.read()

#             if not audio_data:

#                 print(
#                     "[TRANSCRIBE] Empty audio."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not hear your answer. "
#                         "Please try again."

#                 }

#             print(
#                 f"[TRANSCRIBE] Audio size: "
#                 f"{len(audio_data)} bytes"
#             )

#             # ------------------------------------------------
#             # CREATE AUDIO HASH
#             # ------------------------------------------------

#             audio_hash = hashlib.sha256(
#                 audio_data
#             ).hexdigest()

#             print(
#                 f"[TRANSCRIBE] Audio hash: "
#                 f"{audio_hash[:16]}..."
#             )

#             # ------------------------------------------------
#             # DUPLICATE AUDIO CHECK
#             # ------------------------------------------------

#             if (
#                 LAST_AUDIO_HASH is not None
#                 and audio_hash == LAST_AUDIO_HASH
#             ):

#                 print()
#                 print(
#                     "[TRANSCRIBE] DUPLICATE AUDIO "
#                     "DETECTED."
#                 )

#                 print(
#                     "[TRANSCRIBE] "
#                     "Gemini will NOT be called again."
#                 )

#                 robot.set_state(
#                     RobotState.SPEAKING
#                 )

#                 return {

#                     "transcript":
#                         "(duplicate request)",

#                     "model":
#                         LAST_MODEL_RESPONSE
#                         or
#                         "Please continue."

#                 }

#             # ------------------------------------------------
#             # SAVE AUDIO
#             # ------------------------------------------------

#             os.makedirs(
#                 BASE_DIR,
#                 exist_ok=True
#             )

#             with open(
#                 AUDIO_PATH,
#                 "wb"
#             ) as f:

#                 f.write(audio_data)

#             print(
#                 f"[TRANSCRIBE] Saved audio: "
#                 f"{AUDIO_PATH}"
#             )

#             # ------------------------------------------------
#             # LOAD WHISPER
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Loading model..."
#             )

#             model = whisper.load_model(
#                 "base"
#             )

#             print(
#                 "[WHISPER] Model loaded."
#             )

#             # ------------------------------------------------
#             # TRANSCRIBE
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Transcribing..."
#             )

#             result = model.transcribe(
#                 AUDIO_PATH
#             )

#             text = (
#                 result
#                 .get("text", "")
#                 .strip()
#             )

#             print()
#             print(
#                 "[WHISPER] TRANSCRIPT:"
#             )
#             print(text)
#             print()

#             # ------------------------------------------------
#             # EMPTY TRANSCRIPT
#             # ------------------------------------------------

#             if not text:

#                 print(
#                     "[WHISPER] Empty transcript."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not understand your "
#                         "answer. Please try again."

#                 }

#             # ------------------------------------------------
#             # STORE HASH ONLY AFTER SUCCESSFUL TRANSCRIPTION
#             # ------------------------------------------------

#             LAST_AUDIO_HASH = audio_hash

#             # ------------------------------------------------
#             # VERIFY SESSION
#             # ------------------------------------------------

#             print(
#                 "[ADK] Using session:",
#                 CURRENT_SESSION_ID
#             )

#             # ------------------------------------------------
#             # SEND TO GEMINI
#             # ------------------------------------------------

#             model_response = await run_session(

#                 runner,

#                 text,

#                 CURRENT_SESSION_ID

#             )

#             # ------------------------------------------------
#             # HANDLE EMPTY MODEL RESPONSE
#             # ------------------------------------------------

#             if not model_response:

#                 print(
#                     "[ADK] No model response."
#                 )

#                 model_response = (
#                     "Thank you for your answer. "
#                     "Let's continue."
#                 )

#             # ------------------------------------------------
#             # SAVE LAST MODEL RESPONSE
#             # ------------------------------------------------

#             LAST_MODEL_RESPONSE = model_response

#             # ------------------------------------------------
#             # READ SESSION ONLY FOR LOGGING
#             #
#             # IMPORTANT:
#             # This does NOT call Gemini again.
#             # ------------------------------------------------

#             session = await session_service.get_session(

#                 app_name=APP_NAME,

#                 user_id=USER_ID,

#                 session_id=CURRENT_SESSION_ID

#             )

#             # ------------------------------------------------
#             # SAVE CONVERSATION
#             # ------------------------------------------------

#             save_conversation(
#                 session
#             )

#             # ------------------------------------------------
#             # ROBOT SPEAKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.SPEAKING
#             )

#             print()
#             print("=" * 70)
#             print(
#                 f"[TRANSCRIBE] REQUEST "
#                 f"{request_id} COMPLETE"
#             )
#             print(
#                 "[TRANSCRIBE] Candidate:",
#                 text
#             )
#             print(
#                 "[TRANSCRIBE] AI:",
#                 model_response
#             )
#             print("=" * 70)
#             print()

#             # ------------------------------------------------
#             # RETURN TO FRONTEND
#             # ------------------------------------------------

#             return {

#                 "transcript": text,

#                 "model": model_response

#             }

#         except Exception as e:

#             print()
#             print(
#                 "[TRANSCRIBE] ERROR:",
#                 str(e)
#             )

#             import traceback

#             traceback.print_exc()

#             robot.set_state(
#                 RobotState.LISTENING
#             )

#             return {

#                 "transcript": "",

#                 "model":
#                     "Sorry, I encountered an error. "
#                     "Please try again."

#             }


# # ============================================================
# # GENERATE FINAL REPORT
# # ============================================================

# @app.post("/generate-report")
# async def generate_report():

#     global CURRENT_SESSION_ID

#     print()
#     print("=" * 60)
#     print("[REPORT] GENERATING FINAL INTERVIEW REPORT")
#     print("=" * 60)

#     try:

#         if not CURRENT_SESSION_ID:

#             return {

#                 "status": "error",

#                 "message":
#                     "No active interview session."

#             }

#         print(
#             "[REPORT] Session:",
#             CURRENT_SESSION_ID
#         )

#         # ----------------------------------------------------
#         # GET CURRENT SESSION
#         # ----------------------------------------------------

#         session = await session_service.get_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         if not session:

#             return {

#                 "status": "error",

#                 "message":
#                     "Interview session not found."

#             }

#         # ----------------------------------------------------
#         # GENERATE REPORT
#         # ----------------------------------------------------

#         report = generate_interview_report(

#             session_service=session_service,

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID,

#             llm_agent=interviewAgent

#         )

#         print(
#             "[REPORT] Report generated successfully."
#         )

#         robot.set_state(
#             RobotState.GOODBYE
#         )

#         return {

#             "status": "success",

#             "report": report,

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             "[REPORT] Error:",
#             str(e)
#         )

#         import traceback

#         traceback.print_exc()

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROBOT STATE API
# # ============================================================

# @app.get("/robot-state")
# async def robot_state():

#     return {

#         "state":
#             robot.current_state,

#         "connected":
#             robot.connected

#     }


# # ============================================================
# # SET ROBOT STATE
# # ============================================================

# @app.post("/robot/state")
# async def set_robot_state(data: dict):

#     state = data.get("state")

#     valid_states = {

#         RobotState.IDLE,

#         RobotState.LISTENING,

#         RobotState.THINKING,

#         RobotState.SPEAKING,

#         RobotState.GREETING,

#         RobotState.ATTENTION,

#         RobotState.GOODBYE

#     }

#     if state not in valid_states:

#         return {

#             "status": "error",

#             "message":
#                 f"Invalid robot state: {state}"

#         }

#     robot.set_state(state)

#     return {

#         "status": "success",

#         "state":
#             robot.current_state

#     }


# # ============================================================
# # TEST ROBOT
# # ============================================================

# @app.get("/robot/test")
# async def robot_test():

#     robot.set_state(
#         RobotState.GREETING
#     )

#     return {

#         "status": "success",

#         "message":
#             "Robot test animation started."

#     }


# # ============================================================
# # MANUAL SERVO ANGLE
# # ============================================================

# @app.post("/robot/angle")
# async def robot_angle(data: dict):

#     try:

#         angle = int(
#             data.get(
#                 "angle",
#                 robot.CENTER_ANGLE
#             )
#         )

#         robot.send_angle(angle)

#         return {

#             "status": "success",

#             "angle": angle

#         }

#     except Exception as e:

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # STOP ROBOT
# # ============================================================

# @app.post("/robot/stop")
# async def robot_stop():

#     robot.stop_animation()

#     robot.stop_servo()

#     robot.current_state = RobotState.IDLE

#     return {

#         "status": "success",

#         "message":
#             "Robot stopped."

#     }


# # ============================================================
# # VIDEO FRAME
# # ============================================================

# @app.post("/video-frame")
# async def video_frame(
#     file: UploadFile = File(...)
# ):

#     try:

#         data = await file.read()

#         if not data:

#             return {

#                 "status": "error",

#                 "message":
#                     "Empty video frame."

#             }

#         np_arr = np.frombuffer(
#             data,
#             np.uint8
#         )

#         frame = cv2.imdecode(
#             np_arr,
#             cv2.IMREAD_COLOR
#         )

#         if frame is None:

#             return {

#                 "status": "error",

#                 "message":
#                     "Could not decode image."

#             }

#         # ----------------------------------------------------
#         # MediaPipe processing can be performed here if needed.
#         # ----------------------------------------------------

#         return {

#             "status": "success"

#         }

#     except Exception as e:

#         print(
#             "[VIDEO] Frame processing error:",
#             e
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROOT
# # ============================================================

# @app.get("/")
# async def root():

#     return {

#         "status": "online",

#         "application":
#             "Voice Based AI Interviewer",

#         "session":
#             CURRENT_SESSION_ID,

#         "robot_state":
#             robot.current_state,

#         "robot_connected":
#             robot.connected

#     }


# # ============================================================
# # RUN:
# #
# # uvicorn FinalBackend:app --reload
# #
# # ============================================================















# # ============================================================
# # FINAL BACKEND - VOICE BASED AI INTERVIEWER
# # ============================================================

# from fastapi import FastAPI, UploadFile, File
# from fastapi.responses import FileResponse, StreamingResponse
# from fastapi.middleware.cors import CORSMiddleware

# from contextlib import asynccontextmanager

# import pdfplumber
# import os
# import asyncio
# import uuid
# import json
# import time
# import hashlib
# import threading

# import cv2
# import numpy as np
# import mediapipe as mp

# from google.adk.agents import LlmAgent
# from google.adk.models.google_llm import Gemini
# from google.adk.sessions import InMemorySessionService
# from google.adk.runners import Runner
# from google.genai import types

# from mediapipe.tasks import python
# from mediapipe.tasks.python import vision

# from interview_event_detector1 import analyze_expressions
# from interview_report_generator import generate_interview_report

# import whisper
# import requests  # For WiFi communication with ESP32

# # Optional legacy serial mode (used only when USE_WIFI=false).
# try:
#     import serial
# except ImportError:
#     serial = None

# import pyttsx3


# GOOGLE_API_KEY = "AQ.Ab8RN6KsFdoZj_CiRKExRyTTFkNkyTCmjbpMifG_1gq2rPmGRw"
# os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

# # ============================================================
# # CONFIGURATION
# # ============================================================

# # ESP32 Serial Configuration (Legacy - for serial communication)
# ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
# ESP32_BAUD = 115200

# # ESP32 WiFi Configuration (New - for wireless communication)
# ESP32_IP = os.getenv("ESP32_IP", "10.61.133.200")  # ESP32's IP address
# ESP32_PORT_HTTP = 80  # HTTP server port on ESP32
# USE_WIFI = os.getenv("USE_WIFI", "true").lower() == "true"  # Set to "true" to use WiFi

# APP_NAME = "InterviewApp"
# USER_ID = "demo_candidate"

# CURRENT_SESSION_ID = None

# # Prevent two /transcribe requests from being processed together.
# transcribe_lock = asyncio.Lock()

# # Duplicate request protection.
# LAST_AUDIO_HASH = None
# LAST_MODEL_RESPONSE = None

# # ============================================================
# # FILE PATHS
# # ============================================================

# BASE_DIR = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders"

# RESUME_PATH = os.path.join(BASE_DIR, "uploaded_resume.pdf")
# AUDIO_PATH = os.path.join(BASE_DIR, "recording.webm")
# CONVERSATION_PATH = os.path.join(BASE_DIR, "conversation.json")
# EXPRESSIONS_PATH = os.path.join(BASE_DIR, "expressions.log")
# EVENTS_PATH = os.path.join(BASE_DIR, "events.json")
# COMPRESSED_EVENTS_PATH = os.path.join(BASE_DIR, "compressed_events.json")


# # ============================================================
# # ROBOT STATES
# # ============================================================

# class RobotState:

#     IDLE = "IDLE"
#     LISTENING = "LISTENING"
#     THINKING = "THINKING"
#     SPEAKING = "SPEAKING"
#     GREETING = "GREETING"
#     ATTENTION = "ATTENTION"
#     GOODBYE = "GOODBYE"


# # ============================================================
# # ROBOT HEAD CONTROLLER
# # ============================================================

# class RobotHeadController:

#     def __init__(self):

#         self.serial_conn = None
#         self.connected = False

#         self.current_state = RobotState.IDLE

#         self.animation_thread = None
#         self.animation_running = False

#         self.lock = threading.Lock()

#         self.engine = None

#         # Servo configuration

#         # Servo configuration
#         self.MIN_ANGLE = 40
#         self.MAX_ANGLE = 140
#         self.CENTER_ANGLE = 90

#         # Smooth physical movement
#         self.STEP_DELAY = 0.02

#         # Animation control
#         self.animation_thread = None
#         self.animation_running = False
#         self.animation_id = 0

#         self.lock = threading.Lock()

#         # WiFi/HTTP configuration
#         self.use_wifi = USE_WIFI
#         self.esp32_url = f"http://{ESP32_IP}:{ESP32_PORT_HTTP}"


#     # --------------------------------------------------------
#     # CONNECT ESP32
#     # --------------------------------------------------------

#     def connect(self):

#         if self.use_wifi:
#             self.connect_wifi()
#         else:
#             self.connect_serial()

#     def connect_serial(self):

#         if serial is None:
#             print("[ROBOT] Serial mode requires pyserial. Install with: python -m pip install pyserial")
#             self.connected = False
#             return

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via Serial on {ESP32_PORT}...")

#             self.serial_conn = serial.Serial(
#                 ESP32_PORT,
#                 ESP32_BAUD,
#                 timeout=1
#             )

#             time.sleep(2)

#             self.connected = True

#             print("[ROBOT] ESP32 connected successfully via Serial.")

#             self.send_angle(self.CENTER_ANGLE)

#         except Exception as e:

#             print(f"[ROBOT] ESP32 Serial connection failed: {e}")

#             self.connected = False
#             self.serial_conn = None

#     def connect_wifi(self):

#         try:

#             print(f"[ROBOT] Connecting to ESP32 via WiFi at {self.esp32_url}...")

#             # Test connection by sending a status request
#             response = requests.get(
#                 f"{self.esp32_url}/status",
#                 timeout=5
#             )

#             if response.status_code == 200:
#                 self.connected = True
#                 print("[ROBOT] ESP32 connected successfully via WiFi.")
#                 print(f"[ROBOT] ESP32 Status: {response.json()}")
#                 self.send_angle(self.CENTER_ANGLE)
#             else:
#                 print(f"[ROBOT] ESP32 WiFi connection failed: HTTP {response.status_code}")
#                 self.connected = False

#         except Exception as e:

#             print(f"[ROBOT] ESP32 WiFi connection failed: {e}")
#             self.connected = False

#     # --------------------------------------------------------
#     # DISCONNECT
#     # --------------------------------------------------------

#     def disconnect(self):

#         self.stop_animation()

#         try:

#             if self.use_wifi:
#                 self.send_command("STOP")
#             elif self.serial_conn and self.serial_conn.is_open:
#                 self.send_command("STOP")
#                 self.serial_conn.close()

#         except Exception as e:

#             print(f"[ROBOT] Disconnect error: {e}")

#         self.connected = False

#         print("[ROBOT] ESP32 disconnected.")

#     # --------------------------------------------------------
#     # SEND COMMAND
#     # --------------------------------------------------------

#     def send_command(self, command):

#         if not self.connected:
#             return

#         try:

#             if self.use_wifi:
#                 self.send_command_wifi(command)
#             else:
#                 self.send_command_serial(command)

#         except Exception as e:

#             print(f"[ROBOT] Command send error: {e}")

#     def send_command_serial(self, command):

#         try:

#             with self.lock:

#                 self.serial_conn.write(
#                     (command + "\n").encode()
#                 )

#                 self.serial_conn.flush()

#         except Exception as e:

#             print(f"[ROBOT] Serial write error: {e}")

#     def send_command_wifi(self, command):

#         try:

#             with self.lock:

#                 response = requests.post(
#                     f"{self.esp32_url}/command",
#                     data=command,
#                     timeout=5
#                 )

#                 if response.status_code == 200:
#                     print(f"[ROBOT] WiFi command sent: {command}")
#                 else:
#                     print(f"[ROBOT] WiFi command failed: HTTP {response.status_code}")

#         except Exception as e:

#             print(f"[ROBOT] WiFi write error: {e}")

#     # # --------------------------------------------------------
#     # # SEND SERVO ANGLE
#     # # --------------------------------------------------------

#     # def send_angle(self, angle):

#     #     angle = max(
#     #         self.MIN_ANGLE,
#     #         min(self.MAX_ANGLE, int(angle))
#     #     )

#     #     self.send_command(f"ANGLE:{angle}")


#         # --------------------------------------------------------
#     # SEND SERVO ANGLE (HEAD)
#     # --------------------------------------------------------

#     def send_angle(self, angle):

#         angle = max(
#             self.MIN_ANGLE,
#             min(self.MAX_ANGLE, int(angle))
#         )

#         self.send_command(f"ANGLE:{angle}")

#     # --------------------------------------------------------
#     # SEND HAND ANGLES (NEW HELPER)
#     # --------------------------------------------------------

#     def send_hand_angles(self, left, right):
#         """
#         Sends independent, clamped target angles to the hand servos.
#         Because the ESP32 internally maps the right hand using (180 - angle),
#         sending identical angles from the backend results in physically 
#         coordinated, mirrored gestures.
#         """
#         left_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(left)))
#         right_clamped = max(self.MIN_ANGLE, min(self.MAX_ANGLE, int(right)))
        
#         self.send_command(f"LEFT:{left_clamped}")
#         self.send_command(f"RIGHT:{right_clamped}")

#     # --------------------------------------------------------
#     # STOP SERVO
#     # --------------------------------------------------------

#     def stop_servo(self):

#         self.send_command("STOP")

#     # --------------------------------------------------------
#     # ANIMATION
#     # --------------------------------------------------------

#     def start_animation(self, state):
#         self.stop_animation()

#         self.animation_running = True
#         generation = self.animation_id

#         self.animation_thread = threading.Thread(
#             target=self.animation_loop,
#             args=(state, generation),
#             daemon=True
#         )
#         self.animation_thread.start()

#     def stop_animation(self):
#         self.animation_running = False

#         # Invalidate every older animation thread.
#         self.animation_id += 1

#         old_thread = self.animation_thread

#         if (
#             old_thread
#             and old_thread.is_alive()
#             and old_thread != threading.current_thread()
#         ):
#             old_thread.join(timeout=0.7)

#         self.animation_thread = None

#     # --------------------------------------------------------
#     # ANIMATION LOOP (UPDATED TO INTEGRATE HAND GESTURES)
#     # --------------------------------------------------------

#     def animation_loop(self, state, generation):
#         """
#         State-driven robot head and hand animation.
#         Coordinated, non-blocking physical gestures.
#         """

#         def active():
#             return (
#                 self.animation_running
#                 and generation == self.animation_id
#             )

#         def move(head_ang, left_ang=90, right_ang=90, pause=0.0):
#             if not active():
#                 return False

#             # Dispatch head and hand instructions safely across Wi-Fi
#             self.send_angle(head_ang)
#             self.send_hand_angles(left_ang, right_ang)

#             if pause > 0:
#                 deadline = time.monotonic() + pause
#                 while active() and time.monotonic() < deadline:
#                     time.sleep(0.05)

#             return active()

#         try:
#             # ------------------------------------------
#             # IDLE / LISTENING / THINKING: Rest positions
#             # ------------------------------------------
#             if state == RobotState.IDLE:
#                 move(90, 90, 90)
#                 return

#             elif state == RobotState.LISTENING:
#                 # Attentive head tilt, hands relaxed at base rest (90)
#                 if not move(76, 90, 90, 0.8):
#                     return
#                 while active():
#                     time.sleep(0.05)

#             elif state == RobotState.THINKING:
#                 # Look aside, keep hands resting to express analytical calm
#                 if not move(108, 90, 90, 1.4):
#                     return
#                 while active():
#                     if not move(102, 90, 90, 1.8): break
#                     if not move(110, 90, 90, 1.2): break
#                     if not move(90, 90, 90, 2.5): break

#             # ------------------------------------------
#             # SPEAKING: Dynamic conversational expressions
#             # ------------------------------------------
#             elif state == RobotState.SPEAKING:
#                 if not move(90, 90, 90):
#                     return

#                 while active():
#                     # Subtle mirrored conversational expansion (opening up)
#                     if not move(98, 75, 75, 0.45): break
#                     if not move(90, 90, 90, 1.0): break
#                     # Alternating asymmetrical emphasis shifts
#                     if not move(82, 105, 80, 0.45): break
#                     if not move(90, 90, 90, 1.5): break

#             # ------------------------------------------
#             # GREETING: Welcome presentation gesture
#             # ------------------------------------------
#             elif state == RobotState.GREETING:
#                 # Graceful sweep opening both hands outward together
#                 if not move(72, 60, 60, 0.45): return
#                 if not move(108, 60, 60, 0.55): return
#                 # Gradually return to center balance positions
#                 if not move(78, 80, 80, 0.45): return
#                 move(90, 90, 90, 0.8)

#             # ------------------------------------------
#             # ATTENTION: Orient towards user
#             # ------------------------------------------
#             elif state == RobotState.ATTENTION:
#                 if not move(110, 90, 90, 0.8): return
#                 if not move(90, 90, 90, 1.0): return

#                 while active():
#                     if not move(96, 90, 90, 0.8): break
#                     if not move(90, 90, 90, 2.5): break

#             # ------------------------------------------
#             # GOODBYE: Closing polite gesture
#             # ------------------------------------------
#             elif state == RobotState.GOODBYE:
#                 # Brief parting hand gesture, then drop smoothly down to rest
#                 if not move(72, 70, 70, 0.45): return
#                 if not move(108, 70, 70, 0.55): return
#                 if not move(72, 90, 90, 0.45): return
#                 move(90, 90, 90, 1.0)

#         except Exception as e:
#             print(f"[ROBOT] Animation error: {e}")

#     # --------------------------------------------------------
#     # SET ROBOT STATE
#     # --------------------------------------------------------

#     def set_state(self, new_state):

#         thread_alive = (
#             self.animation_thread is not None
#             and self.animation_thread.is_alive()
#         )

#         if new_state == self.current_state and thread_alive:
#             return

#         print(
#             f"[ROBOT] STATE: "
#             f"{self.current_state} -> {new_state}"
#         )

#         self.current_state = new_state
#         self.start_animation(new_state)

#     # --------------------------------------------------------
#     # PYTTSX3 SPEAK
#     # --------------------------------------------------------

#     def speak(self, text):

#         """
#         Optional backend TTS.

#         CURRENT PROJECT FLOW:
#         Browser SpeechSynthesis handles the actual voice.

#         Therefore this function is NOT called by the ADK
#         callback.
#         """

#         if not text:
#             return

#         if self.engine is None:

#             try:

#                 self.engine = pyttsx3.init()

#             except Exception as e:

#                 print(
#                     f"[ROBOT] pyttsx3 initialization failed: {e}"
#                 )

#                 return

#         self.set_state(RobotState.SPEAKING)

#         try:

#             self.engine.say(text)
#             self.engine.runAndWait()

#         except Exception as e:

#             print(f"[ROBOT] TTS error: {e}")

#         finally:

#             self.set_state(RobotState.LISTENING)


# # ============================================================
# # CREATE ROBOT
# # ============================================================

# robot = RobotHeadController()


# # ============================================================
# # RESUME TEXT EXTRACTION
# # ============================================================

# def getText() -> str:

#     resume_path = RESUME_PATH

#     if not os.path.exists(resume_path):

#         print(
#             f"[RESUME] Uploaded resume not found: "
#             f"{resume_path}"
#         )

#         resume_path = "sample_resume.pdf"

#     if not os.path.exists(resume_path):

#         print("[RESUME] No resume PDF found.")

#         return ""

#     text = ""

#     try:

#         with pdfplumber.open(resume_path) as pdf:

#             for page in pdf.pages:

#                 page_text = page.extract_text()

#                 if page_text:

#                     text += page_text + "\n"

#         print(
#             f"[RESUME] Extracted "
#             f"{len(text)} characters."
#         )

#         return text

#     except Exception as e:

#         print(
#             f"[RESUME] Error extracting resume: {e}"
#         )

#         return ""


# # ============================================================
# # ADK CALLBACK
# # ============================================================

# def Speak(callback_context):

#     """
#     ADK callback.

#     IMPORTANT:
#     The browser is responsible for actual voice output.

#     Therefore this callback DOES NOT call pyttsx3.
#     """

#     print(
#         "[AGENT] Speak callback triggered - "
#         "browser will handle TTS"
#     )

#     return None


# # ============================================================
# # GEMINI CONFIGURATION
# # ============================================================

# retry_config = types.HttpRetryOptions(

#     attempts=5,

#     exp_base=7,

#     initial_delay=1,

#     http_status_codes=[
#         429,
#         500,
#         503,
#         504
#     ]
# )


# # ============================================================
# # CAMERA AGENT
# # ============================================================

# CameraAgent = LlmAgent(
#     name="CamAgent"
# )


# # ============================================================
# # INTERVIEW AGENT
# # ============================================================

# interviewAgent = LlmAgent(

#     name="InterviewAgent",

#     model=Gemini(
#         model="gemini-3.5-flash-lite",
#         retry_options=retry_config
#     ),

#     description=(
#         "You are an AI professional interviewer "
#         "who interviews candidates based on their resumes."
#     ),

#     instruction="""

# You are a professional interviewer conducting a
# technical recruitment interview.

# IMPORTANT RULES:

# 1. Use the getText() tool to extract the candidate's
#    resume text.

# 2. Study the candidate's resume carefully.

# 3. Ask ONLY ONE question at a time.

# 4. After asking a question, WAIT for the candidate's
#    answer before asking the next question.

# 5. Ask at least 2 questions about the candidate
#    personally, such as:
#    - Introduction
#    - Background
#    - Career goals
#    - Interests

# 6. Ask at least 4 technical questions based specifically
#    on the skills, technologies and projects present in
#    the candidate's resume.

# 7. Do NOT invent technologies or projects that are not
#    present in the resume.

# 8. Questions should progressively evaluate:
#    - Understanding
#    - Practical knowledge
#    - Problem solving
#    - Technical depth

# 9. Keep each interviewer response concise and natural
#    because it will be converted into speech.

# 10. Do not ask multiple questions in one response.

# 11. Do not repeat a question that has already been asked.

# 12. Maintain awareness of the previous conversation.

# 13. After all required questions have been completed,
#     provide an overall summary of the candidate's
#     performance.

# 14. The final summary should include:
#     - Strengths
#     - Technical knowledge
#     - Communication
#     - Problem solving
#     - Areas for improvement
#     - Overall assessment

# 15. Always use the candidate's resume information when
#     discussing their background, skills and projects.

# 16. Never generate a second answer to the same candidate
#     response.

# """,

#     after_agent_callback=Speak,

#     tools=[getText]
# )


# # ============================================================
# # ADK SESSION SERVICE
# # ============================================================

# session_service = InMemorySessionService()


# # ============================================================
# # RUNNER
# # ============================================================

# runner = Runner(

#     agent=interviewAgent,

#     app_name=APP_NAME,

#     session_service=session_service
# )


# # ============================================================
# # RUN ADK SESSION
# # ============================================================

# async def run_session(
#     runner: Runner,
#     query: str,
#     session_id: str
# ):

#     print()
#     print("=" * 60)
#     print("[ADK] NEW MODEL REQUEST")
#     print(f"[ADK] Session ID : {session_id}")
#     print(f"[ADK] User       : {USER_ID}")
#     print(f"[ADK] Query      : {query}")
#     print("=" * 60)

#     if not query or not query.strip():

#         print(
#             "[ADK] Empty user query. "
#             "Skipping model request."
#         )

#         return None

#     query_content = types.Content(

#         role="user",

#         parts=[
#             types.Part(
#                 text=query.strip()
#             )
#         ]

#     )

#     model_text = None

#     try:

#         async for event in runner.run_async(

#             user_id=USER_ID,

#             session_id=session_id,

#             new_message=query_content

#         ):

#             # Only use the final response.

#             if not event.is_final_response():
#                 continue

#             if not event.content:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     model_text = part.text.strip()

#                     print()
#                     print("[ADK] FINAL MODEL RESPONSE:")
#                     print(model_text)
#                     print()

#                     break

#             if model_text:
#                 break

#     except Exception as e:

#         print(
#             f"[ADK] Model execution error: {e}"
#         )

#         raise

#     if not model_text:

#         print(
#             "[ADK] WARNING: "
#             "No final model response received."
#         )

#     return model_text


# # ============================================================
# # SAVE CONVERSATION
# # ============================================================

# def save_conversation(session):

#     conversation_data = []

#     try:

#         if not session:
#             return conversation_data

#         for event in session.events:

#             if not event.content:
#                 continue

#             role = event.content.role

#             if role not in ["user", "model"]:
#                 continue

#             if not event.content.parts:
#                 continue

#             for part in event.content.parts:

#                 if (
#                     hasattr(part, "text")
#                     and part.text
#                     and part.text.strip()
#                 ):

#                     conversation_data.append({

#                         "role": role,

#                         "text": part.text.strip()

#                     })

#         os.makedirs(
#             os.path.dirname(CONVERSATION_PATH),
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 conversation_data,
#                 f,
#                 indent=4,
#                 ensure_ascii=False
#             )

#         print(
#             f"[CONVERSATION] Saved "
#             f"{len(conversation_data)} messages."
#         )

#     except Exception as e:

#         print(
#             f"[CONVERSATION] Save error: {e}"
#         )

#     return conversation_data


# # ============================================================
# # FASTAPI LIFESPAN
# # ============================================================

# @asynccontextmanager
# async def lifespan(app: FastAPI):

#     print()
#     print("=" * 60)
#     print("VOICE BASED AI INTERVIEWER BACKEND")
#     print("=" * 60)

#     robot.connect()

#     if robot.connected:

#         robot.current_state = RobotState.IDLE

#         robot.start_animation(
#             RobotState.IDLE
#         )

#     yield

#     print(
#         "[SERVER] Shutting down..."
#     )

#     robot.disconnect()


# # ============================================================
# # FASTAPI APP
# # ============================================================

# app = FastAPI(
#     lifespan=lifespan
# )


# # ============================================================
# # CORS
# # ============================================================

# app.add_middleware(

#     CORSMiddleware,

#     allow_origins=["*"],

#     allow_credentials=True,

#     allow_methods=["*"],

#     allow_headers=["*"]

# )


# # ============================================================
# # UPLOAD RESUME
# # ============================================================

# @app.post("/upload-resume")
# async def upload_resume(
#     file: UploadFile = File(...)
# ):

#     try:

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         data = await file.read()

#         with open(
#             RESUME_PATH,
#             "wb"
#         ) as f:

#             f.write(data)

#         print(
#             f"[RESUME] Uploaded: "
#             f"{len(data)} bytes"
#         )

#         return {

#             "status": "success",

#             "message": "Resume uploaded successfully."

#         }

#     except Exception as e:

#         print(
#             f"[RESUME] Upload error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # START NEW INTERVIEW
# # ============================================================

# @app.post("/start-interview")
# async def start_interview():

#     global CURRENT_SESSION_ID
#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE

#     try:

#         # ----------------------------------------------------
#         # CREATE UNIQUE SESSION
#         # ----------------------------------------------------

#         CURRENT_SESSION_ID = (
#             f"interview_{uuid.uuid4().hex}"
#         )

#         print()
#         print("=" * 60)
#         print("[INTERVIEW] NEW INTERVIEW STARTED")
#         print(
#             f"[INTERVIEW] Session: "
#             f"{CURRENT_SESSION_ID}"
#         )
#         print("=" * 60)

#         # ----------------------------------------------------
#         # RESET DUPLICATE PROTECTION
#         # ----------------------------------------------------

#         LAST_AUDIO_HASH = None
#         LAST_MODEL_RESPONSE = None

#         # ----------------------------------------------------
#         # CREATE ADK SESSION
#         # ----------------------------------------------------

#         await session_service.create_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         # ----------------------------------------------------
#         # CLEAR OLD INTERVIEW DATA
#         # ----------------------------------------------------

#         os.makedirs(
#             BASE_DIR,
#             exist_ok=True
#         )

#         with open(
#             CONVERSATION_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             json.dump(
#                 [],
#                 f
#             )

#         with open(
#             EXPRESSIONS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         with open(
#             EVENTS_PATH,
#             "w",
#             encoding="utf-8"
#         ) as f:

#             f.truncate(0)

#         if os.path.exists(
#             COMPRESSED_EVENTS_PATH
#         ):

#             with open(
#                 COMPRESSED_EVENTS_PATH,
#                 "w",
#                 encoding="utf-8"
#             ) as f:

#                 json.dump(
#                     [],
#                     f
#                 )

#         # ----------------------------------------------------
#         # ROBOT GREETING
#         # ----------------------------------------------------
#         # Frontend face sequence: GREETING -> SPEAKING while browser
#         # TTS speaks -> LISTENING after the greeting finishes.
#         robot.set_state(RobotState.GREETING)

#         return {

#             "status": "success",

#             "message":
#                 "New interview session started.",

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             f"[INTERVIEW] Start error: {e}"
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # TRANSCRIBE + AI RESPONSE
# # ============================================================

# @app.post("/transcribe")
# async def transcribe(
#     audio: UploadFile = File(...)
# ):

#     global LAST_AUDIO_HASH
#     global LAST_MODEL_RESPONSE
#     global CURRENT_SESSION_ID

#     # ========================================================
#     # IMPORTANT:
#     # Only one transcription request can run at a time.
#     # ========================================================

#     async with transcribe_lock:

#         request_id = uuid.uuid4().hex[:8]

#         print()
#         print("=" * 70)
#         print(
#             f"[TRANSCRIBE] NEW REQUEST "
#             f"ID={request_id}"
#         )
#         print("=" * 70)

#         try:

#             # ------------------------------------------------
#             # CHECK SESSION
#             # ------------------------------------------------

#             if not CURRENT_SESSION_ID:

#                 print(
#                     "[TRANSCRIBE] ERROR: "
#                     "No active interview session."
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "Please start a new interview first."

#                 }

#             # Keep this request tied to its original session if a new
#             # interview is started while audio/model processing is active.
#             session_id = CURRENT_SESSION_ID

#             # ------------------------------------------------
#             # ROBOT THINKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.THINKING
#             )

#             # ------------------------------------------------
#             # ANALYZE FACE EXPRESSIONS
#             # ------------------------------------------------

#             try:

#                 analyze_expressions()

#             except Exception as e:

#                 print(
#                     "[VISION] Expression analysis error:",
#                     e
#                 )

#             # ------------------------------------------------
#             # READ AUDIO
#             # ------------------------------------------------

#             audio_data = await audio.read()

#             if not audio_data:

#                 print(
#                     "[TRANSCRIBE] Empty audio."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not hear your answer. "
#                         "Please try again."

#                 }

#             print(
#                 f"[TRANSCRIBE] Audio size: "
#                 f"{len(audio_data)} bytes"
#             )

#             # ------------------------------------------------
#             # CREATE AUDIO HASH
#             # ------------------------------------------------

#             audio_hash = hashlib.sha256(
#                 audio_data
#             ).hexdigest()

#             print(
#                 f"[TRANSCRIBE] Audio hash: "
#                 f"{audio_hash[:16]}..."
#             )

#             # ------------------------------------------------
#             # DUPLICATE AUDIO CHECK
#             # ------------------------------------------------

#             if (
#                 LAST_AUDIO_HASH is not None
#                 and audio_hash == LAST_AUDIO_HASH
#             ):

#                 print()
#                 print(
#                     "[TRANSCRIBE] DUPLICATE AUDIO "
#                     "DETECTED."
#                 )

#                 print(
#                     "[TRANSCRIBE] "
#                     "Gemini will NOT be called again."
#                 )

#                 robot.set_state(
#                     RobotState.SPEAKING
#                 )

#                 return {

#                     "transcript":
#                         "(duplicate request)",

#                     "model":
#                         LAST_MODEL_RESPONSE
#                         or
#                         "Please continue."

#                 }

#             # ------------------------------------------------
#             # SAVE AUDIO
#             # ------------------------------------------------

#             os.makedirs(
#                 BASE_DIR,
#                 exist_ok=True
#             )

#             with open(
#                 AUDIO_PATH,
#                 "wb"
#             ) as f:

#                 f.write(audio_data)

#             print(
#                 f"[TRANSCRIBE] Saved audio: "
#                 f"{AUDIO_PATH}"
#             )

#             # ------------------------------------------------
#             # LOAD WHISPER
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Loading model..."
#             )

#             model = whisper.load_model(
#                 "base"
#             )

#             print(
#                 "[WHISPER] Model loaded."
#             )

#             # ------------------------------------------------
#             # TRANSCRIBE
#             # ------------------------------------------------

#             print(
#                 "[WHISPER] Transcribing..."
#             )

#             result = model.transcribe(
#                 AUDIO_PATH
#             )

#             text = (
#                 result
#                 .get("text", "")
#                 .strip()
#             )

#             print()
#             print(
#                 "[WHISPER] TRANSCRIPT:"
#             )
#             print(text)
#             print()

#             # ------------------------------------------------
#             # EMPTY TRANSCRIPT
#             # ------------------------------------------------

#             if not text:

#                 print(
#                     "[WHISPER] Empty transcript."
#                 )

#                 robot.set_state(
#                     RobotState.LISTENING
#                 )

#                 return {

#                     "transcript": "",

#                     "model":
#                         "I could not understand your "
#                         "answer. Please try again."

#                 }

#             # ------------------------------------------------
#             # VERIFY SESSION
#             # ------------------------------------------------

#             print(
#                 "[ADK] Using session:",
#                 session_id
#             )

#             # ------------------------------------------------
#             # SEND TO GEMINI
#             # ------------------------------------------------

#             model_response = await run_session(

#                 runner,

#                 text,

#                 session_id

#             )

#             # ------------------------------------------------
#             # HANDLE EMPTY MODEL RESPONSE
#             # ------------------------------------------------

#             if not model_response:

#                 print(
#                     "[ADK] No model response."
#                 )

#                 model_response = (
#                     "Thank you for your answer. "
#                     "Let's continue."
#                 )

#             # ------------------------------------------------
#             # SAVE LAST MODEL RESPONSE
#             # ------------------------------------------------

#             LAST_MODEL_RESPONSE = model_response

#             # Store duplicate protection only after a successful model
#             # response; failed model calls can then be retried.
#             LAST_AUDIO_HASH = audio_hash

#             # ------------------------------------------------
#             # READ SESSION ONLY FOR LOGGING
#             #
#             # IMPORTANT:
#             # This does NOT call Gemini again.
#             # ------------------------------------------------

#             session = await session_service.get_session(

#                 app_name=APP_NAME,

#                 user_id=USER_ID,

#                 session_id=session_id

#             )

#             # ------------------------------------------------
#             # SAVE CONVERSATION
#             # ------------------------------------------------

#             save_conversation(
#                 session
#             )

#             # ------------------------------------------------
#             # ROBOT SPEAKING
#             # ------------------------------------------------

#             robot.set_state(
#                 RobotState.SPEAKING
#             )

#             print()
#             print("=" * 70)
#             print(
#                 f"[TRANSCRIBE] REQUEST "
#                 f"{request_id} COMPLETE"
#             )
#             print(
#                 "[TRANSCRIBE] Candidate:",
#                 text
#             )
#             print(
#                 "[TRANSCRIBE] AI:",
#                 model_response
#             )
#             print("=" * 70)
#             print()

#             # ------------------------------------------------
#             # RETURN TO FRONTEND
#             # ------------------------------------------------

#             return {

#                 "transcript": text,

#                 "model": model_response

#             }

#         except Exception as e:

#             print()
#             print(
#                 "[TRANSCRIBE] ERROR:",
#                 str(e)
#             )

#             import traceback

#             traceback.print_exc()

#             robot.set_state(
#                 RobotState.LISTENING
#             )

#             return {

#                 "transcript": "",

#                 "model":
#                     "Sorry, I encountered an error. "
#                     "Please try again."

#             }


# # ============================================================
# # GENERATE FINAL REPORT
# # ============================================================

# @app.post("/generate-report")
# async def generate_report():

#     global CURRENT_SESSION_ID

#     print()
#     print("=" * 60)
#     print("[REPORT] GENERATING FINAL INTERVIEW REPORT")
#     print("=" * 60)

#     try:

#         if not CURRENT_SESSION_ID:

#             return {

#                 "status": "error",

#                 "message":
#                     "No active interview session."

#             }

#         print(
#             "[REPORT] Session:",
#             CURRENT_SESSION_ID
#         )

#         # ----------------------------------------------------
#         # GET CURRENT SESSION
#         # ----------------------------------------------------

#         session = await session_service.get_session(

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID

#         )

#         if not session:

#             return {

#                 "status": "error",

#                 "message":
#                     "Interview session not found."

#             }

#         # ----------------------------------------------------
#         # GENERATE REPORT
#         # ----------------------------------------------------

#         report = generate_interview_report(

#             session_service=session_service,

#             app_name=APP_NAME,

#             user_id=USER_ID,

#             session_id=CURRENT_SESSION_ID,

#             llm_agent=interviewAgent

#         )

#         print(
#             "[REPORT] Report generated successfully."
#         )

#         robot.set_state(
#             RobotState.GOODBYE
#         )

#         return {

#             "status": "success",

#             "report": report,

#             "session_id":
#                 CURRENT_SESSION_ID

#         }

#     except Exception as e:

#         print(
#             "[REPORT] Error:",
#             str(e)
#         )

#         import traceback

#         traceback.print_exc()

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROBOT STATE API
# # ============================================================

# @app.get("/robot-state")
# async def robot_state():

#     return {

#         "state":
#             robot.current_state,

#         "connected":
#             robot.connected

#     }


# # ============================================================
# # SET ROBOT STATE
# # ============================================================

# @app.post("/robot/state")
# async def set_robot_state(data: dict):

#     state = data.get("state")

#     valid_states = {

#         RobotState.IDLE,

#         RobotState.LISTENING,

#         RobotState.THINKING,

#         RobotState.SPEAKING,

#         RobotState.GREETING,

#         RobotState.ATTENTION,

#         RobotState.GOODBYE

#     }

#     if state not in valid_states:

#         return {

#             "status": "error",

#             "message":
#                 f"Invalid robot state: {state}"

#         }

#     robot.set_state(state)

#     return {

#         "status": "success" if robot.connected else "warning",

#         "state": robot.current_state,

#         "connected": robot.connected,

#         "message": (
#             "State updated."
#             if robot.connected
#             else "Backend state updated, but ESP32 is not connected."
#         )

#     }


# # ============================================================
# # TEST ROBOT
# # ============================================================

# @app.get("/robot/test")
# async def robot_test():

#     robot.set_state(
#         RobotState.GREETING
#     )

#     return {

#         "status": "success",

#         "message":
#             "Robot test animation started."

#     }


# # ============================================================
# # MANUAL SERVO ANGLE
# # ============================================================

# @app.post("/robot/angle")
# async def robot_angle(data: dict):

#     try:

#         angle = int(
#             data.get(
#                 "angle",
#                 robot.CENTER_ANGLE
#             )
#         )

#         accepted_angle = max(robot.MIN_ANGLE, min(robot.MAX_ANGLE, angle))
#         robot.send_angle(accepted_angle)

#         return {

#             "status": "success" if robot.connected else "warning",

#             "angle": accepted_angle,

#             "connected": robot.connected,

#             "message": (
#                 "Angle command sent."
#                 if robot.connected
#                 else "Angle was validated, but ESP32 is not connected."
#             )

#         }

#     except Exception as e:

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # STOP ROBOT
# # ============================================================

# @app.post("/robot/stop")
# async def robot_stop():

#     robot.stop_animation()
#     robot.stop_servo()

#     # Report IDLE after stopping. set_state() can restart IDLE later
#     # because it checks whether an animation thread is actually alive.
#     robot.current_state = RobotState.IDLE

#     return {

#         "status": "success",

#         "message":
#             "Robot stopped."

#     }


# # ============================================================
# # VIDEO FRAME
# # ============================================================

# @app.post("/video-frame")
# async def video_frame(
#     file: UploadFile = File(...)
# ):

#     try:

#         data = await file.read()

#         if not data:

#             return {

#                 "status": "error",

#                 "message":
#                     "Empty video frame."

#             }

#         np_arr = np.frombuffer(
#             data,
#             np.uint8
#         )

#         frame = cv2.imdecode(
#             np_arr,
#             cv2.IMREAD_COLOR
#         )

#         if frame is None:

#             return {

#                 "status": "error",

#                 "message":
#                     "Could not decode image."

#             }

#         # ----------------------------------------------------
#         # MediaPipe processing can be performed here if needed.
#         # ----------------------------------------------------

#         return {

#             "status": "success"

#         }

#     except Exception as e:

#         print(
#             "[VIDEO] Frame processing error:",
#             e
#         )

#         return {

#             "status": "error",

#             "message": str(e)

#         }


# # ============================================================
# # ROOT
# # ============================================================

# @app.get("/")
# async def root():

#     return {

#         "status": "online",

#         "application":
#             "Voice Based AI Interviewer",

#         "session":
#             CURRENT_SESSION_ID,

#         "robot_state":
#             robot.current_state,

#         "robot_connected":
#             robot.connected

#     }


# # ============================================================
# # RUN:
# #
# # uvicorn FinalBackend:app --reload
# #
# # ============================================================

