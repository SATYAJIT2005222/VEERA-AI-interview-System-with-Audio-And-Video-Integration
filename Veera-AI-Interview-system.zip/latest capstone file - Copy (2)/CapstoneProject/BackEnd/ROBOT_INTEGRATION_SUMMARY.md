# Robot Head Controller Integration - Summary

## OVERVIEW

This integration adds robot head movement control to your Voice-Based AI Interviewer Robot. The robot's head (MG996R servo) now moves naturally in response to the interview state, making the AI interviewer feel more like a physical embodiment.

## WHAT WAS ADDED

### 1. Updated FinalBackend.py
**Location:** `BackEnd/FinalBackend.py`

**New Sections:**
- Robot configuration section at the top
- `RobotState` class with state constants
- `RobotHeadController` class for servo control
- FastAPI lifespan management for robot startup/shutdown
- Robot control endpoints for testing
- Integration with existing interview flow

**Key Features:**
- Thread-safe robot control (doesn't block FastAPI)
- Graceful error handling (works without ESP32)
- Smooth servo movement with configurable speed
- State-based animations (IDLE, LISTENING, THINKING, SPEAKING, etc.)
- TTS synchronization (robot SPEAKING state during speech)
- Manual test endpoints for debugging

**Integration Points:**
- `/start-interview` → GREETING → IDLE
- `/transcribe` → LISTENING → THINKING → SPEAKING → LISTENING
- `Speak()` callback → SPEAKING during TTS → LISTENING after
- `/generate-report` → THINKING → IDLE

### 2. ESP32 Arduino Code
**Location:** `BackEnd/esp32_robot_controller.ino`

**Features:**
- Serial command reception at 115200 baud
- MG996R servo control using ESP32Servo library
- Smooth movement with configurable step delay
- Safe angle limits (MIN_ANGLE, MAX_ANGLE)
- State-based animations matching Python
- STOP command for emergency stop
- Debug messages via Serial Monitor

**Commands Supported:**
- `ANGLE:90` - Set servo to specific angle
- `STATE:IDLE` - Run idle animation
- `STATE:LISTENING` - Run listening animation
- `STATE:THINKING` - Run thinking animation
- `STATE:SPEAKING` - Run speaking animation
- `STATE:GREETING` - Run greeting animation
- `STATE:GOODBYE` - Run goodbye animation
- `STOP` - Stop all movement

### 3. Documentation Files
- `ROBOT_WIRING.md` - Complete wiring diagram and safety notes
- `INSTALLATION.md` - Step-by-step setup instructions
- `TESTING.md` - Comprehensive testing procedure
- `ROBOT_INTEGRATION_SUMMARY.md` - This file

## ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────┐
│                     FastAPI Backend                          │
│                   FinalBackend.py                            │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │           RobotHeadController                        │  │
│  │  - Serial communication with ESP32                   │  │
│  │  - State management                                  │  │
│  │  - Animation control (thread-safe)                   │  │
│  │  - TTS synchronization                               │  │
│  └──────────────────┬───────────────────────────────────┘  │
│                     │ Serial (USB)                          │
└─────────────────────┼───────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│                    ESP32 DEVKIT V1                          │
│                esp32_robot_controller.ino                    │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │           Servo Control (PWM)                         │  │
│  │  - Command parsing                                    │  │
│  │  - Smooth movement                                    │  │
│  │  - Safety limits                                      │  │
│  │  - State animations                                   │  │
│  └──────────────────┬───────────────────────────────────┘  │
│                     │ PWM Signal                            │
└─────────────────────┼───────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│                     MG996R Servo                             │
│                                                               │
│  External 5-6V Power Supply ←──┐                             │
│                                 │                             │
│  Signal from ESP32 GPIO       │                             │
│  Common GND with ESP32 ───────┘                             │
└───────────────────────────────────────────────────────────────┘
```

## ROBOT BEHAVIOR

### State Machine

```
STARTUP
   ↓
IDLE (centered, subtle movement)
   ↓
START INTERVIEW
   ↓
GREETING (welcoming animation)
   ↓
IDLE
   ↓
AI ASKS QUESTION
   ↓
SPEAKING (conversational movement)
   ↓
AI FINISHES SPEAKING
   ↓
LISTENING (subtle nod)
   ↓
CANDIDATE ANSWERS
   ↓
LISTENING (listening animation)
   ↓
CANDIDATE FINISHES
   ↓
THINKING (slight turn)
   ↓
AI PROCESSES
   ↓
SPEAKING (conversational movement)
   ↓
[Repeat for each question]
   ↓
INTERVIEW COMPLETE
   ↓
GOODBYE (farewell animation)
   ↓
IDLE
```

### Animation Details

| State | Movement Pattern | Duration | Purpose |
|-------|-----------------|----------|---------|
| IDLE | 88° → 90° → 92° → 90° (repeating) | Continuous | Waiting state |
| LISTENING | 90° → 85° → 90° | ~1.5s | Show attention |
| THINKING | 90° → 100° → 90° | ~1.8s | Processing state |
| SPEAKING | 90° → 95° → 90° → 85° → 90° | ~2s | Conversational |
| GREETING | 90° → 80° → 100° → 90° | ~1.4s | Welcome gesture |
| GOODBYE | 90° → 100° → 80° → 90° | ~1.4s | Farewell gesture |
| ATTENTION | Move to 90° | ~0.3s | Focus on candidate |

## CONFIGURATION

### Python (FinalBackend.py)
```python
ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
ESP32_BAUDRATE = 115200

SERVO_CENTER = 90
SERVO_MIN = 40
SERVO_MAX = 140

SERVO_STEP_DELAY = 0.02
```

### ESP32 (Arduino)
```cpp
const int SERVO_PIN = 18;
const int MIN_ANGLE = 40;
const int MAX_ANGLE = 140;
const int CENTER_ANGLE = 90;
const int STEP_DELAY = 20;
const int BAUD_RATE = 115200;
```

## NEW API ENDPOINTS

### GET /robot-state
Get current robot status
```json
{
  "connected": true,
  "state": "LISTENING",
  "angle": 90,
  "port": "COM11"
}
```

### POST /robot/test
Manually set robot state (for testing)
```json
{
  "state": "SPEAKING"
}
```

### POST /robot/angle
Manually set servo angle (for testing)
```json
{
  "angle": 90
}
```

### POST /robot/stop
Stop all robot movement

## INTEGRATION WITH EXISTING CODE

### Speak() Function
**Before:**
```python
def Speak(callback_context):
    session=callback_context._invocation_context.session
    engine=pyttsx3.init()
    texts=None
    for event in session.events:
        if event.content and event.content.parts and event.content.parts[0].text and event.content.role and event.content.role=="model":
            texts = event.content.parts[0].text[:] 
            print("Agent Says: ", texts)
```

**After:**
```python
def Speak(callback_context):
    session=callback_context._invocation_context.session
    text=None
    for event in session.events:
        if event.content and event.content.parts and event.content.parts[0].text and event.content.role and event.content.role=="model":
            text = event.content.parts[0].text[:] 
            print("Agent Says: ", text)
            break
    
    if text:
        robot.speak(text)  # Handles TTS and robot state
```

**Robot.speak() method:**
```python
def speak(self, text):
    self.set_state(RobotState.SPEAKING)
    try:
        self.engine.say(text)
        self.engine.runAndWait()
    finally:
        self.set_state(RobotState.LISTENING)
```

### Transcribe Endpoint
**Added robot state management:**
```python
@app.post("/transcribe")
async def transcribe(audio: UploadFile=File(...)):
    robot.set_state(RobotState.LISTENING)  # Candidate speaking
    
    # ... transcription ...
    
    robot.set_state(RobotState.THINKING)  # AI processing
    
    await run_session(runner, text, "default")
    
    # Note: SPEAKING state set by Speak() callback
    # Note: LISTENING state set after TTS completes
```

### Start Interview Endpoint
**Added greeting animation:**
```python
@app.post("/start-interview")
async def start_interview():
    # ... clear data files ...
    
    robot.set_state(RobotState.GREETING)
    time.sleep(2)
    robot.set_state(RobotState.IDLE)
    
    return {"status": "success", "message": "New interview session started"}
```

## PRESERVED FUNCTIONALITY

All existing features remain unchanged:
- ✅ PDF resume extraction
- ✅ Gemini/Google ADK integration
- ✅ InterviewAgent
- ✅ Session management
- ✅ Whisper transcription
- ✅ conversation.json
- ✅ MediaPipe face analysis
- ✅ expressions.log
- ✅ events.json
- ✅ All existing endpoints:
  - `/upload-resume`
  - `/start-interview`
  - `/transcribe`
  - `/generate-report`
  - `/video-frame`

## ERROR HANDLING

### ESP32 Disconnection
If ESP32 is not connected:
- Backend logs: "[ROBOT] Failed to connect to ESP32"
- Backend logs: "[ROBOT] Interview will continue without robot movement"
- Interview functionality continues normally
- No crash or error in API responses

### Serial Communication Errors
If serial communication fails:
- Robot commands fail gracefully
- Backend continues operating
- Error logged but not raised to API

### Servo Movement Errors
If servo cannot move:
- State may change but no physical movement
- Backend continues operating
- Error logged

## THREAD SAFETY

The robot controller uses:
- `threading.Lock()` for serial communication
- Background threads for animations
- `stop_event` for safe animation interruption
- Non-blocking FastAPI endpoints

This ensures:
- FastAPI server remains responsive
- Animations don't block API requests
- Only one animation runs at a time
- Animations can be safely interrupted

## TESTING APPROACH

1. **Unit Testing:** Manual angle control
2. **State Testing:** Each animation individually
3. **Integration Testing:** Full interview flow
4. **Error Testing:** ESP32 disconnection scenarios
5. **Performance Testing:** Extended operation

See `TESTING.md` for detailed procedures.

## DEPENDENCIES

### New Python Package
```bash
pip install pyserial
```

### Arduino Library
- ESP32Servo by Kevin Harrington

### Hardware
- ESP32 DEVKIT V1
- MG996R Servo
- External 5-6V power supply (2A+)
- Jumper wires

## SAFETY CONSIDERATIONS

⚠️ **CRITICAL:**
- MG996R must NOT be powered from ESP32
- Use external 5-6V power supply
- Common ground between ESP32 and power supply
- Constrain servo angles to safe range
- Ensure servo is mechanically free to move

See `ROBOT_WIRING.md` for detailed safety information.

## TROUBLESHOOTING

### Common Issues

**Servo not moving:**
- Check external power supply is ON
- Verify wiring (signal, VCC, GND)
- Check common ground connection
- Verify ESP32 is connected

**Backend can't connect to ESP32:**
- Check COM port is correct
- Verify ESP32 is connected via USB
- Try different USB cable
- Check Arduino Serial Monitor

**Movements too fast/slow:**
- Adjust STEP_DELAY in ESP32 code
- Adjust SERVO_STEP_DELAY in Python code
- Re-upload ESP32 firmware
- Restart Python backend

**Servo hits physical limits:**
- Adjust MIN_ANGLE and MAX_ANGLE
- Update in both ESP32 and Python code
- Re-upload ESP32 firmware
- Restart Python backend

## NEXT STEPS

1. Install dependencies (`pip install pyserial`)
2. Install Arduino IDE and ESP32 support
3. Upload ESP32 firmware
4. Wire hardware according to `ROBOT_WIRING.md`
5. Configure COM port
6. Start Python backend
7. Follow testing procedure in `TESTING.md`
8. Fine-tune movement parameters as needed

## FUTURE ENHANCEMENTS

The architecture supports future additions:
- Face tracking (ATTENTION state with head following)
- Multiple servos (head tilt, facial expressions)
- Voice activity detection for LISTENING state
- Custom animations per interview phase
- Remote robot status monitoring

## FILES MODIFIED/CREATED

### Modified
- `BackEnd/FinalBackend.py` - Added robot controller

### Created
- `BackEnd/esp32_robot_controller.ino` - ESP32 firmware
- `BackEnd/ROBOT_WIRING.md` - Wiring diagram
- `BackEnd/INSTALLATION.md` - Setup instructions
- `BackEnd/TESTING.md` - Testing procedure
- `BackEnd/ROBOT_INTEGRATION_SUMMARY.md` - This file

## SUMMARY

This integration successfully adds robot head movement to your AI interviewer without:
- ❌ Breaking existing functionality
- ❌ Blocking the FastAPI server
- ❌ Requiring complex frameworks
- ❌ Introducing new dependencies (except pyserial)

The robot now behaves like a physical embodiment of the AI interviewer, with natural head movements that respond to the interview state. The system is simple, reliable, and easy to debug through Serial Monitor.
