# Testing Procedure

This guide provides a step-by-step testing procedure for the robot head controller.

## PREREQUISITES

Before testing, ensure:
- [ ] ESP32 is connected to PC via USB
- [ ] ESP32 firmware is uploaded (`esp32_robot_controller.ino`)
- [ ] Servo is wired correctly (see `ROBOT_WIRING.md`)
- [ ] External power supply is connected to servo
- [ ] Common ground is established
- [ ] Python backend is running
- [ ] Robot controller is connected (check backend logs)

## PHASE 1: VERIFY ESP32 CONNECTION

### Step 1.1: Check Backend Logs
Start the Python backend and look for:
```
[ROBOT] Robot Controller initialized - Port: COM11, Baud: 115200
[ROBOT] Starting up - connecting to ESP32...
[ROBOT] Connected to ESP32 on COM11
[ROBOT] Servo angle: 90
```

If you see:
```
[ROBOT] Failed to connect to ESP32: [error]
[ROBOT] Interview will continue without robot movement
```
Then:
1. Check ESP32 is connected via USB
2. Verify COM port is correct
3. Check Arduino Serial Monitor can connect
4. Try reconnecting ESP32

### Step 1.2: Check Robot Status Endpoint
Use curl or Postman to check robot status:

```bash
curl http://127.0.0.1:8000/robot-state
```

Expected response:
```json
{
  "connected": true,
  "state": "IDLE",
  "angle": 90,
  "port": "COM11"
}
```

If `connected` is `false`, troubleshoot connection issues.

## PHASE 2: MANUAL SERVO TESTING

### Step 2.1: Test Direct Angle Control
Test servo movement to specific angles using the `/robot/angle` endpoint.

**Test 1: Center Position**
```bash
curl -X POST http://127.0.0.1:8000/robot/angle -H "Content-Type: application/json" -d "{\"angle\": 90}"
```
- Servo should move to center
- Check Arduino Serial Monitor for: "Servo angle: 90"

**Test 2: Minimum Angle**
```bash
curl -X POST http://127.0.0.1:8000/robot/angle -H "Content-Type: application/json" -d "{\"angle\": 40}"
```
- Servo should move to minimum safe angle
- Verify servo doesn't hit physical limit

**Test 3: Maximum Angle**
```bash
curl -X POST http://127.0.0.1:8000/robot/angle -H "Content-Type: application/json" -d "{\"angle\": 140}"
```
- Servo should move to maximum safe angle
- Verify servo doesn't hit physical limit

**Test 4: Mid Position**
```bash
curl -X POST http://127.0.0.1:8000/robot/angle -H "Content-Type: application/json" -d "{\"angle\": 65}"
```
- Servo should move smoothly to 65°

**If servo hits physical limits:**
- Adjust MIN_ANGLE and MAX_ANGLE in both ESP32 and Python code
- Re-upload ESP32 firmware
- Restart Python backend

### Step 2.2: Test Smooth Movement
Test that movement is smooth (not jerky):
```bash
curl -X POST http://127.0.0.1:8000/robot/angle -H "Content-Type: application/json" -d "{\"angle\": 90}"
```
Observe:
- Movement should be gradual, not instant
- Servo should not jitter
- Movement should take approximately 0.5 seconds

If movement is too fast/slow:
- Adjust STEP_DELAY in ESP32 code
- Adjust SERVO_STEP_DELAY in Python code

### Step 2.3: Test Stop Command
```bash
curl -X POST http://127.0.0.1:8000/robot/stop
```
- Should stop any ongoing animation
- Servo should remain at current position

## PHASE 3: STATE ANIMATION TESTING

### Step 3.1: Test IDLE State
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"IDLE\"}"
```
Expected behavior:
- Servo performs subtle movement: 88° → 90° → 92° → 90°
- Movement repeats continuously
- Movement is slow and subtle
- Long delays between movements (2 seconds)

To stop:
```bash
curl -X POST http://127.0.0.1:8000/robot/stop
```

### Step 3.2: Test LISTENING State
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"LISTENING\"}"
```
Expected behavior:
- Servo performs: 90° → 85° → 90°
- Movement is slow and subtle
- Simulates a listening nod
- Animation runs once and stops

### Step 3.3: Test THINKING State
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"THINKING\"}"
```
Expected behavior:
- Servo performs: 90° → 100° → 90°
- Movement is slow
- Simulates a thoughtful turn
- Animation runs once and stops

### Step 3.4: Test SPEAKING State
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"SPEAKING\"}"
```
Expected behavior:
- Servo performs: 90° → 95° → 90° → 85° → 90°
- Movement is conversational
- Not mechanical oscillation
- Animation runs once and stops

### Step 3.5: Test GREETING State
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"GREETING\"}"
```
Expected behavior:
- Servo performs: 90° → 80° → 100° → 90°
- Wider movement range
- Welcoming gesture
- Animation runs once and stops

### Step 3.6: Test GOODBYE State
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"GOODBYE\"}"
```
Expected behavior:
- Servo performs: 90° → 100° → 80° → 90°
- Farewell gesture
- Animation runs once and stops

### Step 3.7: Test ATTENTION State
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"ATTENTION\"}"
```
Expected behavior:
- Servo moves to center: 90°
- Remains centered
- Animation runs once and stops

### Step 3.8: Test State Interruption
Test that animations can be interrupted:

1. Start IDLE (continuous animation):
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"IDLE\"}"
```

2. Immediately interrupt with LISTENING:
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"LISTENING\"}"
```

Expected behavior:
- IDLE animation stops immediately
- LISTENING animation starts
- No conflicting movements

## PHASE 4: INTEGRATION TESTING WITH INTERVIEW FLOW

### Step 4.1: Test Interview Start
1. Start frontend
2. Upload resume
3. Call `/start-interview` endpoint

Expected behavior:
- Robot performs GREETING animation
- After 2 seconds, robot moves to IDLE state
- Backend returns success response

Check backend logs:
```
[ROBOT] State changed: IDLE -> GREETING
[ROBOT] State changed: GREETING -> IDLE
```

### Step 4.2: Test First Question
1. After interview starts, AI asks first question
2. Robot should be in SPEAKING state during TTS
3. After TTS completes, robot should be in LISTENING state

Check backend logs:
```
[ROBOT] State changed: IDLE -> SPEAKING
[ROBOT] State changed: SPEAKING -> LISTENING
```

### Step 4.3: Test Candidate Answer
1. Candidate answers a question
2. Frontend sends audio to `/transcribe`
3. Robot should be in LISTENING state during transcription

Check backend logs:
```
[ROBOT] State changed: IDLE -> LISTENING
```

### Step 4.4: Test AI Processing
1. After transcription completes
2. Robot should change to THINKING state
3. AI processes the answer
4. Robot should change to SPEAKING state for response

Check backend logs:
```
[ROBOT] State changed: LISTENING -> THINKING
[ROBOT] State changed: THINKING -> SPEAKING
[ROBOT] State changed: SPEAKING -> LISTENING
```

### Step 4.5: Test Multiple Questions
Repeat the interview flow for multiple questions:
1. AI asks question → SPEAKING
2. AI finishes → LISTENING
3. Candidate answers → LISTENING
4. AI processes → THINKING
5. AI responds → SPEAKING
6. AI finishes → LISTENING

Verify state transitions are correct throughout.

### Step 4.6: Test Report Generation
1. Call `/generate-report` endpoint
2. Robot should be in THINKING state during generation
3. After report completes, robot should return to IDLE

Check backend logs:
```
[ROBOT] State changed: LISTENING -> THINKING
[ROBOT] State changed: THINKING -> IDLE
```

## PHASE 5: ERROR HANDLING TESTING

### Step 5.1: Test ESP32 Disconnection
1. Disconnect ESP32 USB cable while backend is running
2. Try to send a robot command:
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"SPEAKING\"}"
```

Expected behavior:
- Backend logs: "[ROBOT] Error sending command"
- Robot state may still change, but no movement occurs
- Interview functionality continues normally
- Backend does not crash

### Step 5.2: Test Reconnection
1. Reconnect ESP32
2. Restart Python backend
3. Verify connection is re-established

Expected behavior:
```
[ROBOT] Connected to ESP32 on COM11
[ROBOT] Servo angle: 90
```

### Step 5.3: Test Invalid Commands
```bash
curl -X POST http://127.0.0.1:8000/robot/test -H "Content-Type: application/json" -d "{\"state\": \"INVALID\"}"
```

Expected behavior:
- Backend returns error response
- Robot state does not change
- No servo movement

## PHASE 6: PERFORMANCE TESTING

### Step 6.1: Test Continuous Operation
Run a full interview session (5-10 questions) and observe:
- Servo movements remain smooth
- No servo overheating
- No ESP32 resets
- No backend crashes
- State transitions are timely

### Step 6.2: Test Concurrent Operations
Test that robot animations don't block the FastAPI server:
1. Start IDLE animation
2. Immediately call `/robot-state` endpoint
3. Response should be immediate (not blocked by animation)

### Step 6.3: Test TTS Synchronization
Verify that SPEAKING state duration matches actual speech:
1. Trigger a question with long response
2. Observe SPEAKING animation
3. Verify robot stays in SPEAKING until speech completes
4. Verify robot returns to LISTENING after speech

## PHASE 7: FINE-TUNING

Based on testing results, you may want to adjust:

### Movement Speed
If movements are too fast/slow:
- Adjust STEP_DELAY in ESP32 code
- Adjust SERVO_STEP_DELAY in Python code

### Angle Limits
If servo hits physical limits:
- Increase MIN_ANGLE (e.g., from 40 to 50)
- Decrease MAX_ANGLE (e.g., from 140 to 130)
- Update in both ESP32 and Python code

### Animation Timing
If animations feel unnatural:
- Adjust delay values in `_animate_*` methods in Python
- Adjust delay values in `animate_*` functions in ESP32

## PHASE 8: FINAL VERIFICATION

Before final deployment:

1. **Full Interview Test**
   - Complete a full interview from start to finish
   - Verify all state transitions
   - Verify robot movements are natural
   - Verify interview functionality is preserved

2. **Robot Status Check**
   - Verify `/robot-state` returns correct information
   - Verify all states are accessible

3. **Manual Override Test**
   - Verify manual test endpoints work
   - Verify they don't interfere with normal operation

4. **Shutdown Test**
   - Stop Python backend
   - Verify servo moves to safe position
   - Verify ESP32 disconnects cleanly

## COMMON ISSUES AND SOLUTIONS

### Servo Jittering
- Check power supply can provide sufficient current
- Check for loose connections
- Verify common ground is connected

### Servo Not Moving
- Check external power supply is ON
- Verify servo wiring
- Check ESP32 Serial Monitor for errors
- Verify GPIO pin is correct

### State Not Changing
- Check backend logs for errors
- Verify robot is connected
- Check `/robot-state` endpoint

### Movement Too Fast/Slow
- Adjust STEP_DELAY values
- Re-upload ESP32 firmware
- Restart Python backend

### Interview Not Working
- Verify existing interview functionality still works
- Check that robot integration didn't break existing features
- Review backend logs for errors

## SUCCESS CRITERIA

Testing is successful when:
- [ ] All manual angle tests pass
- [ ] All state animations work correctly
- [ ] Animations can be interrupted
- [ ] Full interview flow works with robot
- [ ] State transitions are correct throughout interview
- [ ] ESP32 disconnection doesn't crash backend
- [ ] TTS synchronization works correctly
- [ ] Manual test endpoints work
- [ ] Robot status endpoint returns correct information
- [ ] Movements are smooth and natural
- [ ] No servo overheating after extended use
- [ ] Backend remains responsive during animations
