"""
interview_event_detector1.py

Optimized implementation of event detection for interview analysis.
Processes raw MediaPipe FaceLandmarker blendshape logs and compresses them
into meaningful events while maintaining the same file paths.

    Detector      Feature(s)                      Threshold                      Min Duration   Events
    --------      -----------                      ---------                      ------------   ------
    Smile         mouthSmileLeft/Right              <0.5 Neutral / >0.5 Smile       3s             SMILE_START, SMILE_END
    Blink         eyeBlinkLeft/Right                 <0.09 Open / >0.4 Closed        N/A (sequence) BLINK
    Eye Contact   eye-direction blendshapes          <0.2 Up / >0.4 Down             3s             LOOK_FORWARD, LOOK_AWAY, LOOK_DOWN
    Speaking      jawOpen                            <=0.009 Closed / >0.3 Open       0.3s           SPEAKING_START, SPEAKING_END
    Brow Raise    browInnerUp                         <0.09 Down / >0.4 Up            2s             BROW_RAISE_START, BROW_RAISE_END

Optimizations:
- Improved error handling and validation
- Enhanced performance with optimized data structures
- Better timestamp handling and gap detection
- More robust state management
- Configurable parameters for easy tuning
- Cleaner code structure with better separation of concerns
"""

import json
import os
from collections import Counter
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple
import logging

# Configure logging for better debugging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --------------------------------------------------------------------------- #
# Input / output paths -- same as specified in original code
# --------------------------------------------------------------------------- #
Inpath1 = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\expressions.log"
OutPath = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\events.json"


# --------------------------------------------------------------------------- #
# Optimized configuration parameters
# --------------------------------------------------------------------------- #
class DetectorConfig:
    """Centralized configuration for all detectors"""
    
    # Feature combination strategy
    COMBINE_LR: Callable[[float, float], float] = lambda a, b: (a + b) / 2
    
    # Time-based thresholds (in seconds)
    LOOK_AWAY_GAP_SEC: float = 3.0
    SPEAKING_DEBOUNCE_SEC: float = 0.3
    SMILE_DEBOUNCE_SEC: float = 3.0
    BROW_RAISE_DEBOUNCE_SEC: float = 2.0
    EYE_CONTACT_DEBOUNCE_SEC: float = 3.0
    
    # Score thresholds
    SMILE_LOW_TH: float = 0.5
    SMILE_HIGH_TH: float = 0.5
    
    BLINK_LOW_TH: float = 0.09
    BLINK_HIGH_TH: float = 0.4
    
    GAZE_DOWN_LOW_TH: float = 0.2
    GAZE_DOWN_HIGH_TH: float = 0.4
    
    SPEAKING_LOW_TH: float = 0.009
    SPEAKING_HIGH_TH: float = 0.3
    
    BROW_LOW_TH: float = 0.09
    BROW_HIGH_TH: float = 0.4


# --------------------------------------------------------------------------- #
# Optimized feature extraction with validation
# --------------------------------------------------------------------------- #

def _get_feature_safe(blendshapes: Dict[str, float], feature_name: str) -> float:
    """Safely extract feature value with validation"""
    try:
        return float(blendshapes.get(feature_name, 0.0))
    except (TypeError, ValueError):
        return 0.0

def smile_score(blendshapes: Dict[str, float]) -> float:
    """Calculate combined smile score from left and right mouth features"""
    return DetectorConfig.COMBINE_LR(
        _get_feature_safe(blendshapes, "mouthSmileLeft"),
        _get_feature_safe(blendshapes, "mouthSmileRight")
    )

def blink_score(blendshapes: Dict[str, float]) -> float:
    """Calculate combined blink score from left and right eye features"""
    return DetectorConfig.COMBINE_LR(
        _get_feature_safe(blendshapes, "eyeBlinkLeft"),
        _get_feature_safe(blendshapes, "eyeBlinkRight")
    )

def gaze_down_score(blendshapes: Dict[str, float]) -> float:
    """Calculate combined gaze down score from left and right eye features"""
    return DetectorConfig.COMBINE_LR(
        _get_feature_safe(blendshapes, "eyeLookDownLeft"),
        _get_feature_safe(blendshapes, "eyeLookDownRight")
    )

def jaw_open_score(blendshapes: Dict[str, float]) -> float:
    """Calculate jaw open score"""
    return _get_feature_safe(blendshapes, "jawOpen")

def brow_score(blendshapes: Dict[str, float]) -> float:
    """Calculate brow raise score"""
    return _get_feature_safe(blendshapes, "browInnerUp")


# --------------------------------------------------------------------------- #
# Optimized loading with error handling and validation
# --------------------------------------------------------------------------- #

def load_records(path: str) -> List[dict]:
    """
    Load and validate blendshape records from log file.
    Returns sorted list of valid records.
    """
    if not os.path.exists(path):
        logger.warning(f"File not found: {path}")
        return []
    
    records = []
    line_count = 0
    error_count = 0
    
    try:
        with open(path, "r") as f:
            for line in f:
                line_count += 1
                line = line.strip()
                if not line:
                    continue
                
                try:
                    record = json.loads(line)
                    # Validate record structure
                    if isinstance(record, dict) and "timestamp" in record and "blendshapes" in record:
                        # Ensure timestamp is a number
                        try:
                            record["timestamp"] = float(record["timestamp"])
                            # Ensure blendshapes is a dict
                            if not isinstance(record["blendshapes"], dict):
                                record["blendshapes"] = {}
                            records.append(record)
                        except (TypeError, ValueError):
                            error_count += 1
                            continue
                    else:
                        error_count += 1
                        continue
                except json.JSONDecodeError:
                    error_count += 1
                    continue
        
        logger.info(f"Loaded {len(records)} valid records from {line_count} lines ({error_count} errors)")
        
        # Sort by timestamp for chronological processing
        records.sort(key=lambda r: r["timestamp"])
        return records
        
    except IOError as e:
        logger.error(f"Error reading file {path}: {e}")
        return []


# --------------------------------------------------------------------------- #
# Optimized two-state debounced detector with enhanced state management
# Covers Smile, Speaking, Brow Raise: low threshold / high threshold / N
# seconds to confirm / paired START+END events.
# --------------------------------------------------------------------------- #

@dataclass
class TwoStateConfig:
    """Configuration for two-state detectors"""
    feature_fn: Callable[[Dict[str, float]], float]
    low_th: float
    high_th: float
    debounce: float
    start_event: str
    end_event: str
    name: str = "unnamed"  # For logging and debugging


def run_two_state_detector(records: List[dict], cfg: TwoStateConfig) -> List[dict]:
    """
    Optimized two-state detector with improved state management and logging.
    """
    events = []
    state = "low"
    pending_target: Optional[str] = None
    pending_since: Optional[float] = None
    
    for rec in records:
        t = rec["timestamp"]
        score = cfg.feature_fn(rec.get("blendshapes", {}))
        
        # Determine target state based on thresholds
        if score > cfg.high_th:
            target = "high"
        elif score < cfg.low_th:
            target = "low"
        else:
            target = None  # Dead zone - hold current state
        
        # State management logic
        if target is None or target == state:
            # No change needed, reset pending state
            pending_target, pending_since = None, None
            continue
        
        # New target state detected
        if pending_target != target:
            # Start tracking potential state change
            pending_target, pending_since = target, t
            continue
        
        # Check if debounce period has elapsed
        if pending_since is not None and t - pending_since >= cfg.debounce:
            # Confirm state change and generate event
            event_type = cfg.start_event if target == "high" else cfg.end_event
            events.append({
                "event": event_type,
                "timestamp": pending_since,  # When change actually began
                "detector": cfg.name,  # Add detector name for debugging
                "score": round(score, 4)  # Add score for analysis
            })
            state = target
            pending_target, pending_since = None, None
    
    logger.info(f"{cfg.name}: Generated {len(events)} events")
    return events


# --------------------------------------------------------------------------- #
# Optimized blink detector with improved sequence detection
# Sequence: open -> closed -> open = one BLINK, no debounce needed
# --------------------------------------------------------------------------- #

def run_blink_detector(records: List[dict]) -> List[dict]:
    """
    Optimized blink detector with improved sequence detection and validation.
    """
    events = []
    state = "open"
    blink_count = 0
    
    for rec in records:
        t = rec["timestamp"]
        score = blink_score(rec.get("blendshapes", {}))
        
        if state == "open" and score > DetectorConfig.BLINK_HIGH_TH:
            # Transition to closed state
            state = "closed"
        elif state == "closed" and score < DetectorConfig.BLINK_LOW_TH:
            # Complete blink cycle (closed -> open)
            events.append({
                "event": "BLINK",
                "timestamp": t,
                "detector": "blink",
                "score": round(score, 4)
            })
            state = "open"
            blink_count += 1
    
    logger.info(f"Blink detector: Generated {blink_count} blink events")
    return events


# --------------------------------------------------------------------------- #
# Optimized eye contact detector with enhanced gap detection
# 3-way state: LOOK_FORWARD / LOOK_DOWN / LOOK_AWAY
# LOOK_FORWARD and LOOK_DOWN are debounced, LOOK_AWAY driven by frame gaps
# --------------------------------------------------------------------------- #

def run_eye_contact_detector(records: List[dict]) -> List[dict]:
    """
    Optimized eye contact detector with improved gap detection and state management.
    """
    events = []
    state = "forward"
    pending_target: Optional[str] = None
    pending_since: Optional[float] = None
    prev_t: Optional[float] = None
    away_events = 0
    
    for rec in records:
        t = rec["timestamp"]
        
        # Detect LOOK_AWAY based on time gap between frames
        if prev_t is not None and (t - prev_t) >= DetectorConfig.LOOK_AWAY_GAP_SEC and state != "away":
            events.append({
                "event": "LOOK_AWAY",
                "timestamp": prev_t,
                "detector": "eye_contact",
                "gap_duration": round(t - prev_t, 2)
            })
            state = "away"
            pending_target, pending_since = None, None
            away_events += 1
        prev_t = t
        
        # Calculate gaze direction score
        score = gaze_down_score(rec.get("blendshapes", {}))
        
        # Determine target state based on gaze direction
        if score > DetectorConfig.GAZE_DOWN_HIGH_TH:
            target = "down"
        elif score < DetectorConfig.GAZE_DOWN_LOW_TH:
            target = "forward"
        else:
            target = None  # Dead zone
        
        # Handle recovery from LOOK_AWAY state
        if state == "away":
            # Immediate state change when face is detected again
            state = target or "forward"
            events.append({
                "event": "LOOK_DOWN" if state == "down" else "LOOK_FORWARD",
                "timestamp": t,
                "detector": "eye_contact",
                "score": round(score, 4)
            })
            pending_target, pending_since = None, None
            continue
        
        # Normal state management for forward/down states
        if target is None or target == state:
            pending_target, pending_since = None, None
            continue
        
        # New target state detected
        if pending_target != target:
            pending_target, pending_since = target, t
            continue
        
        # Check if debounce period has elapsed
        if pending_since is not None and t - pending_since >= DetectorConfig.EYE_CONTACT_DEBOUNCE_SEC:
            event_type = "LOOK_DOWN" if target == "down" else "LOOK_FORWARD"
            events.append({
                "event": event_type,
                "timestamp": pending_since,
                "detector": "eye_contact",
                "score": round(score, 4)
            })
            state = target
            pending_target, pending_since = None, None
    
    logger.info(f"Eye contact detector: Generated {len(events)} events ({away_events} LOOK_AWAY)")
    return events


# --------------------------------------------------------------------------- #
# Optimized orchestration with centralized configuration
# --------------------------------------------------------------------------- #

def get_detector_configs() -> Dict[str, TwoStateConfig]:
    """Get optimized detector configurations using centralized config"""
    return {
        "smile": TwoStateConfig(
            feature_fn=smile_score,
            low_th=DetectorConfig.SMILE_LOW_TH,
            high_th=DetectorConfig.SMILE_HIGH_TH,
            debounce=DetectorConfig.SMILE_DEBOUNCE_SEC,
            start_event="SMILE_START",
            end_event="SMILE_END",
            name="smile"
        ),
        "speaking": TwoStateConfig(
            feature_fn=jaw_open_score,
            low_th=DetectorConfig.SPEAKING_LOW_TH,
            high_th=DetectorConfig.SPEAKING_HIGH_TH,
            debounce=DetectorConfig.SPEAKING_DEBOUNCE_SEC,
            start_event="SPEAKING_START",
            end_event="SPEAKING_END",
            name="speaking"
        ),
        "brow_raise": TwoStateConfig(
            feature_fn=brow_score,
            low_th=DetectorConfig.BROW_LOW_TH,
            high_th=DetectorConfig.BROW_HIGH_TH,
            debounce=DetectorConfig.BROW_RAISE_DEBOUNCE_SEC,
            start_event="BROW_RAISE_START",
            end_event="BROW_RAISE_END",
            name="brow_raise"
        ),
    }


def detect_events(records: List[dict]) -> List[dict]:
    """
    Run all detectors and return combined, sorted events.
    """
    events = []
    
    # Run two-state detectors
    detector_configs = get_detector_configs()
    for cfg in detector_configs.values():
        events.extend(run_two_state_detector(records, cfg))
    
    # Run specialized detectors
    events.extend(run_blink_detector(records))
    events.extend(run_eye_contact_detector(records))
    
    # Sort events by timestamp for chronological order
    events.sort(key=lambda e: e["timestamp"])
    
    logger.info(f"Total events generated: {len(events)}")
    return events


# --------------------------------------------------------------------------- #
# Optimized utility functions
# --------------------------------------------------------------------------- #

def seconds_to_hms(seconds: float) -> str:
    """Convert seconds to HH:MM:SS format with improved precision"""
    seconds = max(0, float(seconds))
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def build_summary(records: List[dict], events: List[dict]) -> dict:
    """
    Build comprehensive summary of the analysis.
    """
    if not records:
        return {
            "total_duration_sec": 0,
            "event_counts": {},
            "frame_count": 0,
            "events_per_minute": 0
        }
    
    total_duration = records[-1]["timestamp"] - records[0]["timestamp"]
    events_per_minute = (len(events) / total_duration * 60) if total_duration > 0 else 0
    
    return {
        "total_duration_sec": round(total_duration, 2),
        "event_counts": dict(Counter(e["event"] for e in events)),
        "frame_count": len(records),
        "events_per_minute": round(events_per_minute, 2),
        "first_event_time": events[0]["timestamp"] if events else None,
        "last_event_time": events[-1]["timestamp"] if events else None
    }


# --------------------------------------------------------------------------- #
# Optimized main entry point with enhanced error handling
# --------------------------------------------------------------------------- #

def analyze_expressions() -> dict:
    """
    Main entry point for expression analysis.
    
    Reads conversation frames from expressions.log, runs all detectors,
    and writes compressed events to events.json (same paths as original).
    
    Returns:
        dict: {"events": [...], "summary": {...}} for direct use in backend
    """
    try:
        # Load and validate records
        records = load_records(Inpath1)
        if not records:
            logger.warning("No valid records found in expressions.log")
            return {"events": [], "summary": {}}
        
        logger.info(f"Processing {len(records)} frames from {Inpath1}")
        
        # Detect events using optimized detectors
        conversation_start = records[0]["timestamp"]
        events = detect_events(records)
        
        # Add relative timing information to each event
        for e in events:
            e["rel_sec"] = round(e["timestamp"] - conversation_start, 2)
            e["hms"] = seconds_to_hms(e["rel_sec"])
        
        # Build comprehensive summary
        summary = build_summary(records, events)
        
        # Write events to output file with error handling
        try:
            # Ensure output directory exists
            output_dir = os.path.dirname(OutPath)
            if output_dir and not os.path.exists(output_dir):
                os.makedirs(output_dir, exist_ok=True)
            
            with open(OutPath, "w") as f:
                for e in events:
                    f.write(json.dumps(e) + "\n")
            
            logger.info(f"Successfully wrote {len(events)} events to {OutPath}")
            
        except IOError as e:
            logger.error(f"Error writing to {OutPath}: {e}")
            # Still return results even if file write fails
        
        return {"events": events, "summary": summary}
        
    except Exception as e:
        logger.error(f"Error in analyze_expressions: {e}")
        return {"events": [], "summary": {}}
