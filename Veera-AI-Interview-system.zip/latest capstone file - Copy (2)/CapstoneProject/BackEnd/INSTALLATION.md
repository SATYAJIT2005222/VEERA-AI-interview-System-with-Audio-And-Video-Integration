# Installation and Setup Guide

## REQUIREMENTS

### Python Packages
The following Python packages are required. Most are likely already installed, but check:

**Required (new for robot control):**
- `pyserial` - For serial communication with ESP32

**Already installed (preserve existing):**
- `fastapi` - Web framework
- `uvicorn` - ASGI server
- `pyttsx3` - Text-to-speech
- `whisper` - Speech recognition
- `google-adk` - Google Agent Development Kit
- `pdfplumber` - PDF text extraction
- `opencv-python` (cv2) - Computer vision
- `mediapipe` - Face landmark detection
- `numpy` - Numerical computing

### Arduino IDE
- Arduino IDE 2.x or 1.8.x
- ESP32 board support package

### Hardware
- ESP32 DEVKIT V1
- MG996R Servo
- External 5-6V power supply (2A+)
- USB cable for ESP32
- Jumper wires

## STEP 1: INSTALL PYTHON DEPENDENCIES

Install the new serial communication package:

```bash
pip install pyserial
```

If you want to verify all packages are installed:

```bash
pip install fastapi uvicorn pyttsx3 openai-whisper google-adk pdfplumber opencv-python mediapipe numpy pyserial
```

## STEP 2: INSTALL ARDUINO IDE AND ESP32 SUPPORT

### Install Arduino IDE
Download from: https://www.arduino.cc/en/software

### Add ESP32 Board Support
1. Open Arduino IDE
2. Go to **File > Preferences**
3. In "Additional Board Manager URLs", add:
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
4. Click OK
5. Go to **Tools > Board > Boards Manager**
6. Search for "ESP32"
7. Install "ESP32 by Espressif Systems"

### Install ESP32Servo Library
1. Go to **Sketch > Include Library > Manage Libraries**
2. Search for "ESP32Servo"
3. Install "ESP32Servo by Kevin Harrington"

## STEP 3: CONFIGURE ESP32 ARDUINO CODE

1. Open Arduino IDE
2. Open the file: `esp32_robot_controller.ino`
3. Verify the configuration at the top of the file:

```cpp
const int SERVO_PIN = 18;  // Change if using different GPIO
const int MIN_ANGLE = 40;  // Adjust based on your servo
const int MAX_ANGLE = 140; // Adjust based on your servo
const int CENTER_ANGLE = 90;
const int STEP_DELAY = 20;
const int BAUD_RATE = 115200;
```

4. Select your board:
   - **Tools > Board > ESP32 Arduino > ESP32 Dev Module**

5. Select the correct COM port:
   - **Tools > Port > COM[X]** (check Windows Device Manager)

6. Upload the code to ESP32:
   - Click the Upload button (→)
   - Wait for compilation and upload to complete

7. Open Serial Monitor (magnifying glass icon) to verify:
   - Set baud rate to 115200
   - You should see: "ESP32 Robot Head Controller"
   - Then: "Ready to receive commands"

## STEP 4: CONFIGURE PYTHON BACKEND

### Set ESP32 Port (COM Port)

**Option A: Environment Variable (Recommended)**
```bash
# Windows Command Prompt
set ESP32_PORT=COM11

# Windows PowerShell
$env:ESP32_PORT="COM11"

# Or set it permanently in System Environment Variables
```

**Option B: Modify Code Directly**
Edit `FinalBackend.py` and change the default port:
```python
ESP32_PORT = os.getenv("ESP32_PORT", "COM11")  # Change COM11 to your port
```

### Verify Configuration Section
In `FinalBackend.py`, ensure these values match your setup:

```python
# =========================
# ROBOT CONFIGURATION
# =========================
ESP32_PORT = os.getenv("ESP32_PORT", "COM11")
ESP32_BAUDRATE = 115200

SERVO_CENTER = 90
SERVO_MIN = 40
SERVO_MAX = 140

SERVO_STEP_DELAY = 0.02
```

These values should match the ESP32 Arduino code configuration.

## STEP 5: HARDWARE SETUP

Follow the wiring diagram in `ROBOT_WIRING.md`. Summary:

1. **Connect ESP32 to PC** via USB cable
2. **Connect Servo Signal** to ESP32 GPIO 18 (or configured pin)
3. **Connect Servo GND** to ESP32 GND
4. **Connect Servo GND** to External Power Supply GND (common ground)
5. **Connect Servo VCC** to External Power Supply +V (5-6V)
6. **DO NOT** connect servo VCC to ESP32 5V pin
7. **DO NOT** power servo from ESP32

## STEP 6: WIRING CHECKLIST

Before powering on:
- [ ] ESP32 connected to PC via USB
- [ ] Servo signal wire → ESP32 GPIO 18
- [ ] Servo GND → ESP32 GND
- [ ] Servo GND → Power Supply GND
- [ ] Servo VCC → Power Supply +V (5-6V)
- [ ] Servo VCC NOT connected to ESP32
- [ ] External power supply OFF
- [ ] Servo mechanically free to move

## STEP 7: START THE SYSTEM

### 1. Power On ESP32
- The ESP32 will power up via USB from PC
- Wait 2-3 seconds for initialization

### 2. Power On Servo
- Turn on external power supply
- Servo should move to center position (90°)
- Check Serial Monitor to confirm initialization

### 3. Start Python Backend
```bash
cd BackEnd
python FinalBackend.py
```

You should see:
```
[ROBOT] Robot Controller initialized - Port: COM11, Baud: 115200
[ROBOT] Starting up - connecting to ESP32...
[ROBOT] Connected to ESP32 on COM11
[ROBOT] Servo angle: 90
All clear until now...Created landmarker
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://127.0.0.1:8000
```

If ESP32 is not connected, you'll see:
```
[ROBOT] Failed to connect to ESP32: [error details]
[ROBOT] Interview will continue without robot movement
```

The backend will still work, just without robot movement.

### 4. Start Frontend
Navigate to your frontend directory and start it (as per your existing setup).

## STEP 8: VERIFY SERIAL PORT (Windows)

If you're unsure which COM port to use:

1. Open **Device Manager** (Win+X, then Device Manager)
2. Expand **Ports (COM & LPT)**
3. Look for "USB Serial Port" or "Silicon Labs CP210x" or similar
4. Note the COM port number (e.g., COM3, COM11)
5. Use this port in your configuration

## STEP 9: TROUBLESHOOTING CONNECTION ISSUES

### ESP32 Not Recognized
1. Try a different USB cable (some cables are power-only)
2. Try a different USB port on PC
3. Install CP210x or CH340 drivers if needed:
   - CP210x: https://www.silabs.com/developers/usb-to-uart-bridge-vcp-drivers
   - CH340: http://www.wch.cn/download/CH341SER_EXE.html

### Port Already in Use
1. Close Arduino IDE Serial Monitor
2. Close any other terminal/serial programs
3. Restart Python backend

### Permission Error (Windows)
1. Run Command Prompt as Administrator
2. Or add user to Dialout group (if using WSL/Linux)

## STEP 10: CONFIGURATION ADJUSTMENTS

### Change Servo Pin
Edit `esp32_robot_controller.ino`:
```cpp
const int SERVO_PIN = 18;  // Change to your GPIO
```

### Adjust Servo Angle Limits
If your servo cannot safely reach 40° or 140°, adjust in both files:

**ESP32 (Arduino):**
```cpp
const int MIN_ANGLE = 50;   // Increase if servo hits physical limit
const int MAX_ANGLE = 130;  // Decrease if servo hits physical limit
```

**Python (FinalBackend.py):**
```python
SERVO_MIN = 50
SERVO_MAX = 130
```

### Adjust Movement Speed
Make movement faster or slower:

**ESP32 (Arduino):**
```cpp
const int STEP_DELAY = 20;  // Lower = faster, Higher = slower
```

**Python (FinalBackend.py):**
```python
SERVO_STEP_DELAY = 0.02  # Lower = faster, Higher = slower
```

## STEP 11: READY TO TEST

Once everything is set up:
1. Follow the testing procedure in `TESTING.md`
2. Start with manual test endpoints
3. Then test full interview flow

## ADDITIONAL NOTES

### Automatic Startup
To make the backend start automatically with robot connection:
- Add ESP32_PORT to system environment variables
- Create a batch file to start the backend

### Multiple COM Ports
If you have multiple devices, verify which COM port is ESP32 by:
- Unplugging and replugging ESP32
- Watching which COM port appears/disappears in Device Manager

### Linux/Mac Users
Replace COM ports with /dev/ttyUSB0 or /dev/tty.usbserial-...:
```bash
export ESP32_PORT=/dev/ttyUSB0
```
