import os
import cv2
import mediapipe as mp
import numpy as np
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

# --- 1. CONFIGURATION & LANDMARK INDICES ---
LIP_TOP = 13
LIP_BOTTOM = 14
LIP_LEFT = 61
LIP_RIGHT = 291

# Left and Right Iris indices (Tasks API extracts 4 points per iris: 468-472, 473-477)
LEFT_IRIS = [468, 469, 470, 471]
RIGHT_IRIS = [473, 474, 475, 476]

LEFT_EYE_INNER = 133
LEFT_EYE_OUTER = 33
RIGHT_EYE_INNER = 362
RIGHT_EYE_OUTER = 263

def get_distance(p1, p2):
    return np.linalg.norm(np.array(p1) - np.array(p2))

# --- 2. DYNAMIC PATH CORRECTION ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(SCRIPT_DIR, 'face_landmarker.task')

base_options = python.BaseOptions(model_asset_path=MODEL_PATH)
options = vision.FaceLandmarkerOptions(
    base_options=base_options,
    output_face_blendshapes=True, 
    output_facial_transformation_matrixes=False,
    num_faces=1
)
detector = vision.FaceLandmarker.create_from_options(options)

# --- 3. START WEBCAM CAPTURE ---
cap = cv2.VideoCapture(0)
print("Starting Screen-Optimised Face Landmarker Engine... Press 'q' to quit.")

while cap.isOpened():
    success, frame = cap.read()
    if not success:
        print("Ignoring empty camera frame.")
        continue

    frame = cv2.flip(frame, 1)
    height, width, _ = frame.shape
    
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
    
    detection_result = detector.detect(mp_image)
    
    speaking_status = "Silent"
    gaze_status = "No Face Detected"
    expression = "Neutral"

    if detection_result.face_landmarks:
        gaze_status = "Calibrating..."
        # Extract the list containing landmark objects
        landmarks_list = detection_result.face_landmarks[0]
        
        # Convert normalized coordinates to pixel coordinates
        coords = [(int(lm.x * width), int(lm.y * height)) for lm in landmarks_list]
        
        # --- A. SPEAKING DETECTION ---
        lip_dist = get_distance(coords[LIP_TOP], coords[LIP_BOTTOM])
        lip_width = get_distance(coords[LIP_LEFT], coords[LIP_RIGHT])
        if lip_dist / lip_width > 0.15: 
            speaking_status = "Speaking"
        else:
            speaking_status = "Silent"

        # --- B. ADJUSTED SCREEN-GAZE DETECTION ---
        # Extract Left Iris Center by averaging the 4 iris landmarks
        left_iris_center = np.mean([coords[i] for i in LEFT_IRIS], axis=0)
        
        left_eye_width = get_distance(coords[LEFT_EYE_INNER], coords[LEFT_EYE_OUTER])
        left_gaze_dist = get_distance(coords[LEFT_EYE_INNER], left_iris_center)
        
        gaze_ratio = left_gaze_dist / (left_eye_width + 1e-6)
        
        # CHANGED: Widened the thresholds from (0.43 - 0.57) to (0.38 - 0.62)
        # This safely accounts for screen-gaze angles without dropping eye contact
        if 0.38 <= gaze_ratio <= 0.62:
            gaze_status = "Eye-Contact"
        else:
            gaze_status = "Looked Away"

        # --- C. FACIAL EXPRESSIONS VIA BLENDSHAPES ---
        if detection_result.face_blendshapes:
            blendshapes = detection_result.face_blendshapes[0]
            scores = {b.category_name: b.score for b in blendshapes}
            
            if scores.get('jawOpen', 0) > 0.35:
                expression = "Surprised"
            elif scores.get('mouthSmileLeft', 0) > 0.45 or scores.get('mouthSmileRight', 0) > 0.45:
                expression = "Smiling / Happy"
            elif scores.get('browDownLeft', 0) > 0.4 or scores.get('browDownRight', 0) > 0.4:
                expression = "Frowning / Angry"
            else:
                expression = "Neutral"

        # NOTE: Green dot drawer loop (`cv2.circle`) has been completely removed from here.

    # --- 4. HUD / UI DISPLAY OVERLAY ---
    cv2.rectangle(frame, (10, 10), (340, 150), (0, 0, 0), -1)
    
    cv2.putText(frame, f"Gaze: {gaze_status}", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
    cv2.putText(frame, f"Speech: {speaking_status}", (20, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0) if speaking_status == "Speaking" else (0, 0, 255), 2)
    cv2.putText(frame, f"Expression: {expression}", (20, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)

    cv2.imshow('MediaPipe Tasks Gesture Analyzer', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
