# Robot Head Controller - Wiring Diagram

## ⚠️ IMPORTANT SAFETY NOTES

**DO NOT power the MG996R servo from the ESP32!**
- The MG996R requires significant current (stall current can exceed 2A)
- ESP32 GPIO pins cannot provide this current
- ESP32 5V/3.3V pins are not designed to power servos
- Attempting to power the servo from ESP32 may damage the ESP32

**USE AN EXTERNAL POWER SUPPLY:**
- Voltage: 5-6V DC
- Current capability: At least 2A (recommended 3A for safety)
- Common options: 5V 3A power supply, 4xAA battery pack (6V), or dedicated servo power supply

## WIRING DIAGRAM

```
┌─────────────────────────────────────────────────────────────────┐
│                        ESP32 DEVKIT V1                           │
│                                                                   │
│  ┌─────────┐                                                      │
│  │   USB   │ ──── To PC (Serial Communication & Power)          │
│  └─────────┘                                                      │
│                                                                   │
│  GPIO 18 ─────────────────────┐                                 │
│  (or any PWM-capable GPIO)     │                                 │
│                                │                                 │
│  GND ─────────────────────────┼──────────────────────────┐     │
│                                │                          │     │
└────────────────────────────────┼──────────────────────────┼─────┘
                                 │                          │
                                 │                          │
                            ┌────▼─────┐              ┌─────▼─────┐
                            │ MG996R   │              │ EXTERNAL  │
                            │ SERVO    │              │ 5-6V      │
                            │          │              │ POWER     │
                            │          │              │ SUPPLY    │
                            │          │              │           │
                            │ SIGNAL ◄─┘              │ +V ────┐  │
                            │                          │        │  │
                            │ VCC ◄────────────────────┘        │  │
                            │                          │        │  │
                            │ GND ◄─────────────────────────────┘  │
                            └──────────────────────────────────────┘
```

## DETAILED CONNECTIONS

### ESP32 to MG996R Servo
| ESP32 Pin | Servo Wire | Color (Typical) |
|-----------|------------|-----------------|
| GPIO 18   | Signal     | Orange/Yellow   |
| GND       | GND        | Brown/Black     |

### External Power Supply to MG996R Servo
| Power Supply | Servo Wire | Color (Typical) |
|--------------|------------|-----------------|
| +V (5-6V)    | VCC        | Red             |
| GND          | GND        | Brown/Black     |

### Common Ground Connection
**CRITICAL:** Connect ESP32 GND to External Power Supply GND
| ESP32 Pin | Power Supply |
|-----------|--------------|
| GND       | GND          |

## PIN ASSIGNMENT

The ESP32 code uses GPIO 18 by default. You can change this in the Arduino code:

```cpp
const int SERVO_PIN = 18;  // Change this to match your wiring
```

Other suitable GPIO pins on ESP32:
- GPIO 2, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23
- Avoid GPIO 0, 1, 2, 12, 15 if using boot mode
- Avoid GPIO 34-39 (input only)

## SERVO WIRE COLORS (MG996R)

MG996R servos typically use these color codes:
- **Orange/Yellow**: Signal (PWM control)
- **Red**: VCC (Power +5V to +6V)
- **Brown/Black**: GND (Ground)

## POWER SUPPLY RECOMMENDATIONS

### Option 1: 5V 3A DC Power Supply
- Reliable and stable
- Suitable for continuous operation
- Common and affordable

### Option 2: 4xAA Battery Pack
- Provides 6V (4 × 1.5V alkaline)
- Portable solution
- Note: Voltage will drop as batteries discharge

### Option 3: Dedicated Servo Power Supply
- Specifically designed for servos
- Often includes voltage regulation
- Best for long-term reliability

## TROUBLESHOOTING

### Servo not moving
1. Check external power supply is connected and turned on
2. Verify common ground connection between ESP32 and power supply
3. Check servo wiring (signal to GPIO, VCC to +V, GND to GND)
4. Verify GPIO pin number matches Arduino code
5. Check Serial Monitor for errors

### Servo jittering or unstable
1. Ensure external power supply can provide sufficient current
2. Check for loose connections
3. Verify power supply voltage is stable (5-6V)
4. Check if servo angle limits are appropriate

### ESP32 resetting
1. This may indicate power supply issues
2. Ensure ESP32 is powered separately via USB
3. Do not power ESP32 from servo power supply

### Servo not reaching full range
1. MG996R may not safely travel full 0-180° range
2. Adjust MIN_ANGLE and MAX_ANGLE in Arduino code
3. Default: MIN_ANGLE = 40, MAX_ANGLE = 140

## SAFETY CHECKLIST

Before powering on:
- [ ] External power supply disconnected
- [ ] ESP32 connected to PC via USB
- [ ] Servo signal wire connected to GPIO 18
- [ ] Servo GND connected to ESP32 GND
- [ ] Servo GND connected to power supply GND
- [ ] Servo VCC NOT connected to ESP32
- [ ] External power supply set to 5-6V
- [ ] Servo mechanically free to move (not blocked)
- [ ] Arduino code uploaded to ESP32
- [ ] Python backend configured with correct COM port

Power on sequence:
1. Connect ESP32 to PC via USB
2. Connect external power supply to servo
3. Verify servo moves to center position (90°)
4. Start Python backend
5. Begin testing
