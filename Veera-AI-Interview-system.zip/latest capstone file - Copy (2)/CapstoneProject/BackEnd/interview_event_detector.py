"""
interview_event_detector.py

Implements the event-detection spec from your reference table on top of raw
per-frame MediaPipe FaceLandmarker blendshape logs (JSONL: one line per frame,
{"timestamp": ..., "blendshapes": {...}}).

    Detector      Feature(s)                      Threshold                      Min Duration   Events
    --------      -----------                      ---------                      ------------   ------
    Smile         mouthSmileLeft/Right              <0.5 Neutral / >0.5 Smile       3s             SMILE_START, SMILE_END
    Blink         eyeBlinkLeft/Right                 <0.09 Open / >0.4 Closed        N/A (sequence) BLINK
    Eye Contact   eye-direction blendshapes          <0.2 Up / >0.4 Down             3s             LOOK_FORWARD, LOOK_AWAY, LOOK_DOWN
    Speaking      jawOpen                            <=0.009 Closed / >0.3 Open       ?              SPEAKING_START, SPEAKING_END
    Brow Raise    browInnerUp                         <0.09 Down / >0.4 Up            2s             BROW_RAISE_START, BROW_RAISE_END

"Minimum Duration to state change" is implemented as a DEBOUNCE: the raw
score has to stay past a threshold continuously for that many seconds before
the state is confirmed and a START/END event fires. A brief spike that drops
back before the debounce window elapses produces no event at all -- that's
what keeps a single noisy frame from generating a false SMILE_START.

Three things the table doesn't fully pin down -- tune here or tell me if
these guesses are wrong:
"""

import argparse
import json
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional


# --------------------------------------------------------------------------- #
# Tunable assumptions (see module docstring)
# --------------------------------------------------------------------------- #
COMBINE_LR = lambda a, b: (a + b) / 2   # how Left/Right feature pairs are combined; swap for `max`
LOOK_AWAY_GAP_SEC = 3.0                  # no frames for this long -> LOOK_AWAY (face not detected)
SPEAKING_DEBOUNCE_SEC = 0.3              # "?" in the source table -- placeholder, confirm/tune


# --------------------------------------------------------------------------- #
# Feature extraction
# --------------------------------------------------------------------------- #

Inpath1="D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\expressions.log"
OutPath="D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\events.json"

def _g(b: Dict[str, float], k: str) -> float:
    return b.get(k, 0.0)

def smile_score(b):     return COMBINE_LR(_g(b, "mouthSmileLeft"), _g(b, "mouthSmileRight"))
def blink_score(b):     return COMBINE_LR(_g(b, "eyeBlinkLeft"), _g(b, "eyeBlinkRight"))
def gaze_down_score(b): return COMBINE_LR(_g(b, "eyeLookDownLeft"), _g(b, "eyeLookDownRight"))
def jaw_open_score(b):  return _g(b, "jawOpen")
def brow_score(b):      return _g(b, "browInnerUp")


# --------------------------------------------------------------------------- #
# Loading + session safety net (see earlier discussion: don't let leftover
# frames from an older session in the same log file corrupt a fresh reading)
# --------------------------------------------------------------------------- #

def load_records(path: str) -> List[dict]:
    records = []
    with open(path, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    records.sort(key=lambda r: r["timestamp"])
    return records


def split_sessions(records: List[dict], session_gap: float = 30.0) -> List[List[dict]]:
    if not records:
        return []
    sessions = [[records[0]]]
    for prev, curr in zip(records, records[1:]):
        if curr["timestamp"] - prev["timestamp"] > session_gap:
            sessions.append([])
        sessions[-1].append(curr)
    return sessions


# --------------------------------------------------------------------------- #
# Generic two-state debounced detector
# Covers Smile, Speaking, Brow Raise: low threshold / high threshold / N
# seconds to confirm / paired START+END events.
# --------------------------------------------------------------------------- #

@dataclass
class TwoStateConfig:
    feature_fn: Callable[[dict], float]
    low_th: float
    high_th: float
    debounce: float
    start_event: str
    end_event: str


def run_two_state_detector(records: List[dict], cfg: TwoStateConfig) -> List[dict]:
    events = []
    state = "low"
    pending_target: Optional[str] = None
    pending_since: Optional[float] = None

    for rec in records:
        t = rec["timestamp"]
        score = cfg.feature_fn(rec.get("blendshapes", {}))

        if score > cfg.high_th:
            target = "high"
        elif score < cfg.low_th:
            target = "low"
        else:
            target = None  # dead zone between the thresholds -- hold current state

        if target is None or target == state:
            pending_target, pending_since = None, None
            continue

        if pending_target != target:
            pending_target, pending_since = target, t
            continue

        if t - pending_since >= cfg.debounce:
            events.append({
                "event": cfg.start_event if target == "high" else cfg.end_event,
                "timestamp": pending_since,  # when the change actually began, not when it was confirmed
            })
            state = target
            pending_target, pending_since = None, None

    return events


# --------------------------------------------------------------------------- #
# Blink: sequence-based pulse (open -> closed -> open = one BLINK), no debounce
# --------------------------------------------------------------------------- #

def run_blink_detector(records: List[dict], low_th: float = 0.09, high_th: float = 0.4) -> List[dict]:
    events = []
    state = "open"
    for rec in records:
        t = rec["timestamp"]
        score = blink_score(rec.get("blendshapes", {}))
        if state == "open" and score > high_th:
            state = "closed"
        elif state == "closed" and score < low_th:
            events.append({"event": "BLINK", "timestamp": t})
            state = "open"
    return events


# --------------------------------------------------------------------------- #
# Eye Contact: 3-way state -- LOOK_FORWARD / LOOK_DOWN driven by gaze_down_score
# (debounced, per the table), LOOK_AWAY driven by a frame-log gap (see
# assumption #2 in the module docstring).
# --------------------------------------------------------------------------- #

def run_eye_contact_detector(
    records: List[dict],
    down_low_th: float = 0.2,
    down_high_th: float = 0.4,
    debounce: float = 3.0,
    away_gap_sec: float = LOOK_AWAY_GAP_SEC,
) -> List[dict]:
    events = []
    state = "forward"
    pending_target: Optional[str] = None
    pending_since: Optional[float] = None
    prev_t: Optional[float] = None

    for rec in records:
        t = rec["timestamp"]

        if prev_t is not None and (t - prev_t) >= away_gap_sec and state != "away":
            events.append({"event": "LOOK_AWAY", "timestamp": prev_t})
            state = "away"
            pending_target, pending_since = None, None
        prev_t = t

        score = gaze_down_score(rec.get("blendshapes", {}))
        if score > down_high_th:
            target = "down"
        elif score < down_low_th:
            target = "forward"
        else:
            target = None

        if state == "away":
            # first frame back after an absence: re-baseline immediately, no debounce
            state = target or "forward"
            events.append({"event": "LOOK_DOWN" if state == "down" else "LOOK_FORWARD", "timestamp": t})
            pending_target, pending_since = None, None
            continue

        if target is None or target == state:
            pending_target, pending_since = None, None
            continue

        if pending_target != target:
            pending_target, pending_since = target, t
            continue

        if t - pending_since >= debounce:
            events.append({"event": "LOOK_DOWN" if target == "down" else "LOOK_FORWARD", "timestamp": pending_since})
            state = target
            pending_target, pending_since = None, None

    return events


# --------------------------------------------------------------------------- #
# Orchestration
# --------------------------------------------------------------------------- #

DETECTORS: Dict[str, TwoStateConfig] = {
    "smile":      TwoStateConfig(smile_score,   low_th=0.5,   high_th=0.5, debounce=3.0,                  start_event="SMILE_START",       end_event="SMILE_END"),
    "speaking":   TwoStateConfig(jaw_open_score, low_th=0.009, high_th=0.3, debounce=SPEAKING_DEBOUNCE_SEC, start_event="SPEAKING_START",    end_event="SPEAKING_END"),
    "brow_raise": TwoStateConfig(brow_score,     low_th=0.09,  high_th=0.4, debounce=2.0,                  start_event="BROW_RAISE_START",  end_event="BROW_RAISE_END"),
}


def detect_events(records: List[dict]) -> List[dict]:
    events = []
    for cfg in DETECTORS.values():
        events.extend(run_two_state_detector(records, cfg))
    events.extend(run_blink_detector(records))
    events.extend(run_eye_contact_detector(records))
    events.sort(key=lambda e: e["timestamp"])
    return events


def seconds_to_hms(s: float) -> str:
    s = max(0, int(s))
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def build_summary(records: List[dict], events: List[dict]) -> dict:
    from collections import Counter
    total = records[-1]["timestamp"] - records[0]["timestamp"] if records else 0
    return {
        "total_duration_sec": round(total, 2),
        "event_counts": dict(Counter(e["event"] for e in events)),
    }


def process_log(path: str, session_gap: float = 30.0, session: str = "latest"):
    all_records = load_records(path)
    if not all_records:
        return {"events": [], "summary": {}}

    sessions = split_sessions(all_records, session_gap=session_gap)
    chosen = sessions if session == "all" else [sessions[-1]]

    results = []
    for records in chosen:
        session_start = records[0]["timestamp"]
        events = detect_events(records)
        for e in events:
            e["rel_sec"] = round(e["timestamp"] - session_start, 2)
            e["hms"] = seconds_to_hms(e["rel_sec"])
        results.append({"events": events, "summary": build_summary(records, events)})

    return results if session == "all" else results[0]


def Process_expressions():
    parser = argparse.ArgumentParser(description="Run the spec'd detectors (Smile/Blink/Eye Contact/Speaking/Brow Raise) over a blendshape log.")
    # parser.add_argument("log_path")
    # parser.add_argument("-o", "--output", default="events.json")
    parser.add_argument("--session", choices=["latest", "all"], default="latest")
    parser.add_argument("--session-gap", type=float, default=30.0)
    args = parser.parse_args()

    result = process_log(Inpath1, session_gap=args.session_gap, session=args.session)
    results = result if args.session == "all" else [result]

    for i, r in enumerate(results):
        if args.session == "all":
            print(f"--- Session {i+1} ---")
        print("Summary:", json.dumps(r["summary"]))
        for e in r["events"]:
            print(f"  [{e['hms']}]  {e['event']}")
        print()

    with open(OutPath, "w") as f:
        json.dump(result, f, indent=2)
    print(f"Saved -> {OutPath}")
