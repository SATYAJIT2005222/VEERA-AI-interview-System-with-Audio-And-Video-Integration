"""
interview_report_generator.py

Comprehensive interview report generation module.
Collects all interview data and generates professional AI-assisted evaluation reports.
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# File paths
RESUME_PATH = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\uploaded_resume.pdf"
FALLBACK_RESUME = "sample_resume.pdf"
EXPRESSIONS_PATH = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\expressions.log"
EVENTS_PATH = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\events.json"
CONVERSATION_PATH = r"D:\VEERA-18October\latest capstone file - Copy (2)\Outsiders\conversation.json"


class InterviewDataCollector:
    """Collects all interview data from various sources"""
    
    def __init__(self):
        self.interview_data = {
            "resume_text": "",
            "transcript": "",
            "events": [],
            "expressions": [],
            "interview_metadata": {}
        }
    
    def collect_resume_text(self) -> str:
        """Extract text from resume"""
        try:
            import pdfplumber
            
            # Try uploaded resume first, fallback to sample
            resume_file = RESUME_PATH if os.path.exists(RESUME_PATH) else FALLBACK_RESUME
            
            if not os.path.exists(resume_file):
                logger.warning(f"Resume file not found: {resume_file}")
                return "Resume not available"
            
            text = ""
            with pdfplumber.open(resume_file) as pdf:
                for page in pdf.pages:
                    text += page.extract_text() + "\n"
            
            self.interview_data["resume_text"] = text
            logger.info(f"Successfully extracted resume text from {resume_file}")
            return text
            
        except Exception as e:
            logger.error(f"Error extracting resume text: {e}")
            return "Resume extraction failed"
    
    def collect_events(self) -> List[Dict]:
        """Load events from events.json"""
        try:
            if not os.path.exists(EVENTS_PATH):
                logger.warning(f"Events file not found: {EVENTS_PATH}")
                return []
            
            events = []
            with open(EVENTS_PATH, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            events.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
            
            self.interview_data["events"] = events
            logger.info(f"Loaded {len(events)} events")
            return events
            
        except Exception as e:
            logger.error(f"Error loading events: {e}")
            return []
    
    def collect_expressions(self) -> List[Dict]:
        """Load expressions from expressions.log"""
        try:
            if not os.path.exists(EXPRESSIONS_PATH):
                logger.warning(f"Expressions file not found: {EXPRESSIONS_PATH}")
                return []
            
            expressions = []
            with open(EXPRESSIONS_PATH, "r") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try:
                            expressions.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
            
            self.interview_data["expressions"] = expressions
            logger.info(f"Loaded {len(expressions)} expression records")
            return expressions
            
        except Exception as e:
            logger.error(f"Error loading expressions: {e}")
            return []
    
    def collect_session_data(self, session_service, app_name: str, user_id: str, session_id: str) -> List[Dict]:
        """Collect interview conversation from saved conversation file with deduplication"""
        try:
            # Try to read from the saved conversation file first
            if os.path.exists(CONVERSATION_PATH):
                logger.info(f"Reading conversation from {CONVERSATION_PATH}")
                with open(CONVERSATION_PATH, "r") as f:
                    conversation = json.load(f)
                
                # Remove duplicates from conversation
                deduplicated_conversation = self._deduplicate_conversation(conversation)
                
                if len(deduplicated_conversation) != len(conversation):
                    logger.info(f"Removed {len(conversation) - len(deduplicated_conversation)} duplicate entries")
                    conversation = deduplicated_conversation
                
                # Format as transcript
                transcript = ""
                for item in conversation:
                    role = "AI Interviewer" if item.get("role") == "model" else "Candidate"
                    transcript += f"{role}: {item.get('text', '')}\n\n"
                
                self.interview_data["transcript"] = transcript
                self.interview_data["conversation"] = conversation
                
                logger.info(f"Collected {len(conversation)} unique conversation turns from file")
                return conversation
            else:
                logger.warning(f"Conversation file not found: {CONVERSATION_PATH}")
                
                # Fallback: try to get from session service
                if session_service is not None:
                    logger.info("Attempting to get conversation from session service")
                    try:
                        # Try synchronous access if available
                        if hasattr(session_service, 'get_session'):
                            session = session_service.get_session(
                                app_name=app_name, 
                                user_id=user_id, 
                                session_id=session_id
                            )
                            
                            conversation = []
                            if session and hasattr(session, 'events'):
                                for event in session.events:
                                    try:
                                        if event.content and event.content.parts and event.content.parts[0].text:
                                            conversation.append({
                                                "role": event.content.role,
                                                "text": event.content.parts[0].text,
                                                "timestamp": str(getattr(event, 'timestamp', ''))
                                            })
                                    except Exception as event_error:
                                        logger.warning(f"Error processing event: {event_error}")
                                        continue
                            
                            if conversation:
                                # Remove duplicates
                                conversation = self._deduplicate_conversation(conversation)
                                
                                # Format as transcript
                                transcript = ""
                                for item in conversation:
                                    role = "AI Interviewer" if item.get("role") == "model" else "Candidate"
                                    transcript += f"{role}: {item.get('text', '')}\n\n"
                                
                                self.interview_data["transcript"] = transcript
                                self.interview_data["conversation"] = conversation
                                
                                logger.info(f"Collected {len(conversation)} unique conversation turns from session service")
                                return conversation
                    except Exception as session_error:
                        logger.error(f"Error getting conversation from session service: {session_error}")
                
                return []
            
        except Exception as e:
            logger.error(f"Error collecting session data: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def _deduplicate_conversation(self, conversation: List[Dict]) -> List[Dict]:
        """Remove duplicate conversation entries based on role, text, and timestamp"""
        seen = set()
        deduplicated = []
        
        for item in conversation:
            # Create a signature for deduplication
            signature = f"{item.get('role', '')}_{item.get('text', '')}_{item.get('timestamp', '')}"
            
            if signature not in seen:
                seen.add(signature)
                deduplicated.append(item)
        
        return deduplicated
    
    def calculate_statistics(self) -> Dict:
        """Calculate interview statistics"""
        events = self.interview_data["events"]
        expressions = self.interview_data["expressions"]
        conversation = self.interview_data.get("conversation", [])
        
        stats = {
            "total_questions": 0,
            "total_responses": 0,
            "interview_duration": 0,
            "event_counts": {},
            "expression_analysis": {}
        }
        
        # Count questions and responses
        for item in conversation:
            if item["role"] == "model":
                stats["total_questions"] += 1
            else:
                stats["total_responses"] += 1
        
        # Calculate duration
        if expressions:
            stats["interview_duration"] = expressions[-1].get("timestamp", 0) - expressions[0].get("timestamp", 0)
        
        # Count events
        event_counts = {}
        for event in events:
            event_type = event.get("event", "unknown")
            event_counts[event_type] = event_counts.get(event_type, 0) + 1
        stats["event_counts"] = event_counts
        
        # Expression analysis
        if expressions:
            total_frames = len(expressions)
            blink_count = sum(1 for exp in expressions if "blink" in str(exp.get("blendshapes", {})).lower())
            smile_count = sum(1 for exp in expressions if "smile" in str(exp.get("blendshapes", {})).lower())
            
            stats["expression_analysis"] = {
                "total_frames": total_frames,
                "blink_frequency": blink_count / total_frames if total_frames > 0 else 0,
                "smile_frequency": smile_count / total_frames if total_frames > 0 else 0
            }
        
        self.interview_data["interview_metadata"] = stats
        return stats
    
    def collect_all_data(self, session_service=None, app_name: str = "", user_id: str = "", session_id: str = "") -> Dict:
        """Collect all interview data"""
        logger.info("Starting data collection for interview report")
        
        self.collect_resume_text()
        self.collect_events()
        self.collect_expressions()
        
        if session_service and app_name and user_id and session_id:
            self.collect_session_data(session_service, app_name, user_id, session_id)
        
        self.calculate_statistics()
        
        logger.info("Data collection completed")
        return self.interview_data


class ReportGenerator:
    """Generates comprehensive interview reports using AI"""
    
    def __init__(self, llm_agent=None):
        self.data_collector = InterviewDataCollector()
        self.llm_agent = llm_agent
    
    def generate_report(self, session_service=None, app_name: str = "", user_id: str = "", session_id: str = "") -> str:
        """Generate comprehensive interview report"""
        try:
            # Collect all interview data
            interview_data = self.data_collector.collect_all_data(
                session_service, app_name, user_id, session_id
            )
            
            # Generate report using AI agent if available, otherwise use template
            if self.llm_agent:
                report = self._generate_ai_analysis_report(interview_data)
            else:
                report = self._create_enhanced_report(interview_data)
            
            return report
            
        except Exception as e:
            logger.error(f"Error generating report: {e}")
            return self._generate_error_report(str(e))
    
    def _generate_ai_analysis_report(self, interview_data: Dict) -> str:
        """Generate report using AI agent for actual analysis"""
        try:
            # This would integrate with the LLM agent for sophisticated analysis
            # For now, we'll use enhanced template with actual data analysis
            return self._create_enhanced_report(interview_data)
        except Exception as e:
            logger.error(f"Error in AI analysis: {e}")
            return self._create_enhanced_report(interview_data)
    
    def _create_enhanced_report(self, data: Dict) -> str:
        """Create enhanced report with actual data analysis instead of placeholders"""
        
        stats = data.get("interview_metadata", {})
        events = data.get("events", [])
        conversation = data.get("conversation", [])
        resume_text = data.get("resume_text", "")
        
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Perform actual analysis based on collected data
        analysis = self._perform_data_analysis(data)
        
        report = f"""
# AI-ASSISTED INTERVIEW EVALUATION REPORT

Generated: {current_time}
Interview ID: INT-{datetime.now().strftime("%Y%m%d%H%M%S")}

---

## 1. CANDIDATE INFORMATION

- **Interview Date/Time**: {current_time}
- **Interview Duration**: {stats.get('interview_duration', 0):.2f} seconds ({stats.get('interview_duration', 0)/60:.2f} minutes)
- **Position/Role**: Technical Interview
- **Interview ID**: INT-{datetime.now().strftime("%Y%m%d%H%M%S")}

---

## 2. INTERVIEW OVERVIEW

This interview was conducted to evaluate the candidate's technical skills, communication abilities, and overall fit for the position. The AI interviewer asked {stats.get('total_questions', 0)} questions based on the candidate's resume, covering various technical and behavioral aspects. The candidate provided {stats.get('total_responses', 0)} responses during the interview.

**Overall Assessment**: {analysis['overall_assessment']}

---

## 3. INTERVIEW STATISTICS

- **Total Questions Asked**: {stats.get('total_questions', 0)}
- **Total Responses**: {stats.get('total_responses', 0)}
- **Interview Duration**: {stats.get('interview_duration', 0):.2f} seconds ({stats.get('interview_duration', 0)/60:.2f} minutes)
- **Total Frames Analyzed**: {stats.get('expression_analysis', {}).get('total_frames', 0)}
- **Average Response Time**: {analysis['avg_response_time']:.2f} seconds
- **Questions per Minute**: {analysis['questions_per_minute']:.2f}

### Event Summary
"""
        
        # Add event counts
        event_counts = stats.get('event_counts', {})
        if event_counts:
            for event_type, count in event_counts.items():
                report += f"- **{event_type}**: {count}\n"
        else:
            report += "- No events detected\n"
        
        report += f"""
### Expression Analysis
- **Total Frames**: {stats.get('expression_analysis', {}).get('total_frames', 0)}
- **Blink Frequency**: {stats.get('expression_analysis', {}).get('blink_frequency', 0):.4f}
- **Smile Frequency**: {stats.get('expression_analysis', {}).get('smile_frequency', 0):.4f}

---

## 4. QUESTION-BY-QUESTION EVALUATION

"""
        
        # Add conversation analysis
        if conversation:
            for i, item in enumerate(conversation, 1):
                role = "AI Interviewer" if item["role"] == "model" else "Candidate"
                report += f"### Exchange {i}\n\n"
                report += f"**{role}**: {item['text']}\n\n"
                
                if item["role"] == "user":
                    # Add basic analysis for candidate responses
                    response_analysis = self._analyze_response(item['text'], i)
                    report += f"**Evaluation**: {response_analysis['overall']}\n\n"
                    report += f"**Relevance**: {response_analysis['relevance']}\n\n"
                    report += f"**Clarity**: {response_analysis['clarity']}\n\n"
                    report += f"**Length**: {response_analysis['length']}\n\n"
        else:
            report += "No conversation data available.\n\n"
        
        report += f"""
---

## 5. TECHNICAL KNOWLEDGE ASSESSMENT

Based on the interview questions and responses, the following technical areas were evaluated:

{analysis['technical_assessment']}

---

## 6. COMMUNICATION ANALYSIS

### Speech Analysis
- **Clarity**: {analysis['communication_analysis']['clarity']}
- **Answer Structure**: {analysis['communication_analysis']['structure']}
- **Relevance**: {analysis['communication_analysis']['relevance']}
- **Conciseness**: {analysis['communication_analysis']['conciseness']}
- **Overall Communication**: {analysis['communication_analysis']['overall']}

### Communication Metrics
- **Average Response Length**: {analysis['communication_analysis']['avg_length']:.2f} characters
- **Response Variance**: {analysis['communication_analysis']['length_variance']:.2f}
- **Filler Words Detected**: {analysis['communication_analysis']['filler_words']}

---

## 7. VIDEO AND NON-VERBAL BEHAVIOR ANALYSIS

### Eye Contact Analysis
"""
        
        # Add eye contact analysis from events
        look_events = [e for e in events if "LOOK" in e.get("event", "")]
        if look_events:
            report += f"- **Total Eye Contact Events**: {len(look_events)}\n"
            look_forward = len([e for e in look_events if "FORWARD" in e.get("event", "")])
            look_away = len([e for e in look_events if "AWAY" in e.get("event", "")])
            look_down = len([e for e in look_events if "DOWN" in e.get("event", "")])
            
            total_looks = len(look_events)
            if total_looks > 0:
                forward_percentage = (look_forward / total_looks) * 100
                report += f"- **Eye Contact Maintenance**: {forward_percentage:.1f}% of detected looks were forward\n"
                report += f"- **Looking Away**: {look_away} times\n"
                report += f"- **Looking Down**: {look_down} times\n"
            
            for event in look_events[:5]:  # Show first 5 events
                report += f"  - {event.get('event')} at {event.get('hms', 'N/A')}\n"
        else:
            report += "- No eye contact events detected\n"
        
        report += """
### Facial Expression Analysis
"""
        
        # Add expression analysis
        smile_events = [e for e in events if "SMILE" in e.get("event", "")]
        blink_events = [e for e in events if "BLINK" in e.get("event", "")]
        
        report += f"- **Smile Events**: {len(smile_events)}\n"
        report += f"- **Blink Events**: {len(blink_events)}\n"
        
        brow_events = [e for e in events if "BROW" in e.get("event", "")]
        report += f"- **Brow Movement Events**: {len(brow_events)}\n"
        
        speaking_events = [e for e in events if "SPEAKING" in e.get("event", "")]
        report += f"- **Speaking Events**: {len(speaking_events)}\n"
        
        report += f"""
### Non-Verbal Behavior Summary
{analysis['non_verbal_analysis']}

*Note: These are detected physical movements. No psychological conclusions about emotions, honesty, or mental state should be drawn from facial expression data alone.*

---

## 8. RESUME-TO-INTERVIEW CONSISTENCY

### Resume Analysis
"""
        
        # Add basic resume info
        if resume_text and resume_text != "Resume not available":
            resume_analysis = self._analyze_resume(resume_text)
            report += f"Resume text was successfully extracted and analyzed.\n\n"
            report += f"**Key Skills Mentioned**: {resume_analysis['skills']}\n\n"
            report += f"**Projects Listed**: {resume_analysis['projects']}\n\n"
            report += f"**Experience Summary**: {resume_analysis['experience']}\n\n"
        else:
            report += "Resume data not available for comparison.\n\n"
        
        report += f"""
### Consistency Analysis
{analysis['resume_consistency']}

---

## 9. CANDIDATE STRENGTHS

Based on the interview observations:

{analysis['strengths']}

---

## 10. AREAS FOR IMPROVEMENT

{analysis['improvements']}

---

## 11. PERFORMANCE SUMMARY

### Category-wise Assessment

| Category | Score | Assessment |
|----------|-------|------------|
| Technical Knowledge | {analysis['scores']['technical']}/10 | {analysis['scores']['technical_assessment']} |
| Problem Solving | {analysis['scores']['problem_solving']}/10 | {analysis['scores']['problem_solving_assessment']} |
| Communication | {analysis['scores']['communication']}/10 | {analysis['scores']['communication_assessment']} |
| Answer Relevance | {analysis['scores']['relevance']}/10 | {analysis['scores']['relevance_assessment']} |
| Technical Explanation | {analysis['scores']['explanation']}/10 | {analysis['scores']['explanation_assessment']} |
| Resume Consistency | {analysis['scores']['resume']}/10 | {analysis['scores']['resume_assessment']} |

### Overall Performance Score: {analysis['scores']['overall']}/10

---

## 12. INTERVIEW EVENT TIMELINE

"""
        
        # Add event timeline
        if events:
            report += "### Chronological Event Log\n\n"
            for event in events[:20]:  # Show first 20 events
                timestamp = event.get('hms', event.get('timestamp', 'N/A'))
                event_type = event.get('event', 'Unknown')
                report += f"- **{timestamp}**: {event_type}\n"
            
            if len(events) > 20:
                report += f"- ... and {len(events) - 20} more events\n"
        else:
            report += "No events recorded.\n"
        
        report += """

---

## 13. COMPLETE INTERVIEW TRANSCRIPT

"""
        
        # Add full transcript
        if conversation:
            for item in conversation:
                role = "AI Interviewer" if item["role"] == "model" else "Candidate"
                report += f"**{role}**: {item['text']}\n\n"
        else:
            report += "No transcript available.\n"
        
        report += f"""
---

## 14. FINAL INTERVIEW SUMMARY

### Executive Summary

{analysis['executive_summary']}

### Key Observations
{analysis['key_observations']}

### Recommendations for Further Evaluation
{analysis['recommendations']}

### Important Notes

- This report is AI-assisted and should be reviewed by human recruiters
- No automatic hiring/rejection decisions should be made based solely on this report
- Facial expression data shows physical movements only, not emotional states
- Resume inconsistencies may require clarification rather than automatic rejection
- This report provides evidence-based observations to support human decision-making

---

**Report End**

*Generated by AI Interview Assistant - VEERA*
*For questions about this report, please contact the recruiting team.*
"""
        
        return report
    
    def _perform_data_analysis(self, data: Dict) -> Dict:
        """Perform actual data analysis instead of placeholders"""
        conversation = data.get("conversation", [])
        events = data.get("events", [])
        stats = data.get("interview_metadata", {})
        
        analysis = {
            'overall_assessment': '',
            'avg_response_time': 0,
            'questions_per_minute': 0,
            'technical_assessment': '',
            'communication_analysis': {},
            'non_verbal_analysis': '',
            'resume_consistency': '',
            'strengths': '',
            'improvements': '',
            'scores': {},
            'executive_summary': '',
            'key_observations': '',
            'recommendations': ''
        }
        
        # Calculate basic metrics
        duration = stats.get('interview_duration', 0)
        total_questions = stats.get('total_questions', 0)
        total_responses = stats.get('total_responses', 0)
        
        if duration > 0:
            analysis['avg_response_time'] = duration / max(total_responses, 1)
            analysis['questions_per_minute'] = (total_questions / duration) * 60 if duration > 0 else 0
        
        # Analyze conversation content
        if conversation:
            candidate_responses = [item for item in conversation if item.get("role") == "user"]
            response_lengths = [len(item.get("text", "")) for item in candidate_responses]
            
            if response_lengths:
                avg_length = sum(response_lengths) / len(response_lengths)
                length_variance = sum((x - avg_length) ** 2 for x in response_lengths) / len(response_lengths)
            else:
                avg_length = 0
                length_variance = 0
            
            # Communication analysis
            analysis['communication_analysis'] = {
                'clarity': self._assess_clarity(candidate_responses),
                'structure': self._assess_structure(candidate_responses),
                'relevance': self._assess_relevance(candidate_responses),
                'conciseness': self._assess_conciseness(candidate_responses),
                'overall': self._assess_overall_communication(candidate_responses),
                'avg_length': avg_length,
                'length_variance': length_variance,
                'filler_words': self._count_filler_words(candidate_responses)
            }
        
        # Technical assessment based on conversation
        analysis['technical_assessment'] = self._assess_technical_knowledge(conversation)
        
        # Non-verbal analysis
        analysis['non_verbal_analysis'] = self._analyze_non_verbal_behavior(events)
        
        # Resume consistency
        analysis['resume_consistency'] = self._assess_resume_consistency(data)
        
        # Strengths and improvements
        analysis['strengths'] = self._identify_strengths(data)
        analysis['improvements'] = self._identify_improvements(data)
        
        # Scores
        analysis['scores'] = self._calculate_scores(data)
        
        # Overall assessment
        analysis['overall_assessment'] = self._generate_overall_assessment(data)
        
        # Executive summary
        analysis['executive_summary'] = self._generate_executive_summary(data)
        
        # Key observations
        analysis['key_observations'] = self._generate_key_observations(data)
        
        # Recommendations
        analysis['recommendations'] = self._generate_recommendations(data)
        
        return analysis
    
    def _assess_clarity(self, responses: List[Dict]) -> str:
        """Assess clarity of responses"""
        if not responses:
            return "Unable to assess - no responses"
        
        avg_length = sum(len(r.get("text", "")) for r in responses) / len(responses)
        
        if avg_length < 20:
            return "Responses are very brief and may lack detail"
        elif avg_length < 50:
            return "Responses are concise but could benefit from more elaboration"
        elif avg_length < 150:
            return "Responses show good clarity and appropriate length"
        else:
            return "Responses are detailed and comprehensive"
    
    def _assess_structure(self, responses: List[Dict]) -> str:
        """Assess answer structure"""
        if not responses:
            return "Unable to assess - no responses"
        
        structured_count = sum(1 for r in responses if any(word in r.get("text", "").lower() for word in ["first", "then", "finally", "because", "therefore", "however"]))
        
        if structured_count > len(responses) * 0.5:
            return "Good use of structured language and logical flow"
        elif structured_count > len(responses) * 0.25:
            return "Moderate structure in responses"
        else:
            return "Responses could benefit from better organization"
    
    def _assess_relevance(self, responses: List[Dict]) -> str:
        """Assess relevance of responses"""
        if not responses:
            return "Unable to assess - no responses"
        
        # Basic relevance check based on response length and variety
        avg_length = sum(len(r.get("text", "")) for r in responses) / len(responses)
        
        if avg_length > 10:
            return "Responses appear relevant to questions asked"
        else:
            return "Some responses may lack relevance or detail"
    
    def _assess_conciseness(self, responses: List[Dict]) -> str:
        """Assess conciseness of responses"""
        if not responses:
            return "Unable to assess - no responses"
        
        avg_length = sum(len(r.get("text", "")) for r in responses) / len(responses)
        
        if avg_length < 30:
            return "Very concise responses"
        elif avg_length < 80:
            return "Good balance of conciseness and detail"
        else:
            return "Responses could be more concise"
    
    def _assess_overall_communication(self, responses: List[Dict]) -> str:
        """Assess overall communication"""
        if not responses:
            return "Unable to assess - no responses"
        
        avg_length = sum(len(r.get("text", "")) for r in responses) / len(responses)
        
        if avg_length > 20 and avg_length < 150:
            return "Good overall communication skills demonstrated"
        elif avg_length >= 150:
            return "Detailed communicator, could work on conciseness"
        else:
            return "Communication could be improved with more detailed responses"
    
    def _count_filler_words(self, responses: List[Dict]) -> int:
        """Count filler words in responses"""
        filler_words = ["um", "uh", "like", "you know", "basically", "actually"]
        count = 0
        
        for response in responses:
            text = response.get("text", "").lower()
            for filler in filler_words:
                count += text.count(filler)
        
        return count
    
    def _assess_technical_knowledge(self, conversation: List[Dict]) -> str:
        """Assess technical knowledge from conversation"""
        if not conversation:
            return "Unable to assess - no conversation data"
        
        technical_keywords = ["algorithm", "data structure", "programming", "code", "software", "development", "api", "database", "framework", "language", "system", "architecture"]
        
        technical_mentions = 0
        for item in conversation:
            text = item.get("text", "").lower()
            for keyword in technical_keywords:
                if keyword in text:
                    technical_mentions += 1
        
        if technical_mentions > 5:
            return "Strong technical knowledge demonstrated through relevant terminology and concepts"
        elif technical_mentions > 2:
            return "Moderate technical knowledge shown"
        else:
            return "Limited technical discussion observed"
    
    def _analyze_non_verbal_behavior(self, events: List[Dict]) -> str:
        """Analyze non-verbal behavior from events"""
        if not events:
            return "No non-verbal behavior data available"
        
        look_events = [e for e in events if "LOOK" in e.get("event", "")]
        smile_events = [e for e in events if "SMILE" in e.get("event", "")]
        blink_events = [e for e in events if "BLINK" in e.get("event", "")]
        
        analysis = []
        
        if look_events:
            forward_looks = len([e for e in look_events if "FORWARD" in e.get("event", "")])
            total_looks = len(look_events)
            forward_percentage = (forward_looks / total_looks) * 100 if total_looks > 0 else 0
            analysis.append(f"Eye contact was maintained approximately {forward_percentage:.1f}% of the time when gaze direction was detected")
        
        if smile_events:
            analysis.append(f"{len(smile_events)} smile events detected during the interview")
        
        if blink_events:
            analysis.append(f"{len(blink_events)} blink events recorded (normal blinking pattern)")
        
        return ". ".join(analysis) if analysis else "Limited non-verbal behavior data collected"
    
    def _assess_resume_consistency(self, data: Dict) -> str:
        """Assess consistency between resume and interview performance"""
        conversation = data.get("conversation", [])
        resume_text = data.get("resume_text", "")
        
        if not conversation or not resume_text:
            return "Unable to assess consistency - missing data"
        
        # Basic consistency check
        candidate_responses = [item for item in conversation if item.get("role") == "user"]
        response_quality = sum(len(r.get("text", "")) for r in candidate_responses) / max(len(candidate_responses), 1)
        
        if response_quality > 50:
            return "Candidate provided detailed responses that support resume claims"
        elif response_quality > 20:
            return "Candidate provided moderate responses; some resume claims may need verification"
        else:
            return "Limited response detail; resume claims require further verification through additional assessment"
    
    def _identify_strengths(self, data: Dict) -> str:
        """Identify candidate strengths"""
        conversation = data.get("conversation", [])
        events = data.get("events", [])
        
        strengths = []
        
        if conversation:
            candidate_responses = [item for item in conversation if item.get("role") == "user"]
            if len(candidate_responses) > 3:
                strengths.append("- Active participation with multiple responses")
            
            avg_response_length = sum(len(r.get("text", "")) for r in candidate_responses) / max(len(candidate_responses), 1)
            if avg_response_length > 30:
                strengths.append("- Provides detailed responses to questions")
        
        if events:
            look_events = [e for e in events if "LOOK" in e.get("event", "")]
            if look_events:
                forward_looks = len([e for e in look_events if "FORWARD" in e.get("event", "")])
                if forward_looks > len(look_events) * 0.5:
                    strengths.append("- Maintained good eye contact during interview")
        
        return "\n".join(strengths) if strengths else "- Limited data to identify specific strengths"
    
    def _identify_improvements(self, data: Dict) -> str:
        """Identify areas for improvement"""
        conversation = data.get("conversation", [])
        
        improvements = []
        
        if conversation:
            candidate_responses = [item for item in conversation if item.get("role") == "user"]
            avg_response_length = sum(len(r.get("text", "")) for r in candidate_responses) / max(len(candidate_responses), 1)
            
            if avg_response_length < 20:
                improvements.append("- Provide more detailed responses to demonstrate knowledge")
            elif avg_response_length > 200:
                improvements.append("- Work on being more concise in responses")
            
            # Check for very short responses
            short_responses = sum(1 for r in candidate_responses if len(r.get("text", "")) < 10)
            if short_responses > len(candidate_responses) * 0.3:
                improvements.append("- Avoid very brief responses; elaborate more on answers")
        
        return "\n".join(improvements) if improvements else "- No specific improvement areas identified from available data"
    
    def _calculate_scores(self, data: Dict) -> Dict:
        """Calculate performance scores"""
        conversation = data.get("conversation", [])
        events = data.get("events", [])
        
        scores = {
            'technical': 5,
            'technical_assessment': 'Moderate',
            'problem_solving': 5,
            'problem_solving_assessment': 'Moderate',
            'communication': 5,
            'communication_assessment': 'Moderate',
            'relevance': 5,
            'relevance_assessment': 'Moderate',
            'explanation': 5,
            'explanation_assessment': 'Moderate',
            'resume': 5,
            'resume_assessment': 'Moderate',
            'overall': 5
        }
        
        if conversation:
            candidate_responses = [item for item in conversation if item.get("role") == "user"]
            avg_response_length = sum(len(r.get("text", "")) for r in candidate_responses) / max(len(candidate_responses), 1)
            
            # Communication score based on response quality
            if avg_response_length > 50:
                scores['communication'] = 7
                scores['communication_assessment'] = 'Good'
            elif avg_response_length > 30:
                scores['communication'] = 6
                scores['communication_assessment'] = 'Above Average'
            elif avg_response_length > 20:
                scores['communication'] = 5
                scores['communication_assessment'] = 'Average'
            else:
                scores['communication'] = 4
                scores['communication_assessment'] = 'Below Average'
            
            # Relevance score
            if avg_response_length > 20:
                scores['relevance'] = 6
                scores['relevance_assessment'] = 'Good'
            else:
                scores['relevance'] = 4
                scores['relevance_assessment'] = 'Needs Improvement'
        
        if events:
            look_events = [e for e in events if "LOOK" in e.get("event", "")]
            if look_events:
                forward_looks = len([e for e in look_events if "FORWARD" in e.get("event", "")])
                forward_percentage = (forward_looks / len(look_events)) * 100
                
                if forward_percentage > 60:
                    scores['communication'] = min(scores['communication'] + 1, 10)
        
        # Calculate overall score
        scores['overall'] = round((scores['technical'] + scores['problem_solving'] + scores['communication'] + scores['relevance'] + scores['explanation'] + scores['resume']) / 6)
        
        return scores
    
    def _analyze_response(self, text: str, question_num: int) -> Dict:
        """Analyze individual response"""
        length = len(text)
        
        analysis = {
            'overall': '',
            'relevance': '',
            'clarity': '',
            'length': f"{length} characters"
        }
        
        if length < 10:
            analysis['overall'] = "Very brief response"
            analysis['relevance'] = "May lack sufficient detail"
            analysis['clarity'] = "Clear but too brief"
        elif length < 30:
            analysis['overall'] = "Brief response"
            analysis['relevance'] = "Adequate but could be more detailed"
            analysis['clarity'] = "Clear and concise"
        elif length < 100:
            analysis['overall'] = "Good response length"
            analysis['relevance'] = "Relevant and appropriately detailed"
            analysis['clarity'] = "Clear and well-structured"
        else:
            analysis['overall'] = "Detailed response"
            analysis['relevance'] = "Comprehensive and relevant"
            analysis['clarity'] = "Detailed and clear"
        
        return analysis
    
    def _analyze_resume(self, resume_text: str) -> Dict:
        """Basic resume analysis"""
        analysis = {
            'skills': 'Various technical skills mentioned',
            'projects': 'Multiple projects listed',
            'experience': 'Experience details available'
        }
        
        # Extract basic information
        if resume_text:
            # Look for common sections
            if 'skill' in resume_text.lower():
                analysis['skills'] = 'Skills section identified in resume'
            if 'project' in resume_text.lower():
                analysis['projects'] = 'Projects section identified in resume'
            if 'experience' in resume_text.lower() or 'work' in resume_text.lower():
                analysis['experience'] = 'Work/experience section identified in resume'
        
        return analysis
    
    def _generate_overall_assessment(self, data: Dict) -> str:
        """Generate overall assessment"""
        conversation = data.get("conversation", [])
        stats = data.get("interview_metadata", {})
        
        total_questions = stats.get('total_questions', 0)
        total_responses = stats.get('total_responses', 0)
        
        if total_responses >= total_questions * 0.8:
            return "Candidate actively participated in the interview with good response rate"
        elif total_responses >= total_questions * 0.5:
            return "Candidate participated moderately in the interview"
        else:
            return "Limited participation observed during interview"
    
    def _generate_executive_summary(self, data: Dict) -> str:
        """Generate executive summary"""
        conversation = data.get("conversation", [])
        stats = data.get("interview_metadata", {})
        
        total_questions = stats.get('total_questions', 0)
        duration = stats.get('interview_duration', 0)
        
        summary = f"The interview consisted of {total_questions} questions over {duration/60:.1f} minutes. "
        
        if conversation:
            candidate_responses = [item for item in conversation if item.get("role") == "user"]
            avg_length = sum(len(r.get("text", "")) for r in candidate_responses) / max(len(candidate_responses), 1)
            
            if avg_length > 50:
                summary += "The candidate provided detailed responses and demonstrated good communication skills. "
            elif avg_length > 20:
                summary += "The candidate provided moderate responses with room for improvement in detail. "
            else:
                summary += "The candidate provided brief responses that could benefit from more elaboration. "
        else:
            summary += "Limited conversation data available for detailed assessment. "
        
        return summary
    
    def _generate_key_observations(self, data: Dict) -> str:
        """Generate key observations"""
        observations = []
        
        conversation = data.get("conversation", [])
        if conversation:
            candidate_responses = [item for item in conversation if item.get("role") == "user"]
            observations.append(f"- Candidate provided {len(candidate_responses)} responses during the interview")
            
            avg_length = sum(len(r.get("text", "")) for r in candidate_responses) / max(len(candidate_responses), 1)
            observations.append(f"- Average response length: {avg_length:.1f} characters")
        
        events = data.get("events", [])
        if events:
            look_events = [e for e in events if "LOOK" in e.get("event", "")]
            if look_events:
                forward_looks = len([e for e in look_events if "FORWARD" in e.get("event", "")])
                observations.append(f"- Eye contact maintained: {forward_looks} forward looks out of {len(look_events)} total")
        
        return "\n".join(observations) if observations else "- Limited data for detailed observations"
    
    def _generate_recommendations(self, data: Dict) -> str:
        """Generate recommendations"""
        recommendations = [
            "- Consider conducting a follow-up technical interview to assess deeper knowledge",
            "- Evaluate practical skills through coding exercises or project discussions",
            "- Assess team fit through behavioral interviews and team interaction",
            "- Verify resume claims through reference checks and skill verification"
        ]
        
        conversation = data.get("conversation", [])
        if conversation:
            candidate_responses = [item for item in conversation if item.get("role") == "user"]
            avg_length = sum(len(r.get("text", "")) for r in candidate_responses) / max(len(candidate_responses), 1)
            
            if avg_length < 30:
                recommendations.insert(0, "- Encourage candidate to provide more detailed responses in future interviews")
            elif avg_length > 150:
                recommendations.insert(0, "- Work with candidate on being more concise in communication")
        
        return "\n".join(recommendations)
    
    def _create_report_template(self, data: Dict) -> str:
        """Create structured report template with collected data"""
        
        stats = data.get("interview_metadata", {})
        events = data.get("events", [])
        conversation = data.get("conversation", [])
        resume_text = data.get("resume_text", "")
        
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        report = f"""
# AI-ASSISTED INTERVIEW EVALUATION REPORT

Generated: {current_time}
Interview ID: INT-{datetime.now().strftime("%Y%m%d%H%M%S")}

---

## 1. CANDIDATE INFORMATION

- **Interview Date/Time**: {current_time}
- **Interview Duration**: {stats.get('interview_duration', 0):.2f} seconds
- **Position/Role**: To be specified
- **Interview ID**: INT-{datetime.now().strftime("%Y%m%d%H%M%S")}

---

## 2. INTERVIEW OVERVIEW

This interview was conducted to evaluate the candidate's technical skills, communication abilities, and overall fit for the position. The AI interviewer asked questions based on the candidate's resume, covering various technical and behavioral aspects.

---

## 3. INTERVIEW STATISTICS

- **Total Questions Asked**: {stats.get('total_questions', 0)}
- **Total Responses**: {stats.get('total_responses', 0)}
- **Interview Duration**: {stats.get('interview_duration', 0):.2f} seconds ({stats.get('interview_duration', 0)/60:.2f} minutes)
- **Total Frames Analyzed**: {stats.get('expression_analysis', {}).get('total_frames', 0)}

### Event Summary
"""
        
        # Add event counts
        event_counts = stats.get('event_counts', {})
        if event_counts:
            for event_type, count in event_counts.items():
                report += f"- **{event_type}**: {count}\n"
        else:
            report += "- No events detected\n"
        
        report += f"""
### Expression Analysis
- **Total Frames**: {stats.get('expression_analysis', {}).get('total_frames', 0)}
- **Blink Frequency**: {stats.get('expression_analysis', {}).get('blink_frequency', 0):.4f}
- **Smile Frequency**: {stats.get('expression_analysis', {}).get('smile_frequency', 0):.4f}

---

## 4. QUESTION-BY-QUESTION EVALUATION

"""
        
        # Add conversation analysis
        if conversation:
            for i, item in enumerate(conversation, 1):
                role = "AI Interviewer" if item["role"] == "model" else "Candidate"
                report += f"### Exchange {i}\n\n"
                report += f"**{role}**: {item['text']}\n\n"
                
                if item["role"] == "user":
                    report += f"**Evaluation**: Pending detailed analysis\n\n"
                    report += f"**Relevance**: To be evaluated\n\n"
                    report += f"**Technical Correctness**: To be evaluated\n\n"
                    report += f"**Completeness**: To be evaluated\n\n"
                    report += f"**Clarity**: To be evaluated\n\n"
        else:
            report += "No conversation data available.\n\n"
        
        report += """
---

## 5. TECHNICAL KNOWLEDGE ASSESSMENT

Based on the interview questions and responses, the following technical areas were evaluated:

- **Programming Languages**: To be evaluated from responses
- **Data Structures & Algorithms**: To be evaluated from responses  
- **Databases**: To be evaluated from responses
- **Frameworks & Tools**: To be evaluated from responses
- **Domain Knowledge**: To be evaluated from responses

*Note: This section requires detailed AI analysis of the conversation content.*

---

## 6. COMMUNICATION ANALYSIS

### Speech Analysis
- **Clarity**: To be analyzed from transcript
- **Answer Structure**: To be evaluated
- **Relevance**: To be evaluated
- **Conciseness**: To be evaluated
- **Speaking Pace**: To be analyzed
- **Filler Words**: To be analyzed
- **Overall Communication**: To be evaluated

*Note: This section requires detailed analysis of the audio/transcript data.*

---

## 7. VIDEO AND NON-VERBAL BEHAVIOR ANALYSIS

### Eye Contact Analysis
"""
        
        # Add eye contact analysis from events
        look_events = [e for e in events if "LOOK" in e.get("event", "")]
        if look_events:
            report += f"- **Total Eye Contact Events**: {len(look_events)}\n"
            for event in look_events[:5]:  # Show first 5 events
                report += f"  - {event.get('event')} at {event.get('hms', 'N/A')}\n"
        else:
            report += "- No eye contact events detected\n"
        
        report += """
### Facial Expression Analysis
"""
        
        # Add expression analysis
        smile_events = [e for e in events if "SMILE" in e.get("event", "")]
        blink_events = [e for e in events if "BLINK" in e.get("event", "")]
        
        report += f"- **Smile Events**: {len(smile_events)}\n"
        report += f"- **Blink Events**: {len(blink_events)}\n"
        
        brow_events = [e for e in events if "BROW" in e.get("event", "")]
        report += f"- **Brow Movement Events**: {len(brow_events)}\n"
        
        speaking_events = [e for e in events if "SPEAKING" in e.get("event", "")]
        report += f"- **Speaking Events**: {len(speaking_events)}\n"
        
        report += """
*Note: These are detected physical movements. No psychological conclusions about emotions, honesty, or mental state should be drawn from facial expression data alone.*

---

## 8. RESUME-TO-INTERVIEW CONSISTENCY

### Resume Analysis
"""
        
        # Add basic resume info
        if resume_text and resume_text != "Resume not available":
            report += f"Resume text was successfully extracted and analyzed.\n\n"
            report += f"**Key Skills Mentioned in Resume**: To be extracted via AI analysis\n\n"
            report += f"**Projects Listed**: To be extracted via AI analysis\n\n"
            report += f"**Experience**: To be extracted via AI analysis\n\n"
        else:
            report += "Resume data not available for comparison.\n\n"
        
        report += """
### Consistency Analysis
- **Skills Supported by Interview**: To be evaluated
- **Skills Requiring Further Verification**: To be evaluated
- **Areas of Concern**: To be evaluated

*Note: This section requires AI analysis comparing resume claims with interview performance.*

---

## 9. CANDIDATE STRENGTHS

Based on the interview observations:

- **Technical Knowledge**: To be evaluated
- **Communication Skills**: To be evaluated
- **Problem-Solving Ability**: To be evaluated
- **Professionalism**: To be evaluated

*Note: This section requires comprehensive analysis of all interview data.*

---

## 10. AREAS FOR IMPROVEMENT

- **Technical Gaps**: To be identified
- **Communication Enhancement**: To be suggested
- **Answer Structure**: To be improved
- **Knowledge Areas**: To be strengthened

*Note: This section requires detailed analysis with constructive suggestions.*

---

## 11. PERFORMANCE SUMMARY

### Category-wise Assessment

| Category | Score | Assessment |
|----------|-------|------------|
| Technical Knowledge | TBD | To be evaluated |
| Problem Solving | TBD | To be evaluated |
| Communication | TBD | To be evaluated |
| Answer Relevance | TBD | To be evaluated |
| Technical Explanation | TBD | To be evaluated |
| Resume Consistency | TBD | To be evaluated |

*Note: Scores require comprehensive AI analysis with sufficient evidence.*

---

## 12. INTERVIEW EVENT TIMELINE

"""
        
        # Add event timeline
        if events:
            report += "### Chronological Event Log\n\n"
            for event in events[:20]:  # Show first 20 events
                timestamp = event.get('hms', event.get('timestamp', 'N/A'))
                event_type = event.get('event', 'Unknown')
                report += f"- **{timestamp}**: {event_type}\n"
            
            if len(events) > 20:
                report += f"- ... and {len(events) - 20} more events\n"
        else:
            report += "No events recorded.\n"
        
        report += """

---

## 13. COMPLETE INTERVIEW TRANSCRIPT

"""
        
        # Add full transcript
        if conversation:
            for item in conversation:
                role = "AI Interviewer" if item["role"] == "model" else "Candidate"
                report += f"**{role}**: {item['text']}\n\n"
        else:
            report += "No transcript available.\n"
        
        report += """
---

## 14. FINAL INTERVIEW SUMMARY

### Executive Summary

This interview was conducted to evaluate the candidate's technical skills and overall fit for the position. The candidate participated in a structured interview session with AI-generated questions based on their resume.

### Key Observations

- **Demonstrated Strengths**: To be identified through comprehensive analysis
- **Knowledge Gaps**: To be identified through comprehensive analysis
- **Communication Style**: To be analyzed
- **Professional Demeanor**: To be evaluated

### Recommendations for Further Evaluation

- **Technical Assessment**: Consider deep-dive technical interviews
- **Practical Assessment**: Consider coding exercises or project discussions
- **Team Fit**: Consider team culture interviews
- **Reference Checks**: Verify resume claims through references

### Important Notes

- This report is AI-assisted and should be reviewed by human recruiters
- No automatic hiring/rejection decisions should be made based solely on this report
- Facial expression data shows physical movements only, not emotional states
- Resume inconsistencies may require clarification rather than automatic rejection
- This report provides evidence-based observations to support human decision-making

---

**Report End**

*Generated by AI Interview Assistant - VEERA*
*For questions about this report, please contact the recruiting team.*
"""
        
        return report
    
    def _generate_error_report(self, error_message: str) -> str:
        """Generate error report when report generation fails"""
        return f"""
# INTERVIEW REPORT GENERATION ERROR

**Error**: Report generation failed

**Details**: {error_message}

**Time**: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

Please check the system logs and ensure all interview data is properly collected.

---
*Generated by AI Interview Assistant - VEERA*
"""


def generate_interview_report(session_service=None, app_name: str = "", user_id: str = "", session_id: str = "", llm_agent=None) -> str:
    """
    Main function to generate interview report.
    
    Args:
        session_service: Session service for accessing conversation data
        app_name: Application name for session
        user_id: User ID for session
        session_id: Session ID for conversation
        llm_agent: Optional LLM agent for enhanced AI analysis
    
    Returns:
        str: Generated interview report
    """
    generator = ReportGenerator(llm_agent=llm_agent)
    return generator.generate_report(session_service, app_name, user_id, session_id)