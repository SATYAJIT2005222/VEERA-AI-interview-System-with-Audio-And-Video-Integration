# ESP32 WiFi Robot Controller Setup Guide

This guide explains how to set up wireless communication between your ESP32 robot controller and the laptop backend.

## Overview

The ESP32 can now communicate with the backend using WiFi instead of USB serial connection. This provides:
- **Wireless operation** - No USB cable needed
- **Remote control** - Control robot from anywhere on the network
- **Flexibility** - Easier to position the robot

## Hardware Requirements

- ESP32 development board
- Servo motors (MG996R for head, SG90 for hands)
- WiFi network (2.4GHz recommended)
- Power supply for ESP32 and servos

## Software Requirements

- Arduino IDE 2.x
- ESP32Servo library
- WiFi library (included with ESP32 board support)

## Setup Instructions

### 1. Install ESP32 Board Support in Arduino IDE

1. Open Arduino IDE
2. Go to **File > Preferences**
3. Add this URL to "Additional Board Manager URLs":
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
4. Go to **Tools > Board > Boards Manager**
5. Search for "ESP32" and install

### 2. Install Required Libraries

1. Go to **Sketch > Include Library > Manage Libraries**
2. Install **ESP32Servo** by Kevin Harrington

### 3. Configure WiFi Settings

Open `esp32_robot_controller_wifi.ino` and update these lines:

```cpp
const char* WIFI_SSID = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
```

Replace with your actual WiFi network credentials.

### 4. Optional: Set Static IP

If you want a fixed IP address for the ESP32, uncomment and configure:

```cpp
IPAddress local_IP(192, 168, 1, 100);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);
```

Then uncomment this line in `setup()`:
```cpp
if (!WiFi.config(local_IP, gateway, subnet)) {
  Serial.println("Failed to configure Static IP");
}
```

### 5. Upload to ESP32

1. Connect ESP32 to computer via USB
2. Select your ESP32 board from **Tools > Board**
3. Select the correct COM port from **Tools > Port**
4. Click **Upload** button

### 6. Get ESP32 IP Address

After upload, open **Serial Monitor** (115200 baud). You'll see:
```
========================================
ESP32 WiFi Robot Head Controller
========================================
Connecting to WiFi....
WiFi connected! IP address: 192.168.1.100
HTTP server started
========================================
Ready to receive commands via HTTP
========================================
```

Note the IP address shown (e.g., `192.168.1.100`)

## Backend Configuration

### Update Backend Python Code

The backend has been updated to support both serial and WiFi communication. Configure it by setting environment variables:

#### Option 1: Use Environment Variables

Create a `.env` file in the backend directory:

```env
# WiFi Configuration
ESP32_IP=192.168.1.100
USE_WIFI=true

# Serial Configuration (legacy, if USE_WIFI=false)
ESP32_PORT=COM11
```

#### Option 2: Modify Code Directly

In `FinalBackend.py`, update these lines:

```python
# ESP32 WiFi Configuration
ESP32_IP = "192.168.1.100"  # Your ESP32's IP address
ESP32_PORT_HTTP = 80
USE_WIFI = True  # Set to True for WiFi, False for Serial
```

## API Endpoints

The ESP32 exposes these HTTP endpoints:

### GET /
Returns usage information and available commands

### GET /status
Returns current robot status as JSON:
```json
{
  "state": "IDLE",
  "angle": 90,
  "stop_flag": false
}
```

### POST /command
Send command to robot
- **Body**: Plain text command
- **Example**: `STATE:LISTENING`

### GET /command?cmd=STATE:LISTENING
Alternative method to send command via URL parameter

## Available Commands

Same as serial version:
- `ANGLE:<angle>` - Set head angle (40-140)
- `STATE:IDLE` - Set idle state
- `STATE:LISTENING` - Set listening state
- `STATE:THINKING` - Set thinking state
- `STATE:SPEAKING` - Set speaking state
- `STATE:GREETING` - Set greeting state
- `STATE:GOODBYE` - Set goodbye state
- `STATE:ATTENTION` - Set attention state
- `STOP` - Stop all movements

## Testing the Connection

### Using curl

```bash
# Get status
curl http://192.168.1.100/status

# Send command
curl -X POST http://192.168.1.100/command -d "STATE:LISTENING"

# Alternative method
curl "http://192.168.1.100/command?cmd=STATE:LISTENING"
```

### Using Python

```python
import requests

# Get status
response = requests.get("http://192.168.1.100/status")
print(response.json())

# Send command
response = requests.post("http://192.168.1.100/command", data="STATE:LISTENING")
print(response.text)
```

### Using Browser

Open in browser:
- `http://192.168.1.100/` - View usage info
- `http://192.168.1.100/status` - View status

## Troubleshooting

### ESP32 won't connect to WiFi

1. Check WiFi credentials are correct
2. Ensure 2.4GHz network (ESP32 doesn't support 5GHz)
3. Check signal strength
4. Try restarting ESP32

### Backend can't connect to ESP32

1. Verify ESP32 and laptop are on same network
2. Check firewall settings on laptop
3. Ping ESP32 IP from laptop: `ping 192.168.1.100`
4. Check ESP32 Serial Monitor for IP address
5. Try accessing `http://192.168.1.100/` in browser

### Commands not working

1. Check ESP32 Serial Monitor for errors
2. Verify backend is sending correct commands
3. Check ESP32 power supply (WiFi can consume more power)
4. Try switching back to serial mode to isolate issue

## Switching Between Serial and WiFi

To switch communication methods:

### Use Serial (USB)

```python
USE_WIFI = False
ESP32_PORT = "COM11"  # Your COM port
```

Upload `esp32_robot_controller.ino` (original serial version)

### Use WiFi

```python
USE_WIFI = True
ESP32_IP = "192.168.1.100"  # Your ESP32 IP
```

Upload `esp32_robot_controller_wifi.ino` (WiFi version)

## Security Notes

- WiFi communication is not encrypted (HTTP, not HTTPS)
- Only use on trusted local networks
- Consider adding authentication for production use
- Keep WiFi password secure

## Performance Considerations

- WiFi adds ~10-50ms latency compared to serial
- Good WiFi signal is important for reliable operation
- HTTP requests are lightweight, suitable for real-time control
- For sub-10ms response times, serial is still preferred

## Advanced Configuration

### Change HTTP Port

In ESP32 code:
```cpp
WebServer server(8080);  // Change from 80 to 8080
```

Update backend:
```python
ESP32_PORT_HTTP = 8080
```

### Add Authentication

For production use, consider adding API key authentication to ESP32 HTTP server.

## Support

For issues:
1. Check Serial Monitor output
2. Verify network connectivity
3. Test with curl/browser first
4. Check backend logs
5. Try switching back to serial to isolate issue
