
#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>

// ============================================================
// WIFI CONFIGURATION
// ============================================================

const char* WIFI_SSID = "Redmi 13 C 5G";
const char* WIFI_PASSWORD = "12345678";

const unsigned long WIFI_TIMEOUT_MS = 20000;
const unsigned long WIFI_RETRY_INTERVAL_MS = 5000;

// DHCP is used. No static IP configuration is required.

// ============================================================
// HTTP SERVER
// ============================================================

WebServer server(80);

bool serverStarted = false;

// ============================================================
// SERVO CONFIGURATION - ORIGINAL PINS PRESERVED
// ============================================================

const int SERVO_PIN = 18;
const int left_servo = 19;
const int right_servo = 21;

const int MIN_ANGLE = 40;
const int MAX_ANGLE = 140;
const int CENTER_ANGLE = 90;

const int STEP_DELAY = 20;

Servo myservo;
Servo leftServo;
Servo rightServo;

// ============================================================
// ROBOT STATE
// ============================================================

String current_state = "IDLE";

int current_angle = CENTER_ANGLE;
bool stop_flag = false;

// ============================================================
// NON-BLOCKING HEAD MOVEMENT
// ============================================================

bool headMoveActive = false;

int headStartAngle = CENTER_ANGLE;
int headTargetAngle = CENTER_ANGLE;

unsigned long headMoveStartTime = 0;
unsigned long headMoveDuration = 0;
unsigned long lastHeadUpdateTime = 0;

// ============================================================
// IDLE ANIMATION
// ============================================================

unsigned long last_idle_step_time = 0;
int idle_phase = 0;

// ============================================================
// ANIMATION SEQUENCER
// ============================================================

struct MotionStep {
  int angle;
  unsigned long duration;
  unsigned long pauseAfter;
};

const MotionStep listeningSteps[] = {
  {76, 400, 500},
  {90, 400, 0}
};

const MotionStep thinkingSteps[] = {
  {100, 500, 800},
  {90, 500, 0}
};

const MotionStep speakingSteps[] = {
  {95, 300, 400},
  {90, 300, 400},
  {85, 300, 400},
  {90, 300, 0}
};

const MotionStep greetingSteps[] = {
  {80, 400, 300},
  {100, 400, 300},
  {90, 400, 0}
};

const MotionStep goodbyeSteps[] = {
  {100, 400, 300},
  {80, 400, 300},
  {90, 400, 0}
};

const MotionStep attentionSteps[] = {
  {90, 300, 0}
};

const MotionStep* activeSteps = nullptr;
int activeStepCount = 0;
int activeStepIndex = 0;

bool stepMoveStarted = false;
bool stepPauseStarted = false;

unsigned long stepPauseStartTime = 0;

// ============================================================
// NON-BLOCKING THINKING SERVO MOVEMENT
// ============================================================

bool thinkingServoActive = false;
int thinkingServoAngle = 90;
unsigned long lastThinkingServoStep = 0;

// ============================================================
// WIFI RECONNECTION
// ============================================================

unsigned long lastWiFiRetryTime = 0;

// ============================================================
// FUNCTION DECLARATIONS
// ============================================================

void setupServer();

void handleRoot();
void handleCommand();
void handleStatus();
void handleNotFound();

void process_command(String command);

void beginHeadMove(int targetAngle, unsigned long duration);
void updateHeadMove();

void run_non_blocking_idle();
void startStateAnimation();
void updateStateAnimation();
void updateThinkingServo();

void setRobotState(String state);
void cancelAnimation();

bool isValidState(String state);

// ============================================================
// SETUP
// ============================================================

void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println();
  Serial.println("========================================");
  Serial.println("ESP32 WiFi Robot Head Controller");
  Serial.println("========================================");

  // ----------------------------------------------------------
  // WIFI INITIALIZATION
  // ----------------------------------------------------------

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to WiFi...");

  unsigned long startTime = millis();

  while (WiFi.status() != WL_CONNECTED &&
         millis() - startTime < WIFI_TIMEOUT_MS) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.println("WiFi connected!");

    Serial.print("ESP32 IP address: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println();
    Serial.println("WiFi connection timed out.");
    Serial.println("The ESP32 will retry in the background.");
  }

  // ----------------------------------------------------------
  // SERVO INITIALIZATION
  // ----------------------------------------------------------

  myservo.setPeriodHertz(50);
  leftServo.setPeriodHertz(50);
  rightServo.setPeriodHertz(50);

  myservo.attach(SERVO_PIN, 544, 2400);
  leftServo.attach(left_servo, 500, 2400);
  rightServo.attach(right_servo, 500, 2400);

  current_angle = CENTER_ANGLE;

  myservo.write(CENTER_ANGLE);

  leftServo.write(0);
  rightServo.write(0);

  // ----------------------------------------------------------
  // HTTP SERVER
  // ----------------------------------------------------------

  setupServer();

  server.begin();
  serverStarted = true;

  Serial.println("HTTP server started.");
  Serial.println("Commands: ANGLE:<angle>, STATE:<state>, STOP");
  Serial.println("========================================");
}

// ============================================================
// HTTP SERVER ROUTES
// ============================================================

void setupServer() {
  server.on("/", HTTP_GET, handleRoot);

  server.on("/command", HTTP_POST, handleCommand);
  server.on("/command", HTTP_GET, handleCommand);

  server.on("/status", HTTP_GET, handleStatus);

  server.onNotFound(handleNotFound);

  server.enableCORS(true);
}

// ============================================================
// ROOT ENDPOINT
// ============================================================

void handleRoot() {
  String html = "<html><body>";
  html += "<h1>ESP32 Robot Controller</h1>";
  html += "<p>WiFi-connected robot controller is running.</p>";
  html += "<h2>Endpoints</h2>";
  html += "<ul>";
  html += "<li>GET /</li>";
  html += "<li>GET /status</li>";
  html += "<li>POST /command</li>";
  html += "</ul>";
  html += "<h2>Commands</h2>";
  html += "<ul>";
  html += "<li>ANGLE:40 to ANGLE:140</li>";
  html += "<li>STATE:IDLE</li>";
  html += "<li>STATE:LISTENING</li>";
  html += "<li>STATE:THINKING</li>";
  html += "<li>STATE:SPEAKING</li>";
  html += "<li>STATE:GREETING</li>";
  html += "<li>STATE:GOODBYE</li>";
  html += "<li>STATE:ATTENTION</li>";
  html += "<li>STOP</li>";
  html += "</ul>";
  html += "</body></html>";

  server.send(200, "text/html", html);
}

// ============================================================
// COMMAND ENDPOINT
// ============================================================

void handleCommand() {
  String command;

  if (server.method() == HTTP_POST) {
    command = server.arg("plain");

    // Also accept a form field named "cmd".
    if (command.length() == 0) {
      command = server.arg("cmd");
    }
  } else {
    command = server.arg("cmd");
  }

  command.trim();

  Serial.print("Received command: ");
  Serial.println(command);

  if (command.length() == 0) {
    server.send(400, "text/plain", "No command provided");
    return;
  }

  // Validate before reporting successful processing.
  if (command == "STOP") {
    process_command(command);
    server.send(200, "text/plain", "STOP accepted");
    return;
  }

  if (command.startsWith("ANGLE:")) {
    String angleText = command.substring(6);
    angleText.trim();

    bool validNumber = angleText.length() > 0;

    for (unsigned int i = 0; i < angleText.length(); i++) {
      if (angleText[i] < '0' || angleText[i] > '9') {
        validNumber = false;
        break;
      }
    }

    if (!validNumber) {
      server.send(400, "text/plain", "Invalid angle");
      return;
    }

    process_command(command);
    server.send(200, "text/plain", "Angle command accepted");
    return;
  }

  if (command.startsWith("STATE:")) {
    String requestedState = command.substring(6);
    requestedState.trim();

    if (!isValidState(requestedState)) {
      server.send(400, "text/plain", "Unknown state");
      return;
    }

    process_command("STATE:" + requestedState);
    server.send(200, "text/plain", "State command accepted");
    return;
  }

  server.send(400, "text/plain", "Unknown command");
}

// ============================================================
// STATUS ENDPOINT
// ============================================================

void handleStatus() {
  String json = "{";

  json += "\"state\":\"" + current_state + "\",";
  json += "\"angle\":" + String(current_angle) + ",";
  json += "\"stop_flag\":";
  json += stop_flag ? "true" : "false";
  json += ",\"wifi_connected\":";
  json += WiFi.status() == WL_CONNECTED ? "true" : "false";

  json += "}";

  server.send(200, "application/json", json);
}

// ============================================================
// 404 HANDLER
// ============================================================

void handleNotFound() {
  server.send(404, "text/plain", "Not Found");
}

// ============================================================
// MAIN LOOP
// ============================================================

void loop() {
  // Process HTTP requests on every loop iteration.
  if (serverStarted) {
    server.handleClient();
  }

  // Retry WiFi without blocking servo animation.
  if (WiFi.status() != WL_CONNECTED) {
    unsigned long now = millis();

    if (now - lastWiFiRetryTime >= WIFI_RETRY_INTERVAL_MS) {
      lastWiFiRetryTime = now;

      Serial.println("WiFi disconnected. Reconnecting...");
      WiFi.reconnect();
    }
  }

  // Update all motion using non-blocking timing.
  updateHeadMove();
  updateThinkingServo();

  if (!stop_flag) {
    if (current_state == "IDLE") {
      run_non_blocking_idle();
    } else {
      updateStateAnimation();
    }
  }

  // Yield briefly without introducing a long blocking delay.
  delay(2);
}

// ============================================================
// COMMAND PROCESSING
// ============================================================

void process_command(String command) {
  command.trim();

  Serial.print("Processing: ");
  Serial.println(command);

  // ----------------------------------------------------------
  // STOP COMMAND
  // ----------------------------------------------------------

  if (command == "STOP") {
    stop_flag = true;

    cancelAnimation();

    headMoveActive = false;
    thinkingServoActive = false;

    leftServo.write(0);
    rightServo.write(0);

    Serial.println("Action: STOP");

    // Hold the head at its current position.
    return;
  }

  stop_flag = false;

  // ----------------------------------------------------------
  // MANUAL HEAD ANGLE
  // ----------------------------------------------------------

  if (command.startsWith("ANGLE:")) {
    int angle = command.substring(6).toInt();

    angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);

    cancelAnimation();
    thinkingServoActive = false;

    beginHeadMove(angle, 500);

    Serial.print("Head target angle: ");
    Serial.println(angle);

    return;
  }

  // ----------------------------------------------------------
  // STATE COMMAND
  // ----------------------------------------------------------

  if (command.startsWith("STATE:")) {
    String requestedState = command.substring(6);
    requestedState.trim();

    if (!isValidState(requestedState)) {
      Serial.println("Unknown state");
      return;
    }

    setRobotState(requestedState);

    return;
  }

  Serial.println("Unknown command");
}

// ============================================================
// STATE VALIDATION
// ============================================================

bool isValidState(String state) {
  return state == "IDLE" ||
         state == "LISTENING" ||
         state == "THINKING" ||
         state == "SPEAKING" ||
         state == "GREETING" ||
         state == "GOODBYE" ||
         state == "ATTENTION";
}

// ============================================================
// SET ROBOT STATE
// ============================================================

void setRobotState(String state) {
  current_state = state;

  cancelAnimation();

  headMoveActive = false;
  thinkingServoActive = false;

  Serial.print("State changed to: ");
  Serial.println(current_state);

  // ----------------------------------------------------------
  // IDLE
  // ----------------------------------------------------------

  if (state == "IDLE") {
    idle_phase = 0;
    last_idle_step_time = 0;

    leftServo.write(0);
    rightServo.write(0);

    return;
  }

  // ----------------------------------------------------------
  // LISTENING
  // ----------------------------------------------------------

  if (state == "LISTENING") {
    leftServo.write(90);
    rightServo.write(0);
  }

  // ----------------------------------------------------------
  // THINKING
  // ----------------------------------------------------------

  else if (state == "THINKING") {
    // Preserve the original movement from 90 down toward 76.
    leftServo.write(90);
    rightServo.write(0);

    thinkingServoAngle = 90;
    lastThinkingServoStep = millis();
    thinkingServoActive = true;
  }

  // ----------------------------------------------------------
  // SPEAKING
  // ----------------------------------------------------------

  else if (state == "SPEAKING") {
    leftServo.write(25);
    rightServo.write(25);
  }

  // ----------------------------------------------------------
  // GREETING
  // ----------------------------------------------------------

  else if (state == "GREETING") {
    leftServo.write(45);
    rightServo.write(45);
  }

  // ----------------------------------------------------------
  // GOODBYE
  // ----------------------------------------------------------

  else if (state == "GOODBYE") {
    leftServo.write(80);
    rightServo.write(0);
  }

  // ATTENTION retains the auxiliary servo positions,
  // as in the original sketch.

  startStateAnimation();
}

// ============================================================
// CANCEL ACTIVE ANIMATION SEQUENCE
// ============================================================

void cancelAnimation() {
  activeSteps = nullptr;
  activeStepCount = 0;
  activeStepIndex = 0;

  stepMoveStarted = false;
  stepPauseStarted = false;
}

// ============================================================
// BEGIN NON-BLOCKING HEAD MOVEMENT
// ============================================================

void beginHeadMove(int targetAngle, unsigned long duration) {
  targetAngle = constrain(targetAngle, MIN_ANGLE, MAX_ANGLE);

  headStartAngle = current_angle;
  headTargetAngle = targetAngle;

  headMoveStartTime = millis();
  headMoveDuration = duration;
  lastHeadUpdateTime = 0;

  if (duration == 0 || headStartAngle == headTargetAngle) {
    current_angle = targetAngle;
    myservo.write(current_angle);
    headMoveActive = false;
    return;
  }

  headMoveActive = true;
}

// ============================================================
// UPDATE HEAD MOVEMENT WITHOUT BLOCKING WIFI
// ============================================================

void updateHeadMove() {
  if (!headMoveActive) {
    return;
  }

  unsigned long now = millis();

  if (lastHeadUpdateTime != 0 &&
      now - lastHeadUpdateTime < STEP_DELAY) {
    return;
  }

  lastHeadUpdateTime = now;

  unsigned long elapsed = now - headMoveStartTime;

  if (elapsed >= headMoveDuration) {
    current_angle = headTargetAngle;
    myservo.write(current_angle);

    headMoveActive = false;
    return;
  }

  float progress =
      (float)elapsed / (float)headMoveDuration;

  int newAngle = headStartAngle +
      (int)((headTargetAngle - headStartAngle) * progress);

  newAngle = constrain(newAngle, MIN_ANGLE, MAX_ANGLE);

  if (newAngle != current_angle) {
    current_angle = newAngle;
    myservo.write(current_angle);
  }
}

// ============================================================
// START STATE ANIMATION SEQUENCE
// ============================================================

void startStateAnimation() {
  if (current_state == "LISTENING") {
    activeSteps = listeningSteps;
    activeStepCount =
        sizeof(listeningSteps) / sizeof(listeningSteps[0]);
  }

  else if (current_state == "THINKING") {
    activeSteps = thinkingSteps;
    activeStepCount =
        sizeof(thinkingSteps) / sizeof(thinkingSteps[0]);
  }

  else if (current_state == "SPEAKING") {
    activeSteps = speakingSteps;
    activeStepCount =
        sizeof(speakingSteps) / sizeof(speakingSteps[0]);
  }

  else if (current_state == "GREETING") {
    activeSteps = greetingSteps;
    activeStepCount =
        sizeof(greetingSteps) / sizeof(greetingSteps[0]);
  }

  else if (current_state == "GOODBYE") {
    activeSteps = goodbyeSteps;
    activeStepCount =
        sizeof(goodbyeSteps) / sizeof(goodbyeSteps[0]);
  }

  else if (current_state == "ATTENTION") {
    activeSteps = attentionSteps;
    activeStepCount =
        sizeof(attentionSteps) / sizeof(attentionSteps[0]);
  }

  else {
    activeSteps = nullptr;
    activeStepCount = 0;
    return;
  }

  activeStepIndex = 0;
  stepMoveStarted = false;
  stepPauseStarted = false;
}

// ============================================================
// UPDATE STATE ANIMATION SEQUENCE
// ============================================================

void updateStateAnimation() {
  if (activeSteps == nullptr ||
      activeStepIndex >= activeStepCount) {
    return;
  }

  // The original THINKING animation moved the auxiliary
  // servo before beginning its head movement.
  if (current_state == "THINKING" &&
      thinkingServoActive) {
    return;
  }

  const MotionStep& step = activeSteps[activeStepIndex];

  if (!stepMoveStarted) {
    beginHeadMove(step.angle, step.duration);

    stepMoveStarted = true;
    stepPauseStarted = false;

    return;
  }

  if (headMoveActive) {
    return;
  }

  if (!stepPauseStarted) {
    stepPauseStartTime = millis();
    stepPauseStarted = true;
    return;
  }

  if (millis() - stepPauseStartTime >= step.pauseAfter) {
    activeStepIndex++;

    stepMoveStarted = false;
    stepPauseStarted = false;
  }
}

// ============================================================
// NON-BLOCKING THINKING AUXILIARY SERVO
// ============================================================

void updateThinkingServo() {
  if (!thinkingServoActive || stop_flag ||
      current_state != "THINKING") {
    return;
  }

  unsigned long now = millis();

  if (now - lastThinkingServoStep < STEP_DELAY) {
    return;
  }

  lastThinkingServoStep = now;

  if (thinkingServoAngle > 76) {
    thinkingServoAngle -= 2;

    if (thinkingServoAngle < 76) {
      thinkingServoAngle = 76;
    }

    leftServo.write(thinkingServoAngle);
  }

  if (thinkingServoAngle <= 76) {
    thinkingServoActive = false;
  }
}

// ============================================================
// NON-BLOCKING IDLE ANIMATION
// ============================================================

void run_non_blocking_idle() {
  if (headMoveActive) {
    return;
  }

  unsigned long now = millis();

  if (now - last_idle_step_time < 2300) {
    return;
  }

  last_idle_step_time = now;

  if (idle_phase == 0) {
    beginHeadMove(88, 300);
    idle_phase = 1;
  }

  else if (idle_phase == 1) {
    beginHeadMove(90, 300);
    idle_phase = 2;
  }

  else if (idle_phase == 2) {
    beginHeadMove(92, 300);
    idle_phase = 3;
  }

  else {
    beginHeadMove(90, 300);
    idle_phase = 0;
  }
}
