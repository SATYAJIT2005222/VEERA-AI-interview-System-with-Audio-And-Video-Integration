#include <ESP32Servo.h>

// =========================
// CONFIGURATION
// =========================

const int SERVO_PIN = 18;  
const int left_servo=19;
const int right_servo=21;

// Servo angle limits 
const int MIN_ANGLE = 40;
const int MAX_ANGLE = 140;
const int CENTER_ANGLE = 90;

const int STEP_DELAY = 20;
const int BAUD_RATE = 115200;

// Current state
String current_state = "IDLE";
int current_angle = CENTER_ANGLE;
bool stop_flag = false;

// Variables to handle non-blocking Idle timing
unsigned long last_idle_step_time = 0;
int idle_phase = 0;

Servo myservo;
Servo leftServo;
Servo rightServo;

// =========================
// SETUP
// =========================

void setup() {
  Serial.begin(BAUD_RATE);
  delay(1000);
  
  Serial.println("========================================");
  Serial.println("ESP32 Robot Head Controller");
  Serial.println("========================================");
  
  myservo.setPeriodHertz(50);  
  // FIX: Use standard pulse width limits in microseconds (544us to 2400us)
  myservo.attach(SERVO_PIN, 544, 2400);
  



  // Set standard servo PWM frequency (50Hz)
  leftServo.setPeriodHertz(50);
  rightServo.setPeriodHertz(50);

  // Attach the servos to their respective pins.
  // 500 and 2400 represent the min/max pulse width in microseconds for standard SG90 0-180° rotation.
  leftServo.attach(left_servo, 500, 2400);
  rightServo.attach(right_servo, 500, 2400);

  move_smooth(CENTER_ANGLE, 500);
  current_angle = CENTER_ANGLE;
  
  leftServo.write(0);
  rightServo.write(0);

  Serial.println("Ready to receive commands");
  Serial.println("========================================");
}

// =========================
// MAIN LOOP
// =========================

void loop() {
  if (Serial.available() > 0) {
    String command = Serial.readStringUntil('\n');
    command.trim();
    
    if (command.length() > 0) {
      process_command(command);
    }
  }
  
  // FIX: Run idle tracking safely outside the blocked function
  
  myservo.write(current_angle);
  delay(10);
}

// =========================
// COMMAND PROCESSING
// =========================

void process_command(String command) {
  Serial.print("Received: ");
  Serial.println(command);
  
  if (command == "STOP") {
    stop_flag = true;
    Serial.println("Action: STOP");
    leftServo.write(0);
    rightServo.write(0);
    return;
  }
  
  stop_flag = false;
  
  if (command.startsWith("ANGLE:")) {
    int angle = command.substring(6).toInt();
    angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);
    move_smooth(angle, 500);
    current_angle = angle;
    return;
  }
  
  if (command.startsWith("STATE:")) {
    String state = command.substring(6);
    current_state = state;
    Serial.print("State changed to: ");
    Serial.println(state);
    
    if (state == "IDLE") {
      idle_phase = 0; // Reset phase tracker
      last_idle_step_time = 0;
      leftServo.write(0);
      rightServo.write(0);
    } else if (state == "LISTENING") {
      leftServo.write(90);
      rightServo.write(0);
      animate_listening();
    } else if (state == "THINKING") {
      animate_thinking();
    } else if (state == "SPEAKING") {
      leftServo.write(25);
      rightServo.write(25);
      animate_speaking();
    } else if (state == "GREETING") {
      leftServo.write(45);
      rightServo.write(45);
      animate_greeting();
    } else if (state == "GOODBYE") {
      leftServo.write(80);
      rightServo.write(0);
      animate_goodbye();
    } else if (state == "ATTENTION") {
      animate_attention();
    } else {
      Serial.println("Unknown state");
    }
    return;
  }
  Serial.println("Unknown command");
}

// =========================
// MOVEMENT FUNCTIONS
// =========================

void move_smooth(int target_angle, int duration_ms) {
  if (stop_flag) return;
  
  int start_angle = current_angle;
  int steps = duration_ms / STEP_DELAY;
  
  for (int i = 0; i <= steps; i++) {
    // Check serial inside movement loops so STOP works mid-transit
    if (Serial.available() > 0) {
      String command = Serial.readStringUntil('\n');
      command.trim();
      if (command == "STOP") { 
        stop_flag = true; 
        break; 
      }
    }
    
    if (stop_flag) break;
    
    float progress = (float)i / steps;
    int angle = start_angle + (target_angle - start_angle) * progress;
    angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);
    
    myservo.write(angle);
    current_angle = angle;
    delay(STEP_DELAY);
  }
}

// =========================
// ANIMATION FUNCTIONS
// =========================

// FIX: Rewritten to use millis() timers instead of a blocking while loop
void run_non_blocking_idle() {
  unsigned long now = millis();
  if (now - last_idle_step_time < 2300) return; // 2000ms delay + 300ms move time

  last_idle_step_time = now;
  
  if (idle_phase == 0) {
    move_smooth(88, 300);
    idle_phase = 1;
  } else if (idle_phase == 1) {
    move_smooth(90, 300);
    idle_phase = 2;
  } else if (idle_phase == 2) {
    move_smooth(92, 300);
    idle_phase = 3;
  } else {
    move_smooth(90, 300);
    idle_phase = 0;
  }
}

void animate_listening() {
  move_smooth(76, 400);
  if (!stop_flag) delay(500);
  if (!stop_flag) move_smooth(90, 400);
}

void animate_thinking() {
  for(int i=90; i>75; i+=2){
    leftServo.write(i);
  }  
  rightServo.write(0);
  move_smooth(100, 500);
  if (!stop_flag) delay(800);
  if (!stop_flag) move_smooth(90, 500);
}

void animate_speaking() {
  move_smooth(95, 300);
  if (!stop_flag) delay(400);
  if (!stop_flag) move_smooth(90, 300);
  if (!stop_flag) delay(400);
  if (!stop_flag) move_smooth(85, 300);
  if (!stop_flag) delay(400);
  if (!stop_flag) move_smooth(90, 300);
}

void animate_greeting() {
  move_smooth(80, 400);
  if (!stop_flag) delay(300);
  if (!stop_flag) move_smooth(100, 400);
  if (!stop_flag) delay(300);
  if (!stop_flag) move_smooth(90, 400);
}

void animate_goodbye() {
  move_smooth(100, 400);
  if (!stop_flag) delay(300);
  if (!stop_flag) move_smooth(80, 400);
  if (!stop_flag) delay(300);
  if (!stop_flag) move_smooth(90, 400);
}

void animate_attention() {
  move_smooth(90, 300);
}












// #include <ESP32Servo.h>

// // ============================================================
// // ESP32 ROBOT INTERVIEWER
// // MG996R Head + Two SG90 Hands
// // Serial baud rate: 115200
// //
// // Serial commands:
// //   ANGLE:<angle>
// //   STATE:IDLE
// //   STATE:GREETING
// //   STATE:SPEAKING
// //   STATE:LISTENING
// //   STATE:THINKING
// //   STATE:ATTENTION
// //   STATE:GOODBYE
// //   STOP
// // ============================================================

// // =========================
// // PIN CONFIGURATION
// // =========================

// // Existing MG996R head servo
// const int HEAD_SERVO_PIN = 18;

// // New SG90 hand servos
// const int LEFT_HAND_PIN  = 19;
// const int RIGHT_HAND_PIN = 21;

// // =========================
// // HEAD SERVO CONFIGURATION
// // =========================

// const int MIN_ANGLE = 40;
// const int MAX_ANGLE = 140;
// const int CENTER_ANGLE = 90;

// const int STEP_DELAY = 20;
// const int BAUD_RATE = 115200;

// // =========================
// // HAND SERVO CONFIGURATION
// // =========================

// // Neutral position
// const int LEFT_REST = 90;
// const int RIGHT_REST = 90;

// // Gentle speaking gestures
// const int LEFT_GESTURE = 108;
// const int RIGHT_GESTURE = 72;

// // Raised arms
// const int LEFT_RAISED = 125;
// const int RIGHT_RAISED = 55;

// // Farewell wave positions
// const int LEFT_WAVE_LOW = 105;
// const int LEFT_WAVE_HIGH = 135;

// const int RIGHT_WAVE_LOW = 75;
// const int RIGHT_WAVE_HIGH = 45;

// // Hand animation timing
// const unsigned long SPEAK_INTERVAL = 900;
// const unsigned long WAVE_INTERVAL = 350;
// const unsigned long GREETING_HOLD = 1200;

// // =========================
// // GLOBAL VARIABLES
// // =========================

// String current_state = "IDLE";

// int current_angle = CENTER_ANGLE;
// bool stop_flag = false;

// unsigned long last_idle_step_time = 0;
// int idle_phase = 0;

// unsigned long last_hand_move = 0;
// unsigned long hand_state_started = 0;

// bool gesture_left_next = true;
// bool wave_high = false;

// Servo headServo;
// Servo leftHandServo;
// Servo rightHandServo;

// // =========================
// // SETUP
// // =========================

// void setup() {
//   Serial.begin(BAUD_RATE);
//   Serial.setTimeout(50);

//   delay(1000);

//   Serial.println("========================================");
//   Serial.println("ESP32 Robot Head + Hand Controller");
//   Serial.println("========================================");

//   // Initialize the existing head servo
//   headServo.setPeriodHertz(50);
//   headServo.attach(HEAD_SERVO_PIN, 544, 2400);

//   // Initialize the two new SG90 servos
//   leftHandServo.setPeriodHertz(50);
//   rightHandServo.setPeriodHertz(50);

//   leftHandServo.attach(LEFT_HAND_PIN, 500, 2400);
//   rightHandServo.attach(RIGHT_HAND_PIN, 500, 2400);

//   // Set all servos to their neutral positions
//   headServo.write(CENTER_ANGLE);
//   leftHandServo.write(LEFT_REST);
//   rightHandServo.write(RIGHT_REST);

//   current_angle = CENTER_ANGLE;

//   // Preserve the original head startup movement
//   move_smooth(CENTER_ANGLE, 500);

//   Serial.println("Head servo: GPIO 18");
//   Serial.println("Left hand:  GPIO 19");
//   Serial.println("Right hand: GPIO 21");
//   Serial.println("Ready to receive commands");
//   Serial.println("========================================");
// }

// // =========================
// // MAIN LOOP
// // =========================

// void loop() {
//   if (Serial.available() > 0) {
//     String command = Serial.readStringUntil('\n');
//     command.trim();

//     if (command.length() > 0) {
//       process_command(command);
//     }
//   }

//   // Existing non-blocking head idle animation
//   if (current_state == "IDLE" && !stop_flag) {
//     run_non_blocking_idle();
//   }

//   // New hand animations
//   update_hand_animation();

//   headServo.write(current_angle);
// }

// // =========================
// // COMMAND PROCESSING
// // =========================

// void process_command(String command) {
//   command.trim();

//   Serial.print("Received: ");
//   Serial.println(command);

//   if (command == "STOP") {
//     stop_flag = true;
//     Serial.println("Action: STOP");
//     return;
//   }

//   stop_flag = false;

//   // Direct head-angle command
//   if (command.startsWith("ANGLE:")) {
//     int angle = command.substring(6).toInt();

//     angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);

//     move_smooth(angle, 500);
//     current_angle = angle;
//     return;
//   }

//   // Robot state command
//   if (command.startsWith("STATE:")) {
//     String state = command.substring(6);
//     state.trim();
//     state.toUpperCase();

//     current_state = state;

//     Serial.print("State changed to: ");
//     Serial.println(current_state);

//     // Set the hand pose immediately when the state arrives
//     set_hand_state(current_state);

//     // Preserve the original head animations
//     if (current_state == "IDLE") {
//       idle_phase = 0;
//       last_idle_step_time = 0;
//     }
//     else if (current_state == "LISTENING") {
//       animate_listening();
//     }
//     else if (current_state == "THINKING") {
//       animate_thinking();
//     }
//     else if (current_state == "SPEAKING") {
//       animate_speaking();
//     }
//     else if (current_state == "GREETING") {
//       animate_greeting();
//     }
//     else if (current_state == "GOODBYE") {
//       animate_goodbye();
//     }
//     else if (current_state == "ATTENTION") {
//       animate_attention();
//     }
//     else {
//       Serial.println("Unknown state");
//     }

//     return;
//   }

//   Serial.println("Unknown command");
// }

// // ============================================================
// // HAND SERVO FUNCTIONS
// // ============================================================

// // Move both hands to their requested positions.
// // Mechanical limits can differ depending on how the hands
// // are attached. Start cautiously and calibrate if necessary.
// void move_hands(int leftAngle, int rightAngle) {
//   leftAngle = constrain(leftAngle, 40, 140);
//   rightAngle = constrain(rightAngle, 40, 140);

//   leftHandServo.write(leftAngle);
//   rightHandServo.write(rightAngle);
// }

// // Select an initial hand pose for each robot state.
// void set_hand_state(String state) {
//   hand_state_started = millis();
//   last_hand_move = millis();

//   gesture_left_next = true;
//   wave_high = false;

//   if (state == "IDLE") {
//     move_hands(LEFT_REST, RIGHT_REST);
//   }
//   else if (state == "GREETING") {
//     // Welcome the candidate with both hands raised
//     move_hands(LEFT_RAISED, RIGHT_RAISED);
//   }
//   else if (state == "SPEAKING") {
//     // Begin with a small explanatory gesture
//     move_hands(LEFT_GESTURE, RIGHT_REST);
//   }
//   else if (state == "LISTENING") {
//     // Relaxed pose while the candidate answers
//     move_hands(LEFT_REST, RIGHT_REST);
//   }
//   else if (state == "THINKING") {
//     // Raise the left hand as if considering an answer
//     move_hands(LEFT_RAISED, RIGHT_REST);
//   }
//   else if (state == "ATTENTION") {
//     // Slightly open, attentive posture
//     move_hands(100, 80);
//   }
//   else if (state == "GOODBYE") {
//     // Raise both hands before waving
//     move_hands(LEFT_RAISED, RIGHT_RAISED);
//   }
// }

// // Update hands without using delay().
// // This function is called repeatedly from loop().
// void update_hand_animation() {
//   if (stop_flag) {
//     return;
//   }

//   unsigned long now = millis();

//   // ----------------------------------------------------------
//   // SPEAKING: alternate small hand gestures
//   // ----------------------------------------------------------
//   if (current_state == "SPEAKING") {
//     if (now - last_hand_move >= SPEAK_INTERVAL) {
//       last_hand_move = now;

//       if (gesture_left_next) {
//         move_hands(LEFT_GESTURE, RIGHT_REST);
//       } else {
//         move_hands(LEFT_REST, RIGHT_GESTURE);
//       }

//       gesture_left_next = !gesture_left_next;
//     }
//   }

//   // ----------------------------------------------------------
//   // GREETING: hold the welcome pose, then relax
//   // ----------------------------------------------------------
//   else if (current_state == "GREETING") {
//     if (now - hand_state_started >= GREETING_HOLD) {
//       move_hands(LEFT_REST, RIGHT_REST);

//       // Avoid repeating this action every loop iteration
//       hand_state_started = now;
//     }
//   }

//   // ----------------------------------------------------------
//   // GOODBYE: alternate the hands to create a waving effect
//   // ----------------------------------------------------------
//   else if (current_state == "GOODBYE") {
//     if (now - last_hand_move >= WAVE_INTERVAL) {
//       last_hand_move = now;
//       wave_high = !wave_high;

//       if (wave_high) {
//         move_hands(LEFT_WAVE_HIGH, RIGHT_WAVE_HIGH);
//       } else {
//         move_hands(LEFT_WAVE_LOW, RIGHT_WAVE_LOW);
//       }
//     }
//   }
// }

// // =========================
// // HEAD MOVEMENT FUNCTIONS
// // Original head movement logic retained
// // =========================

// void move_smooth(int target_angle, int duration_ms) {
//   if (stop_flag) return;

//   int start_angle = current_angle;
//   int steps = duration_ms / STEP_DELAY;

//   if (steps < 1) {
//     steps = 1;
//   }

//   for (int i = 0; i <= steps; i++) {
//     // Preserve the original STOP check
//     if (Serial.available() > 0) {
//       String command = Serial.readStringUntil('\n');
//       command.trim();

//       if (command == "STOP") {
//         stop_flag = true;
//         break;
//       }
//     }

//     if (stop_flag) break;

//     float progress = (float)i / steps;

//     int angle =
//       start_angle + (target_angle - start_angle) * progress;

//     angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);

//     headServo.write(angle);
//     current_angle = angle;

//     delay(STEP_DELAY);
//   }
// }

// // =========================
// // HEAD IDLE ANIMATION
// // =========================

// void run_non_blocking_idle() {
//   unsigned long now = millis();

//   if (now - last_idle_step_time < 2300) {
//     return;
//   }

//   last_idle_step_time = now;

//   if (idle_phase == 0) {
//     move_smooth(88, 300);
//     idle_phase = 1;
//   }
//   else if (idle_phase == 1) {
//     move_smooth(90, 300);
//     idle_phase = 2;
//   }
//   else if (idle_phase == 2) {
//     move_smooth(92, 300);
//     idle_phase = 3;
//   }
//   else {
//     move_smooth(90, 300);
//     idle_phase = 0;
//   }
// }

// // =========================
// // HEAD LISTENING ANIMATION
// // =========================

// void animate_listening() {
//   move_smooth(85, 400);

//   if (!stop_flag) delay(500);

//   if (!stop_flag) move_smooth(90, 400);
// }

// // =========================
// // HEAD THINKING ANIMATION
// // =========================

// void animate_thinking() {
//   move_smooth(100, 500);

//   if (!stop_flag) delay(800);

//   if (!stop_flag) move_smooth(90, 500);
// }

// // =========================
// // HEAD SPEAKING ANIMATION
// // =========================

// void animate_speaking() {
//   move_smooth(95, 300);

//   if (!stop_flag) delay(400);

//   if (!stop_flag) move_smooth(90, 300);

//   if (!stop_flag) delay(400);

//   if (!stop_flag) move_smooth(85, 300);

//   if (!stop_flag) delay(400);

//   if (!stop_flag) move_smooth(90, 300);
// }

// // =========================
// // HEAD GREETING ANIMATION
// // =========================

// void animate_greeting() {
//   move_smooth(80, 400);

//   if (!stop_flag) delay(300);

//   if (!stop_flag) move_smooth(100, 400);

//   if (!stop_flag) delay(300);

//   if (!stop_flag) move_smooth(90, 400);
// }

// // =========================
// // HEAD GOODBYE ANIMATION
// // =========================

// void animate_goodbye() {
//   move_smooth(100, 400);

//   if (!stop_flag) delay(300);

//   if (!stop_flag) move_smooth(80, 400);

//   if (!stop_flag) delay(300);

//   if (!stop_flag) move_smooth(90, 400);
// }

// // =========================
// // HEAD ATTENTION ANIMATION
// // =========================

// void animate_attention() {
//   move_smooth(90, 300);
// }
















// #include <ESP32Servo.h>

// // =========================
// // CONFIGURATION
// // =========================

// const int SERVO_PIN = 18;  

// // Servo angle limits 
// const int MIN_ANGLE = 40;
// const int MAX_ANGLE = 140;
// const int CENTER_ANGLE = 90;

// const int STEP_DELAY = 20;
// const int BAUD_RATE = 115200;

// // Current state
// String current_state = "IDLE";
// int current_angle = CENTER_ANGLE;
// bool stop_flag = false;

// // Variables to handle non-blocking Idle timing
// unsigned long last_idle_step_time = 0;
// int idle_phase = 0;

// Servo myservo;

// // =========================
// // SETUP
// // =========================

// void setup() {
//   Serial.begin(BAUD_RATE);
//   delay(1000);
  
//   Serial.println("========================================");
//   Serial.println("ESP32 Robot Head Controller");
//   Serial.println("========================================");
  
//   myservo.setPeriodHertz(50);  
//   // FIX: Use standard pulse width limits in microseconds (544us to 2400us)
//   myservo.attach(SERVO_PIN, 544, 2400);
  
//   move_smooth(CENTER_ANGLE, 500);
//   current_angle = CENTER_ANGLE;
  
//   Serial.println("Ready to receive commands");
//   Serial.println("========================================");
// }

// // =========================
// // MAIN LOOP
// // =========================

// void loop() {
//   if (Serial.available() > 0) {
//     String command = Serial.readStringUntil('\n');
//     command.trim();
    
//     if (command.length() > 0) {
//       process_command(command);
//     }
//   }
  
//   // FIX: Run idle tracking safely outside the blocked function
//   if (current_state == "IDLE" && !stop_flag) {
//     run_non_blocking_idle();
//   }
  
//   myservo.write(current_angle);
//   delay(10);
// }

// // =========================
// // COMMAND PROCESSING
// // =========================

// void process_command(String command) {
//   Serial.print("Received: ");
//   Serial.println(command);
  
//   if (command == "STOP") {
//     stop_flag = true;
//     Serial.println("Action: STOP");
//     return;
//   }
  
//   stop_flag = false;
  
//   if (command.startsWith("ANGLE:")) {
//     int angle = command.substring(6).toInt();
//     angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);
//     move_smooth(angle, 500);
//     current_angle = angle;
//     return;
//   }
  
//   if (command.startsWith("STATE:")) {
//     String state = command.substring(6);
//     current_state = state;
//     Serial.print("State changed to: ");
//     Serial.println(state);
    
//     if (state == "IDLE") {
//       idle_phase = 0; // Reset phase tracker
//       last_idle_step_time = 0;
//     } else if (state == "LISTENING") {
//       animate_listening();
//     } else if (state == "THINKING") {
//       animate_thinking();
//     } else if (state == "SPEAKING") {
//       animate_speaking();
//     } else if (state == "GREETING") {
//       animate_greeting();
//     } else if (state == "GOODBYE") {
//       animate_goodbye();
//     } else if (state == "ATTENTION") {
//       animate_attention();
//     } else {
//       Serial.println("Unknown state");
//     }
//     return;
//   }
//   Serial.println("Unknown command");
// }

// // =========================
// // MOVEMENT FUNCTIONS
// // =========================

// void move_smooth(int target_angle, int duration_ms) {
//   if (stop_flag) return;
  
//   int start_angle = current_angle;
//   int steps = duration_ms / STEP_DELAY;
  
//   for (int i = 0; i <= steps; i++) {
//     // Check serial inside movement loops so STOP works mid-transit
//     if (Serial.available() > 0) {
//       String command = Serial.readStringUntil('\n');
//       command.trim();
//       if (command == "STOP") { 
//         stop_flag = true; 
//         break; 
//       }
//     }
    
//     if (stop_flag) break;
    
//     float progress = (float)i / steps;
//     int angle = start_angle + (target_angle - start_angle) * progress;
//     angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);
    
//     myservo.write(angle);
//     current_angle = angle;
//     delay(STEP_DELAY);
//   }
// }

// // =========================
// // ANIMATION FUNCTIONS
// // =========================

// // FIX: Rewritten to use millis() timers instead of a blocking while loop
// void run_non_blocking_idle() {
//   unsigned long now = millis();
//   if (now - last_idle_step_time < 2300) return; // 2000ms delay + 300ms move time

//   last_idle_step_time = now;
  
//   if (idle_phase == 0) {
//     move_smooth(88, 300);
//     idle_phase = 1;
//   } else if (idle_phase == 1) {
//     move_smooth(90, 300);
//     idle_phase = 2;
//   } else if (idle_phase == 2) {
//     move_smooth(92, 300);
//     idle_phase = 3;
//   } else {
//     move_smooth(90, 300);
//     idle_phase = 0;
//   }
// }

// void animate_listening() {
//   move_smooth(85, 400);
//   if (!stop_flag) delay(500);
//   if (!stop_flag) move_smooth(90, 400);
// }

// void animate_thinking() {
//   move_smooth(100, 500);
//   if (!stop_flag) delay(800);
//   if (!stop_flag) move_smooth(90, 500);
// }

// void animate_speaking() {
//   move_smooth(95, 300);
//   if (!stop_flag) delay(400);
//   if (!stop_flag) move_smooth(90, 300);
//   if (!stop_flag) delay(400);
//   if (!stop_flag) move_smooth(85, 300);
//   if (!stop_flag) delay(400);
//   if (!stop_flag) move_smooth(90, 300);
// }

// void animate_greeting() {
//   move_smooth(80, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(100, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(90, 400);
// }

// void animate_goodbye() {
//   move_smooth(100, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(80, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(90, 400);
// }

// void animate_attention() {
//   move_smooth(90, 300);
// }










// #include <ESP32Servo.h>

// // =========================
// // CONFIGURATION
// // =========================

// const int SERVO_PIN = 18;  

// const int MIN_ANGLE = 40;
// const int MAX_ANGLE = 140;
// const int CENTER_ANGLE = 90;

// const int STEP_DELAY = 20;
// const int BAUD_RATE = 115200;

// // FIX: Change to "STARTUP" or "ATTENTION" so it doesn't immediately loop movements on boot
// String current_state = "STARTUP"; 
// int current_angle = CENTER_ANGLE;
// bool stop_flag = false;

// unsigned long last_idle_step_time = 0;
// int idle_phase = 0;

// Servo myservo;

// // =========================
// // SETUP
// // =========================

// void setup() {
//   Serial.begin(BAUD_RATE);
//   delay(1000);
  
//   Serial.println("========================================");
//   Serial.println("ESP32 Robot Head Controller");
//   Serial.println("========================================");
  
//   myservo.setPeriodHertz(50);  
//   myservo.attach(SERVO_PIN, 544, 2400);
  
//   // Set initial position once
//   myservo.write(CENTER_ANGLE);
//   current_angle = CENTER_ANGLE;
  
//   Serial.println("Ready to receive commands");
//   Serial.println("========================================");
// }

// // =========================
// // MAIN LOOP
// // =========================

// void loop() {
//   if (Serial.available() > 0) {
//     String command = Serial.readStringUntil('\n');
//     command.trim();
    
//     if (command.length() > 0) {
//       process_command(command);
//     }
//   }
  
//   // Only loops animations if explicitly put into IDLE state
//   if (current_state == "IDLE" && !stop_flag) {
//     run_non_blocking_idle();
//   }
  
//   // FIX: Removed the global myservo.write() from here. 
//   // Servos remember their pulse automatically; writing continuously causes twitching.
  
//   delay(10);
// }

// // =========================
// // COMMAND PROCESSING
// // =========================

// void process_command(String command) {
//   Serial.print("Received: ");
//   Serial.println(command);
  
//   if (command == "STOP") {
//     stop_flag = true;
//     Serial.println("Action: STOP");
//     return;
//   }
  
//   stop_flag = false;
  
//   if (command.startsWith("ANGLE:")) {
//     int angle = command.substring(6).toInt();
//     angle = constrain(angle, MIN_ANGLE, MAX_ANGLE);
//     move_smooth(angle, 500);
//     return;
//   }
  
//   if (command.startsWith("STATE:")) {
//     String state = command.substring(6);
//     current_state = state;
//     Serial.print("State changed to: ");
//     Serial.println(state);
    
//     if (state == "IDLE") {
//       idle_phase = 0; 
//       last_idle_step_time = 0;
//     } else if (state == "LISTENING") {
//       animate_listening();
//     } else if (state == "THINKING") {
//       animate_thinking();
//     } else if (state == "SPEAKING") {
//       animate_speaking();
//     } else if (state == "GREETING") {
//       animate_greeting();
//     } else if (state == "GOODBYE") {
//       animate_goodbye();
//     } else if (state == "ATTENTION") {
//       animate_attention();
//     } else {
//       Serial.println("Unknown state");
//     }
//     return;
//   }
//   Serial.println("Unknown command");
// }

// // =========================
// // MOVEMENT FUNCTIONS
// // =========================

// void move_smooth(int target_angle, int duration_ms) {
//   if (stop_flag) return;
  
//   int start_angle = current_angle;
//   int steps = duration_ms / STEP_DELAY;
//   if (steps < 1) steps = 1; // Prevent division by zero
  
//   for (int i = 0; i <= steps; i++) {
//     if (Serial.available() > 0) {
//       String command = Serial.readStringUntil('\n');
//       command.trim();
//       if (command == "STOP") { 
//         stop_flag = true; 
//         break; 
//       }
//     }
    
//     if (stop_flag) break;
    
//     float progress = (float)i / steps;
//     // FIX: Using precise float tracking to eliminate staircase step jitter
//     float exact_angle = (float)start_angle + ((float)target_angle - (float)start_angle) * progress;
//     int write_angle = constrain((int)round(exact_angle), MIN_ANGLE, MAX_ANGLE);
    
//     // FIX: Only send data to servo hardware when an actual degree changes
//     if (write_angle != current_angle) {
//       myservo.write(write_angle);
//       current_angle = write_angle;
//     }
    
//     delay(STEP_DELAY);
//   }
  
//   // Explicitly snap to target at end of sequence to finalize precision
//   if (!stop_flag) {
//     myservo.write(target_angle);
//     current_angle = target_angle;
//   }
// }

// // =========================
// // ANIMATION FUNCTIONS
// // =========================

// void run_non_blocking_idle() {
//   unsigned long now = millis();
//   if (now - last_idle_step_time < 2300) return; 

//   last_idle_step_time = now;
  
//   if (idle_phase == 0) {
//     move_smooth(88, 300);
//     idle_phase = 1;
//   } else if (idle_phase == 1) {
//     move_smooth(90, 300);
//     idle_phase = 2;
//   } else if (idle_phase == 2) {
//     move_smooth(92, 300);
//     idle_phase = 3;
//   } else {
//     move_smooth(90, 300);
//     idle_phase = 0;
//   }
// }

// void animate_listening() {
//   move_smooth(85, 400);
//   if (!stop_flag) delay(500);
//   if (!stop_flag) move_smooth(90, 400);
// }

// void animate_thinking() {
//   move_smooth(100, 500);
//   if (!stop_flag) delay(800);
//   if (!stop_flag) move_smooth(90, 500);
// }

// void animate_speaking() {
//   move_smooth(95, 300);
//   if (!stop_flag) delay(400);
//   if (!stop_flag) move_smooth(90, 300);
//   if (!stop_flag) delay(400);
//   if (!stop_flag) move_smooth(85, 300);
//   if (!stop_flag) delay(400);
//   if (!stop_flag) move_smooth(90, 300);
// }

// void animate_greeting() {
//   move_smooth(80, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(100, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(90, 400);
// }

// void animate_goodbye() {
//   move_smooth(100, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(80, 400);
//   if (!stop_flag) delay(300);
//   if (!stop_flag) move_smooth(90, 400);
// }

// void animate_attention() {
//   move_smooth(90, 300);
// }

